import SwiftUI
import UniformTypeIdentifiers
struct NativeConcertView: View {
    @ObservedObject var model: NativeConcertModel
    @Environment(\.dismiss) private var dismiss
    @State private var syncSheet = false
    @State private var settingsOpen = false
    @State private var midiAction: NativeMIDIAction = .playPause
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                VStack(alignment: .leading, spacing: 12) {
                    Text("NATIVE V27.32 · TEST VERSION").font(.caption).foregroundStyle(.secondary)
                    Picker("Song", selection: Binding(get: { model.selectedEntry }, set: { entry in Task { await model.selectEntry(entry) } })) {
                        ForEach(Array(model.playlist.enumerated()), id: \.offset) { entry, index in
                            Text("\(entry + 1). " + (model.songs[index]["title"] as? String ?? "Song")).tag(entry)
                        }
                    }.disabled(model.busy || model.playing)
                    HStack {
                        Button("PREVIOUS") { Task { await model.moveSong(-1) } }.disabled(model.busy || model.selectedEntry == 0)
                        Button(model.playing ? "PAUSE" : "PLAY") { model.play() }.disabled(model.busy || model.duration == 0)
                        Button("STOP") { model.stop() }
                        Button("NEXT") { Task { await model.moveSong(1) } }.disabled(model.busy || model.selectedEntry + 1 >= model.playlist.count)
                        Spacer()
                        Button("SETTINGS") { settingsOpen.toggle() }
                    }.buttonStyle(.bordered)
                    ProgressView(value: model.position, total: max(1, model.duration))
                    Text("\(Int(model.position)) / \(Int(model.duration)) s · \(model.status)").font(.footnote).lineLimit(4)
                }.padding().background(Color(white: 0.11))
                Divider()
                ScrollViewReader { reader in
                    ScrollView {
                        VStack(alignment: .leading, spacing: 20) {
                            Color.clear.frame(height: 1).id("lyrics-top")
                            if settingsOpen {
                                Text("The native player has a separate concert copy. Test before live use.").font(.footnote).foregroundStyle(.secondary)
                                if model.status.contains("\n") { Text(model.status).font(.footnote) }
                                Button("PREPARE AUDIO") { Task { await model.prepare() } }.disabled(model.busy || model.playing)
                        DisclosureGroup("Tempo & transpose") {
                            VStack(alignment: .leading, spacing: 14) {
                                Text("Tempo \(Int((model.rate * 100).rounded()))%")
                                Slider(value: $model.rate, in: 0.5...1.5, step: 0.01)
                                Stepper("Transpose \(Int(model.pitch)) semitones", value: $model.pitch, in: -6...6, step: 1)
                                Text("\(model.transposingCount) of \(model.rawTracks.count) tracks follow the song key. All tracks follow tempo.").font(.footnote)
                                ForEach(Array(model.rawTracks.enumerated()), id: \.offset) { index, track in
                                    Toggle(track["name"] as? String ?? "Track \(index + 1)", isOn: Binding(get: { model.trackFollows(track) }, set: { value in Task { await model.setTrackFollows(index, enabled: value) } }))
                                }
                                Button("APPLY & PREPARE") { Task { await model.saveSettings() } }
                            }.disabled(model.busy || model.playing || model.receiver).padding(.top)
                        }
                        DisclosureGroup("Practice & metronome") {
                            VStack(alignment: .leading, spacing: 12) {
                                Toggle("Practice", isOn: $model.practice)
                                Picker("Count-in", selection: $model.countBars) { Text("Off").tag(0); Text("2 bars").tag(2); Text("4 bars").tag(4) }
                                Stepper("Metronome \(Int(model.bpm)) BPM", value: $model.bpm, in: 20...300)
                                Toggle("Audible count-in", isOn: $model.audibleClick)
                                Toggle("Continue metronome", isOn: $model.continuousClick)
                                Button("SAVE CLICK SETTINGS") { Task { await model.saveSettings() } }.disabled(model.receiver)
                                if !model.regions.isEmpty {
                                    Picker("Region", selection: $model.regionIndex) { ForEach(Array(model.regions.enumerated()), id: \.offset) { i, region in Text(region["label"] as? String ?? "Region").tag(i) } }
                                    Button("PLAY REGION") { model.play(region: true) }.disabled(!model.practice || model.duration == 0)
                                }
                            }.disabled(model.busy || model.playing).padding(.top)
                        }
                        DisclosureGroup("Outputs") {
                            Toggle("Stereo 1–2 (off uses concert USB routing)", isOn: $model.stereo).disabled(model.playing || model.busy).onChange(of: model.stereo) { UserDefaults.standard.set(model.stereo, forKey: "nativeStereo"); Task { await model.prepare() } }
                            Text("Check the physical outputs on each device. Output mode stays local to this device.").font(.footnote).foregroundStyle(.secondary)
                        }
                        Button("SYNC WITH ANOTHER DEVICE") { syncSheet = true }.disabled(model.busy || model.playing)
                                DisclosureGroup("Native MIDI controls") {
                                    VStack(alignment: .leading, spacing: 12) {
                                        Picker("Action", selection: $midiAction) { ForEach(NativeMIDIAction.allCases, id: \.self) { action in Text(action.label).tag(action) } }
                                        HStack {
                                            Button(model.midiLearning ? "LISTENING…" : "LEARN") { model.learnMIDI(midiAction) }
                                            Button("CANCEL LEARN") { model.cancelMIDILearn() }
                                            Button("CLEAR ASSIGNMENTS") { model.clearMIDI() }
                                        }
                                        Text(model.midiInputs.isEmpty ? "No MIDI inputs connected." : "Inputs: " + model.midiInputs.joined(separator: ", ")).font(.footnote).foregroundStyle(.secondary)
                                        Text(model.midiStatus).font(.footnote)
                                        ForEach(Array(model.midiBindings.enumerated()), id: \.offset) { _, binding in Text(binding.action.label + " — " + binding.description).font(.footnote) }
                                        Text("Assignments are local to this device. Next / Previous stops the current song and prepares the next selection; it does not start it. Native and web playback do not receive the same pedal action together.").font(.footnote).foregroundStyle(.secondary)
                                    }.disabled(model.busy || model.playing).padding(.top)
                                }
                                Divider()
                            }
                            Toggle("Follow lyric sections", isOn: $model.followLyrics).onChange(of: model.followLyrics) {
                                UserDefaults.standard.set(model.followLyrics, forKey: "nativeFollowLyrics")
                                if model.followLyrics, let section = model.activeLyricSection, !settingsOpen { reader.scrollTo(section, anchor: .top) }
                            }
                            if model.regions.isEmpty { Text("No timed sections in this concert. Import region timings from REAPER to enable automatic text following.").font(.footnote).foregroundStyle(.secondary) }
                            LazyVStack(alignment: .leading, spacing: 28) {
                                ForEach(model.lyricSections) { section in
                                    VStack(alignment: .leading, spacing: 12) {
                                        if !section.label.isEmpty { Text(section.label).font(.headline).foregroundStyle(model.activeLyricSection == section.id ? Color.mint : Color.secondary) }
                                        ForEach(Array(section.lines.enumerated()), id: \.offset) { _, line in
                                            VStack(alignment: .leading, spacing: 4) {
                                                if !line.chords.isEmpty { Text(line.chords).foregroundStyle(.mint).font(.system(size: 20, design: .monospaced)) }
                                                Text(line.words.isEmpty ? " " : line.words).font(.system(size: 24, design: .monospaced))
                                            }.frame(maxWidth: .infinity, alignment: .leading)
                                        }
                                    }.frame(maxWidth: .infinity, alignment: .leading).id(section.id)
                                }
                            }
                        }.padding(24).frame(maxWidth: 1000)
                    }.onChange(of: model.activeLyricSection) { _, section in
                        if model.playing, model.followLyrics, !settingsOpen, let section { withAnimation(.easeInOut(duration: 0.25)) { reader.scrollTo(section, anchor: .top) } }
                    }.onChange(of: model.selectedEntry) { reader.scrollTo("lyrics-top", anchor: .top) }
                    .onChange(of: settingsOpen) {
                        if settingsOpen { reader.scrollTo("lyrics-top", anchor: .top) }
                        else if model.playing, model.followLyrics, let section = model.activeLyricSection { reader.scrollTo(section, anchor: .top) }
                    }
                }
            }.background(Color(white: 0.07)).navigationTitle(model.title)
                .toolbar { ToolbarItem(placement: .confirmationAction) { Button("CLOSE") { model.cancelMIDILearn(); model.stop(); dismiss() }.disabled(model.busy) } }
        }.preferredColorScheme(.dark)
        .sheet(isPresented: $syncSheet) { NativeSyncView(model: model) }
        .interactiveDismissDisabled(model.busy || model.playing)
        .task { if model.duration == 0 && model.library != nil { await model.prepare() } }
    }
}
