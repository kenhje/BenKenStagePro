import SwiftUI
import UniformTypeIdentifiers
struct NativeSyncView: View {
    @ObservedObject var model: NativeConcertModel
    @Environment(\.dismiss) private var dismiss
    @State private var folderPicker = false
    var openConcert: (() -> Void)? = nil
    private var sending: String { "To shared folder" }
    private var receiving: String { "From shared folder" }
    var body: some View {
        NavigationStack {
            Form {
                Section("Setlist") {
                    Text(model.library == nil ? "From sending device" : model.concertName)
                }
                Section("Sync from / to") {
                    Text("Mac, iPad and iPhone · choose the same shared folder on each device.").font(.caption)
                    Picker("Direction", selection: $model.publisher) {
                        Text(sending).tag(true)
                        Text(receiving).tag(false)
                    }.pickerStyle(.segmented).onChange(of: model.publisher) { model.saveSyncChoices() }
                }
                Section("Folder in use") {
                    Button(model.folder == nil ? "CHOOSE FOLDER" : model.folderName) { folderPicker = true }
                }
                Section {
                    Button("SYNC") { Task {
                        if await model.sync(force: true) { model.syncEnabled = true; model.saveSyncChoices() }
                    } }.buttonStyle(.borderedProminent)
                        .disabled(model.folder == nil || model.publisher && model.library == nil)
                    Text(model.syncStatus).font(.callout).textSelection(.enabled)
                }
            }.disabled(model.busy || model.playing)
             .navigationTitle("Concert / Sync")
             .toolbar { ToolbarItem(placement: .confirmationAction) { Button("DONE") { dismiss() }.disabled(model.busy) } }
        }.preferredColorScheme(.dark)
        .fileImporter(isPresented: $folderPicker, allowedContentTypes: [.folder]) { result in if case .success(let url) = result { model.chooseFolder(url) } }
        .interactiveDismissDisabled(model.busy || model.playing)
        .onAppear { model.configureSimpleSync(); model.syncControlsOpen = true }
        .onDisappear { model.syncControlsOpen = false }
    }
}
