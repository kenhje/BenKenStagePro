import Foundation
import WebKit
import SwiftUI
import UniformTypeIdentifiers
import AVFoundation
import EventKit
import MapKit

@MainActor private final class BenKenCalendarLink {
    private let store = EKEventStore()
    private let defaults = UserDefaults.standard
    private let mappingKey = "benken-calendar-managed-events-v1"
    private var allowed: Bool {
        if #available(iOS 17.0, macCatalyst 17.0, *) { return EKEventStore.authorizationStatus(for: .event) == .fullAccess }
        return EKEventStore.authorizationStatus(for: .event) == .authorized
    }
    func status() -> [String:Any] {
        guard allowed else { return ["connected":false,"calendars":[]] }
        return ["connected":true,"calendars":store.calendars(for:.event).filter(\.allowsContentModifications).map { ["id":$0.calendarIdentifier,"title":$0.title,"account":$0.source.title] },"selected":defaults.string(forKey:"benken-calendar-target") ?? ""]
    }
    func connect() async throws -> [String:Any] {
        let granted: Bool
        if #available(iOS 17.0, macCatalyst 17.0, *) { granted = try await store.requestFullAccessToEvents() }
        else { granted = try await withCheckedThrowingContinuation { continuation in store.requestAccess(to:.event) { ok,error in if let error {continuation.resume(throwing:error)} else {continuation.resume(returning:ok)} } } }
        guard granted else { throw BenKenAudioError.invalid("Calendar access is off. Enable full Calendar access for BenKen in device Settings.") }
        return status()
    }
    func sync(_ payload:[String:Any]) throws -> [String:Any] {
        guard allowed,let target=payload["calendarId"] as? String,let calendar=store.calendar(withIdentifier:target),calendar.allowsContentModifications,let rows=payload["events"] as? [[String:Any]],rows.count<=2000 else {throw BenKenAudioError.invalid("Choose a writable calendar first.")}
        // Validate the entire snapshot before staging any changes.
        var seen=Set<String>()
        for row in rows {guard let id=row["id"] as? String,id.range(of:"^[A-Za-z0-9_-]{1,100}$",options:.regularExpression) != nil,seen.insert(id).inserted,let title=row["title"] as? String,!title.isEmpty,let start=row["start"] as? Double,let end=row["end"] as? Double,start.isFinite,end.isFinite,end>start else {throw BenKenAudioError.invalid("Invalid calendar event.")}}
        let mapping=defaults.dictionary(forKey:mappingKey) as? [String:String] ?? [:]
        var saved:[String:EKEvent]=[:]
        do {
            for row in rows {
                let id=row["id"] as! String, marker=URL(string:"benkenstagepro://calendar/"+id)!
                let known=mapping[id].flatMap {store.event(withIdentifier:$0)}
                let event:EKEvent
                if let known, known.url==marker {event=known} else {event=EKEvent(eventStore:store)}
                event.calendar=calendar;event.title=row["title"] as? String
                event.startDate=Date(timeIntervalSince1970:row["start"] as! Double);event.endDate=Date(timeIntervalSince1970:row["end"] as! Double)
                event.location=row["location"] as? String;event.notes=row["notes"] as? String;event.url=marker
                try store.save(event,span:.thisEvent,commit:false);saved[id]=event
            }
            for (id,identifier) in mapping where !seen.contains(id) {
                if let event=store.event(withIdentifier:identifier),event.url==URL(string:"benkenstagepro://calendar/"+id) {try store.remove(event,span:.thisEvent,commit:false)}
            }
            try store.commit()
        } catch {store.reset();throw error}
        defaults.set(saved.compactMapValues(\.eventIdentifier),forKey:mappingKey)
        defaults.set(target,forKey:"benken-calendar-target")
        return ["count":saved.count,"calendar":calendar.title]
    }
}


private final class NativeTunerWindow: @unchecked Sendable {
    private let lock = NSLock()
    private var samples: [Float] = []
    private var active=true,dirty=false,channel=1
    func append(_ block:[Float],channel:Int) {
        lock.lock();defer {lock.unlock()}
        guard active else {return}
        samples.append(contentsOf:block.suffix(8192))
        if samples.count>8192 {samples.removeFirst(samples.count-8192)}
        self.channel=channel;dirty=true
    }
    func snapshot() -> (samples:[Float],channel:Int)? {
        lock.lock();defer {lock.unlock()}
        guard active,dirty,samples.count>=4096 else {return nil}
        dirty=false
        return (samples,channel)
    }
    func cancel() {lock.lock();active=false;dirty=false;samples.removeAll();lock.unlock()}
}
// Native input avoids WebKit AudioContext/microphone startup ordering.
@MainActor private final class NativeTunerCapture {
    private var engine: AVAudioEngine?
    private var captureWindow:NativeTunerWindow?
    private var analysisTimer:DispatchSourceTimer?
    private var generation = UUID()
    private let worker = DispatchQueue(label: "no.benken.tuner.analysis", qos: .userInitiated)
    private var reading: [String: Any] = ["running":false,"frequency":0.0,"level":0.0,"input":"Microphone off"]
    var running: Bool { engine != nil }
    nonisolated static func yieldsToPlayback(_ command:String) -> Bool { ["audioBegin","audioFinish","audioPlay","audioCancel","audioWarmBegin"].contains(command) }
    func status() -> [String:Any] { reading }
    func start() async throws {
        stop()
        let request = generation
        let granted = await withCheckedContinuation { continuation in
            AVCaptureDevice.requestAccess(for: .audio) { continuation.resume(returning: $0) }
        }
        guard request == generation else { throw CancellationError() }
        guard granted else { throw BenKenAudioError.invalid("Microphone access is off. Open iPad Settings → Privacy & Security → Microphone, enable BenKen Stage Pro, then try again.") }
        #if !targetEnvironment(macCatalyst)
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playAndRecord, mode: .measurement, options: [.mixWithOthers, .defaultToSpeaker])
        try session.setActive(true)
        if let microphone = session.availableInputs?.first(where: { $0.portType == .builtInMic }) { try session.setPreferredInput(microphone) }
        #endif
        let capture = AVAudioEngine(), input = capture.inputNode
        let format = input.outputFormat(forBus: 0)
        guard format.sampleRate > 0, format.channelCount > 0 else { throw BenKenAudioError.invalid("No microphone input is available. Check the connected audio device.") }
        let rate = format.sampleRate, accumulator = NativeTunerWindow()
        reading = ["running":true,"frequency":0.0,"level":0.0,"input":AVAudioSession.sharedInstance().currentRoute.inputs.map(\.portName).joined(separator:", ")]
        input.installTap(onBus: 0, bufferSize: 1024, format: format) { buffer, _ in
            guard let channels=buffer.floatChannelData, buffer.frameLength>0 else {return}
            let frames=Int(buffer.frameLength),stride=Int(buffer.stride)
            var strongest=0,highest=0.0
            for c in 0..<Int(buffer.format.channelCount) {var energy=0.0;for i in 0..<frames {let x=Double(channels[c][i*stride]);energy += x*x};if energy>highest {highest=energy;strongest=c}}
            let selectedChannel=strongest
            let data=(0..<frames).map {channels[selectedChannel][$0*stride]}
            accumulator.append(data,channel:selectedChannel+1)
        }
        captureWindow=accumulator
        // A dispatch timer coalesces missed ticks. Only the newest bounded window is analysed.
        // No per-audio-buffer analysis tasks can remain queued after closing the tuner.
        let timer=DispatchSource.makeTimerSource(queue:worker)
        timer.schedule(deadline:.now()+0.05,repeating:0.05,leeway:.milliseconds(5))
        timer.setEventHandler { [weak self] in
            guard let window=accumulator.snapshot() else {return}
            let result=NativeTunerCapture.estimate(window.samples,sampleRate:rate)
            Task { @MainActor [weak self] in
                guard let self,self.generation==request,self.engine != nil else {return}
                self.reading["frequency"]=result.frequency
                self.reading["level"]=result.level
                self.reading["channel"]=window.channel
                self.reading["sequence"]=(self.reading["sequence"] as? Int ?? 0)+1
            }
        }
        analysisTimer=timer;timer.resume()
        engine = capture
        capture.prepare()
        do { try capture.start() } catch { stop(); throw error }
    }
    func stop() {
        generation = UUID()
        captureWindow?.cancel();captureWindow=nil
        analysisTimer?.setEventHandler {};analysisTimer?.cancel();analysisTimer=nil
        if let engine { engine.inputNode.removeTap(onBus: 0); engine.stop() }
        engine = nil
        reading = ["running":false,"frequency":0.0,"level":0.0,"input":"Microphone off"]
    }
    nonisolated static func estimate(_ samples:[Float], sampleRate:Double) -> (frequency:Double,level:Double) {
        // A recent short window responds faster to guitar/voice; keep the long window for bass.
        if samples.count > 4096 {
            let fast = estimateWindow(Array(samples.suffix(4096)), sampleRate: sampleRate)
            if fast.frequency >= 65 { return fast }
        }
        return estimateWindow(samples, sampleRate: sampleRate)
    }
    nonisolated static func estimateWindow(_ samples:[Float], sampleRate:Double) -> (frequency:Double,level:Double) {
        let samples=Array(samples.suffix(8192))
        let stride = max(1,Int(sampleRate/12000)), count = samples.count/stride
        guard count >= 128 else { return (0,0) }
        var data = [Double](repeating:0,count:count), mean = 0.0
        for i in 0..<count { var sum=0.0;for j in 0..<stride {sum += Double(samples[i*stride+j])};data[i]=sum/Double(stride);mean += data[i] }
        mean /= Double(count)
        var energy=0.0
        for i in 0..<count {data[i] -= mean;energy += data[i]*data[i]}
        let level=sqrt(energy/Double(count))
        guard level >= 0.0003 else {return (0,level)}
        let rate=sampleRate/Double(stride), window=min(768,count/2), maximum=min(window-1,Int(rate/30)), minimum=max(2,Int(rate/2000))
        guard maximum > minimum else {return (0,level)}
        let coarseOffset=count-window-maximum-1
        var difference=[Double](repeating:1,count:maximum+1),running=0.0
        for tau in 1...maximum {var sum=0.0;for i in 0..<window {let value=data[coarseOffset+i]-data[coarseOffset+i+tau];sum += value*value};running += sum;difference[tau]=running>0 ? sum*Double(tau)/running : 1}
        var tau=minimum
        while tau<maximum {if difference[tau]<0.20 {while tau+1<=maximum && difference[tau+1]<difference[tau] {tau += 1};break};tau += 1}
        guard tau<maximum,difference[tau]<0.20 else {return (0,level)}
        let a=difference[tau-1],b=difference[tau],c=difference[tau+1],denominator=a-2*b+c
        let adjustment=denominator != 0 ? (a-c)/(2*denominator) : 0
        let coarse=rate/(Double(tau)+max(-1,min(1,adjustment)))
        let period=sampleRate/coarse, cycles=max(1,min(4,Int(Double(samples.count)*0.3/period)))
        let center=Int((period*Double(cycles)).rounded()), radius=max(3,Int(ceil(Double(stride*cycles)*0.65))), length=min(samples.count/2,max(1024,Int(ceil(period*6))))
        let lower=max(1,center-radius),upper=min(samples.count-length-1,center+radius)
        guard lower<upper else {return (0,level)}
        let sampleOffset=max(0,samples.count-length-upper-1)
        var scores=[Double](repeating:0,count:upper+2),best=center,bestScore = -Double.infinity
        for lag in lower...upper {
            var xy=0.0,xx=0.0,yy=0.0
            for i in 0..<length {let x=Double(samples[sampleOffset+i])-mean,y=Double(samples[sampleOffset+i+lag])-mean;xy += x*y;xx += x*x;yy += y*y}
            let value=xy/sqrt(max(xx*yy,1e-30));scores[lag]=value
            if value>bestScore {bestScore=value;best=lag}
        }
        guard bestScore>=0.75 else {return (0,level)}
        let left=scores[best-1],middle=scores[best],right=scores[best+1],curve=left-2*middle+right
        let offset=best>lower && best<upper && curve != 0 ? (left-right)/(2*curve) : 0
        let hz=sampleRate*Double(cycles)/(Double(best)+max(-1,min(1,offset)))
        return (hz.isFinite && hz>=30 && hz<=2000 ? hz : 0,level)
    }
}
#if !targetEnvironment(macCatalyst)
import MediaPlayer
#else
import CoreAudio
#endif

@MainActor final class NativePlayerBridge: NSObject, WKScriptMessageHandlerWithReply, UIDocumentPickerDelegate {
    let model = NativeConcertModel()
    let mainAudio = MainAudioSession()
    private let tuner = NativeTunerCapture()
    private let calendarLink = BenKenCalendarLink()
    weak var controller: UIViewController?
    #if !targetEnvironment(macCatalyst)
    private var deviceVolumeView: MPVolumeView?
    private var volumeObservation: NSKeyValueObservation?
    #endif
    private func deviceAudioStatus() -> [String: Any] {
        let session = AVAudioSession.sharedInstance()
        var rate = session.sampleRate, frames = Int((session.ioBufferDuration * session.sampleRate).rounded())
        #if targetEnvironment(macCatalyst)
        var device = AudioDeviceID(0), size = UInt32(MemoryLayout<AudioDeviceID>.size)
        var address = AudioObjectPropertyAddress(mSelector:kAudioHardwarePropertyDefaultOutputDevice,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
        if AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject),&address,0,nil,&size,&device) == noErr {
            var actual = UInt32(0);size = UInt32(MemoryLayout<UInt32>.size)
            address = AudioObjectPropertyAddress(mSelector:kAudioDevicePropertyBufferFrameSize,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
            if AudioObjectGetPropertyData(device,&address,0,nil,&size,&actual) == noErr { frames = Int(actual) }
            size = UInt32(MemoryLayout<Double>.size)
            address = AudioObjectPropertyAddress(mSelector:kAudioDevicePropertyNominalSampleRate,mScope:kAudioObjectPropertyScopeGlobal,mElement:kAudioObjectPropertyElementMain)
            _ = AudioObjectGetPropertyData(device,&address,0,nil,&size,&rate)
        }
        let isIPad = false
        #else
        let isIPad = true
        #endif
        return ["volume":session.outputVolume,"volumeSupported":isIPad,"bufferSupported":isIPad,"requestedFrames":UserDefaults.standard.object(forKey:"benken-buffer-frames") as? Int ?? 1024,"actualFrames":frames,"sampleRate":rate,"bufferMilliseconds":rate > 0 ? Double(frames)/rate*1000 : 0,"playing":model.playing || mainAudio.playing,"route":session.currentRoute.outputs.map(\.portName).joined(separator:", ")]
    }
    func hideDeviceVolume() {
        #if !targetEnvironment(macCatalyst)
        deviceVolumeView?.removeFromSuperview()
        #endif
    }
    private func deviceVolumeFrame(_ payload:[String:Any], web:WKWebView?) {
        #if !targetEnvironment(macCatalyst)
        guard payload["visible"] as? Bool == true, let web, let controller, controller.presentedViewController == nil,
              let x=payload["x"] as? Double,let y=payload["y"] as? Double,let width=payload["width"] as? Double,let height=payload["height"] as? Double,
              x.isFinite,y.isFinite,width.isFinite,height.isFinite,width>=40,height>=20 else { deviceVolumeView?.removeFromSuperview();return }
        let frame=web.convert(CGRect(x:x,y:y,width:width,height:height),to:controller.view)
        guard controller.view.bounds.contains(frame) else {deviceVolumeView?.removeFromSuperview();return}
        if deviceVolumeView == nil {let v=MPVolumeView(frame:frame);v.showsVolumeSlider=true;v.showsRouteButton=true;v.accessibilityLabel="Device volume";deviceVolumeView=v
            volumeObservation=AVAudioSession.sharedInstance().observe(\.outputVolume,options:[.initial,.new]) { [weak web] session,_ in
                let value=session.outputVolume
                DispatchQueue.main.async {web?.evaluateJavaScript("window.dispatchEvent(new CustomEvent('benken-device-volume',{detail:"+String(value)+"}))",completionHandler:nil)}
            }
        }
        if let v=deviceVolumeView {v.frame=frame;v.overrideUserInterfaceStyle=payload["light"] as? Bool == true ? .light : .dark
            if let hex=payload["color"] as? String,hex.range(of:"^#[0-9a-fA-F]{6}$",options:.regularExpression) != nil,let value=UInt32(hex.dropFirst(),radix:16){v.tintColor=UIColor(red:CGFloat((value>>16)&255)/255,green:CGFloat((value>>8)&255)/255,blue:CGFloat(value&255)/255,alpha:1)}
            if v.superview == nil {controller.view.addSubview(v)}
        }
        #endif
    }
    private var folderReply: ((Any?, String?) -> Void)?
    private var staging: URL?, state: Data?, catalog: [[String: Any]] = [], lengths: [String: Int] = [:]
    private var files: [String: URL] = [:]
    private var handles: [String: FileHandle] = [:]
    init(controller: UIViewController) { self.controller = controller }
    func stopTuning() { tuner.stop(); (controller as? BenKenController)?.endNativeTuning() }
    var isOpen: Bool { controller?.presentedViewController is UIHostingController<NativeConcertView> || controller?.presentedViewController is UIHostingController<NativeSyncView> }
    func open() {
        guard controller?.presentedViewController == nil else { return }
        model.setExternalPlaybackBusy(false)
        model.syncControlsOpen = false
        model.activateMIDI()
        let screen = UIHostingController(rootView: NativeConcertView(model: model)); screen.modalPresentationStyle = .fullScreen
        controller?.present(screen, animated: true)
    }
    func openSync() {
        guard controller?.presentedViewController == nil else { return }
        model.setExternalPlaybackBusy(false)
        model.syncControlsOpen = true
        let screen = UIHostingController(rootView: NativeSyncView(model: model, openConcert: { [weak self] in
            self?.controller?.presentedViewController?.dismiss(animated: true) { self?.open() }
        }))
        screen.modalPresentationStyle = .fullScreen; controller?.present(screen, animated: true)
    }
    private var localDevice: String {
        #if targetEnvironment(macCatalyst)
        return "Mac"
        #else
        return UIDevice.current.userInterfaceIdiom == .phone ? "iPhone" : "iPad"
        #endif
    }
    private func syncInfo() -> [String: Any] {
        ["receiver": model.receiver, "hasConcert": model.library != nil, "folder": model.folder == nil ? "" : model.folderName,
         "folderPath": model.folder?.path ?? "", "publisher": model.publisher, "device": localDevice,
         "setlist": model.library == nil ? "From sending device" : model.concertName,
         "status": model.syncStatus, "busy": model.busy || model.playing]
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        if let url = urls.first { model.chooseFolder(url) }
        let reply = folderReply; folderReply = nil; reply?(syncInfo(), nil)
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        let reply = folderReply; folderReply = nil; reply?(syncInfo(), nil)
    }
    private func reset() {
        for handle in handles.values { try? handle.close() }; handles = [:]
        if let staging { try? FileManager.default.removeItem(at: staging) }; staging = nil; state = nil; catalog = []; lengths = [:]; files = [:]
    }
    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage, replyHandler: @escaping (Any?, String?) -> Void) {
        guard message.frameInfo.isMainFrame, message.frameInfo.securityOrigin.protocol == "https", message.frameInfo.securityOrigin.host == "kenhje.github.io", let payload = message.body as? [String: Any], let command = payload["command"] as? String else { replyHandler(nil, "Untrusted native player request."); return }
        if command == "tunerStop" { tuner.stop(); (controller as? BenKenController)?.endNativeTuning(); replyHandler(tuner.status(),nil); return }
        if command == "calendarStatus" {replyHandler(calendarLink.status(),nil);return}
        if command == "calendarConnect" {Task {do {replyHandler(try await calendarLink.connect(),nil)} catch {replyHandler(nil,error.localizedDescription)}};return}
        if command == "calendarSync" {do {replyHandler(try calendarLink.sync(payload),nil)} catch {replyHandler(nil,error.localizedDescription)};return}
        if command == "venueSearch" {
            guard let query=payload["query"] as? String,query.count>=3,query.count<=200 else {replyHandler(nil,"Enter a venue name and city.");return}
            Task {do {let request=MKLocalSearch.Request();request.naturalLanguageQuery=query
                let response=try await MKLocalSearch(request:request).start()
                let rows:[[String:Any]]=response.mapItems.prefix(10).map {item in let p=item.placemark;return ["name":item.name ?? "","address":[p.thoroughfare,p.subThoroughfare].compactMap{$0}.joined(separator:" "),"postalCode":p.postalCode ?? "","city":p.locality ?? "","country":p.country ?? "","phone":item.phoneNumber ?? "","website":item.url?.absoluteString ?? "","latitude":p.coordinate.latitude,"longitude":p.coordinate.longitude]}
                replyHandler(["results":rows],nil)
            } catch {replyHandler(nil,error.localizedDescription)}};return
        }
        if command == "tunerStatus" { replyHandler(tuner.status(),nil); return }
        if command == "tunerStart" {
            guard !model.playing,!model.busy,!mainAudio.playing,!mainAudio.preparing else {replyHandler(nil,"Stop playback before tuning.");return}
            (controller as? BenKenController)?.beginNativeTuning()
            mainAudio.pauseForTuner()
            Task {do {try await tuner.start();replyHandler(tuner.status(),nil)}catch is CancellationError {replyHandler(nil,"Tuner start cancelled.")}catch{tuner.stop();(controller as? BenKenController)?.endNativeTuning();replyHandler(nil,error.localizedDescription)}}
            return
        }
        if command == "deviceAudioStatus" { replyHandler(deviceAudioStatus(),nil);return }
        if command == "deviceVolumeFrame" {deviceVolumeFrame(payload,web:message.webView);replyHandler(true,nil);return}
        if command == "deviceBuffer" {
            guard !model.playing,!model.busy,!mainAudio.playing,!mainAudio.preparing,let frames=payload["frames"] as? Int,[256,512,1024].contains(frames) else {replyHandler(nil,"Stop playback before changing buffer.");return}
            #if targetEnvironment(macCatalyst)
            replyHandler(nil,"The audio device controls buffer size on Mac.")
            #else
            do {let session=AVAudioSession.sharedInstance();try session.setPreferredIOBufferDuration(Double(frames)/max(1,session.sampleRate));UserDefaults.standard.set(frames,forKey:"benken-buffer-frames");replyHandler(deviceAudioStatus(),nil)}catch{replyHandler(nil,error.localizedDescription)}
            #endif
            return
        }
        if ["audioState","audioDiagnostics","midiClockStatus","midiClockConfigure"].contains(command) {
            Task {do {replyHandler(try await mainAudio.request(payload),nil)}catch{replyHandler(nil,error.localizedDescription)}}
            return
        }
        if command.hasPrefix("audio") {
            if tuner.running && command == "audioWarmBegin" && payload["automatic"] as? Bool == true { replyHandler(nil,"Tuner is running.");return }
            if tuner.running && NativeTunerCapture.yieldsToPlayback(command) { tuner.stop(); (controller as? BenKenController)?.endNativeTuning() }
            guard !model.playing, !model.busy, controller?.presentedViewController == nil else { replyHandler(nil, "Close the native player or other window before using the main audio engine."); return }
            Task { do { replyHandler(try await mainAudio.request(payload), nil) } catch { mainAudio.writeReport(reason:error.localizedDescription);replyHandler(nil, error.localizedDescription) } }; return
        }
        if command == "activity", let busy = payload["busy"] as? Bool { model.setExternalPlaybackBusy(busy); replyHandler(true, nil); return }
        if command == "concertStatus" { replyHandler(syncInfo(), nil); return }
        do {
            guard !model.busy, !model.playing, !mainAudio.playing, !mainAudio.preparing else { throw BenKenAudioError.invalid("Stop native playback and preparation before sending another concert.") }
            switch command {
            case "open": open(); replyHandler(true, nil)
            case "chooseSyncFolder":
                guard staging == nil else { throw BenKenAudioError.invalid("Wait for the current transfer.") }
                guard controller?.presentedViewController == nil, folderReply == nil else { throw BenKenAudioError.invalid("Close the other window first.") }
                let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder]); picker.delegate = self
                folderReply = replyHandler; controller?.present(picker, animated: true)
            case "syncNow":
                guard model.folder != nil, let publisher = payload["publisher"] as? Bool else { throw BenKenAudioError.invalid("Choose the shared folder first.") }
                model.publisher = publisher; model.saveSyncChoices(); model.setExternalPlaybackBusy(false)
                Task {
                    let success = await model.sync(force: true)
                    if success { model.syncEnabled = true; model.saveSyncChoices() }
                    replyHandler(syncInfo(), nil)
                }
            case "sync": openSync(); replyHandler(true, nil)
            case "begin":
                model.setExternalPlaybackBusy(false)
                guard payload["forSync"] as? Bool != true || model.folder != nil else { throw BenKenAudioError.invalid("Choose the shared folder first.") }
                if payload["forSync"] as? Bool == true { model.publisher = true; model.saveSyncChoices() }
                else { guard !model.receiver else { throw BenKenAudioError.invalid("This device receives a concert. Sync from the other device instead.") } }
                guard let text = payload["state"] as? String, text.utf8.count <= 8 * 1024 * 1024, let entries = payload["assets"] as? [[String: Any]], entries.count <= 10000 else { throw BenKenAudioError.invalid("Invalid concert transfer.") }
                reset(); let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString, isDirectory: true); try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                staging = folder; state = Data(text.utf8); catalog = entries
                var total = 0
                for entry in entries {
                    guard let id = entry["id"] as? String, !id.isEmpty, id.count <= 120, lengths[id] == nil, let bytes = entry["size"] as? Int, bytes > 0, bytes <= 160 * 1024 * 1024 else { throw BenKenAudioError.invalid("Invalid audio entry.") }
                    total += bytes; guard total <= 8 * 1024 * 1024 * 1024 else { throw BenKenAudioError.invalid("Concert transfer exceeds 8 GiB.") }
                    let file = folder.appendingPathComponent(UUID().uuidString); FileManager.default.createFile(atPath: file.path, contents: nil)
                    files[id] = file; lengths[id] = 0; handles[id] = try FileHandle(forWritingTo: file)
                }
                replyHandler(true, nil)
            case "chunk":
                guard let id = payload["asset"] as? String, let text = payload["data"] as? String, text.utf8.count <= 350_000, let data = Data(base64Encoded: text), data.count <= 256 * 1024, let handle = handles[id], let offset = payload["offset"] as? Int, offset == lengths[id], let size = catalog.first(where: { $0["id"] as? String == id })?["size"] as? Int, offset + data.count <= size else { throw BenKenAudioError.invalid("Incomplete or out-of-order audio transfer.") }
                try handle.write(contentsOf: data); lengths[id] = offset + data.count; replyHandler(true, nil)
            case "finish":
                guard let state, catalog.allSatisfy({ lengths[$0["id"] as? String ?? ""] == ($0["size"] as? Int) }) else { throw BenKenAudioError.invalid("Audio transfer is incomplete.") }
                for handle in handles.values { try handle.close() }; handles = [:]
                let originals = try catalog.map { entry -> (id: String, name: String, url: URL) in guard let id = entry["id"] as? String, let url = files[id] else { throw BenKenAudioError.invalid("Missing audio.") }; return (id, entry["name"] as? String ?? "audio.mp3", url) }
                model.busy = true
                let root = model.root
                Task {
                    do {
                        let library = try await Task.detached { try NativeLibrary.install(state: state, originals: originals, root: root) }.value
                        let forSync = payload["forSync"] as? Bool == true
                        reset(); model.busy = false; await model.accept(library, prepareAudio: !forSync)
                        if forSync {
                            let success = await model.sync(force: true)
                            if success { model.syncEnabled = true; model.saveSyncChoices() }
                            replyHandler(syncInfo(), nil)
                        } else { open(); replyHandler(true, nil) }
                    } catch { reset(); model.busy = false; replyHandler(nil, error.localizedDescription) }
                }
            case "cancel": reset(); replyHandler(true, nil)
            default: throw BenKenAudioError.invalid("Unknown native player command.")
            }
        } catch { reset(); replyHandler(nil, error.localizedDescription) }
    }
    static let script = #"""
    (()=>{
      const post=value=>window.webkit.messageHandlers.benkenNativePlayer.postMessage(value);
      window.BenKenNativePlayer={version:'27.32',available:true};
      let transferring=false,checking=false,nativeSyncing=false,info=null;
      const idle=()=>{const m=window.BenKenApp?.mixer;return !m||!(m.busy()||m.player.playing||m.player.click?.running)};
      setInterval(()=>{post({command:'activity',busy:!idle()||(transferring&&!nativeSyncing)}).catch(()=>{});if(!transferring&&!checking&&document.getElementById('nativeSyncNow'))refresh().catch(()=>{})},1000);
      const report=text=>{const el=document.getElementById('nativeTransferStatus')||document.getElementById('nativePlaybackStatus');if(el)el.textContent=text};
      const setDirection=()=>{
        const select=document.getElementById('concertSetSelect'),direction=document.getElementById('nativeSyncDirection');if(!select||!direction)return;
        if(direction.value==='receive'){
          if(!select.dataset.originalOptions){select.dataset.originalOptions=select.innerHTML;select.dataset.originalValue=select.value}
          const title=info?.setlist||'From sending device';if(select.dataset.receivedTitle!==title){const option=document.createElement('option');option.value='';option.textContent=title;select.replaceChildren(option);select.dataset.receivedTitle=title}
          select.disabled=true;select.title="The sending device chooses the setlist.";
        }else{
          if(select.dataset.originalOptions){select.innerHTML=select.dataset.originalOptions;select.value=select.dataset.originalValue;delete select.dataset.originalOptions;delete select.dataset.receivedTitle}
          select.disabled=transferring;select.title='';
        }
      };
      const applyInfo=value=>{
        info=value;
        const folder=document.getElementById('nativeSyncFolder'),direction=document.getElementById('nativeSyncDirection');
        if(folder){folder.textContent=value.folder||'CHOOSE FOLDER';folder.title=value.folderPath||''}
        if(direction&&!direction.dataset.chosen){direction.innerHTML='<option value="send">This device → shared folder</option><option value="receive">Shared folder → this device</option>';direction.title='Sync between Mac, iPad and iPhone using the same shared folder.';direction.value=value.publisher?'send':'receive';direction.dataset.chosen='true'}
        setDirection();
      };
      const refresh=async()=>{const value=await post({command:'concertStatus'});applyInfo(value);return value};
      const install=()=>{
        const playback=document.getElementById('nativePlaybackSlot');
        if(playback&&!document.getElementById('nativeOpenConcert')){
          const button=document.createElement('button');button.id='nativeOpenConcert';button.textContent='OPEN NATIVE TEST PLAYER';playback.appendChild(button);
          const status=document.createElement('p');status.id='nativePlaybackStatus';status.setAttribute('role','status');playback.appendChild(status);
          button.onclick=async()=>{if(transferring||checking)return;try{if(!idle())throw Error('Stop playback first.');const saved=await post({command:'concertStatus'});if(saved.receiver){window.BenKenApp?.mixer.cancel();await post({command:'open'})}else await transfer(false)}catch(e){report(e.message||String(e))}}
        }
        const panel=document.getElementById('nativeConcertSlot');if(!panel)return;
        if(document.getElementById('nativePlayerSection')?.parentNode===panel)return;
        const section=document.createElement('section');section.id='nativePlayerSection';
        section.innerHTML='<label for="nativeSyncDirection">SYNC FROM / TO</label><select id="nativeSyncDirection"><option value="send">This device → other device</option><option value="receive">Other device → this device</option></select><label for="nativeSyncFolder">FOLDER IN USE</label><button id="nativeSyncFolder" type="button">CHOOSE FOLDER</button><button id="nativeSyncNow" type="button">SYNC</button><p id="nativeTransferStatus" role="status" aria-live="polite"></p>';
        panel.replaceChildren(section);
        document.getElementById('nativeTransferStatus').style.whiteSpace='pre-line';
        document.getElementById('nativeSyncFolder').onclick=async()=>{if(transferring||checking)return;checking=true;try{if(!idle())throw Error('Stop playback first.');applyInfo(await post({command:'chooseSyncFolder'}))}catch(e){report(e.message||String(e))}finally{checking=false}};
        document.getElementById('nativeSyncDirection').onchange=setDirection;
        refresh().catch(e=>report(e.message||String(e)));
        document.getElementById('nativeSyncNow').onclick=()=>transfer(true);
      };
      const transfer=async forSync=>{
          if(transferring||checking)return;
          const app=window.BenKenApp;if(!app){report('Update the web files to V26.58, then reopen BenKen.');return}const mixer=app.mixer;
          if(mixer.busy()||mixer.player.playing||mixer.player.click?.running){report('Stop playback and preparation before sending a concert.');return}
          transferring=true;const button=document.getElementById(forSync?'nativeSyncNow':'nativeOpenConcert'),direction=document.getElementById('nativeSyncDirection'),folder=document.getElementById('nativeSyncFolder'),setlist=document.getElementById('concertSetSelect');
          button.disabled=true;if(direction)direction.disabled=true;if(folder)folder.disabled=true;if(setlist)setlist.disabled=true;
          try{
            const current=forSync?await refresh():null;if(forSync&&!current.folder)throw Error('Choose the same shared folder on Mac, iPad or iPhone first.');
            if(forSync&&direction?.value==='receive'){mixer.cancel();nativeSyncing=true;await post({command:'activity',busy:false});report('Receiving concert…');try{const result=await post({command:'syncNow',publisher:false});applyInfo(result);report(result.status)}finally{nativeSyncing=false;transferring=false;button.disabled=false;if(direction)direction.disabled=false;if(folder)folder.disabled=false;if(setlist)setlist.disabled=false;setDirection()}return}
          }catch(error){report(error.message||String(error));transferring=false;button.disabled=false;if(direction)direction.disabled=false;if(folder)folder.disabled=false;if(setlist)setlist.disabled=false;setDirection();return}
          try{
            const snapshot=StageConcert.concertState(app.state(),Date.now());
            for(const song of snapshot.songs){const rate=StageTempo.ratio(song);song._nativeRegions=StageLyrics.segments(song,(song.reaperSource?.duration||song.duration||0)/rate).map(r=>({...r,start:r.start*rate,end:r.end*rate}))}
            // Release decoded web audio before the native decoder starts.
            mixer.cancel();
            const signature=JSON.stringify(app.state()),ids=StageProject.assets(snapshot),assets=[];
            const missing=[];
            for(const id of ids){const file=await mixer.repo.get(id);if(!file?.data||!(file.data.byteLength??file.data.size)){missing.push(id);continue}assets.push({id,name:file.name||'audio.mp3',size:file.data.byteLength??file.data.size})}
            if(missing.length){const describe=window.StageProject.missingAudioMessage;if(describe)throw Error(describe(snapshot,missing));const wanted=new Set(missing),lines=[];for(const song of snapshot.songs)for(const track of song.playback?.tracks||[])if(wanted.has(track.assetId))lines.push(song.title+' → '+track.name+' → '+(track.fileName||'Original filename unavailable'));throw Error('Audio files missing locally:\n'+lines.slice(0,200).join('\n')+'\nReimport these songs from REAPER or use REPLACE FILE.')}
            await post({command:'begin',forSync,state:JSON.stringify(snapshot),assets});await post({command:'activity',busy:true});
            for(let i=0;i<assets.length;i++){
              const a=assets[i],file=await mixer.repo.get(a.id),blob=file.data instanceof Blob?file.data:new Blob([file.data]);
              if(blob.size!==a.size)throw Error('Audio changed during transfer. Please retry.');
              for(let offset=0;offset<blob.size;offset+=262144){const bytes=new Uint8Array(await blob.slice(offset,offset+262144).arrayBuffer());let binary='';for(let n=0;n<bytes.length;n+=8192)binary+=String.fromCharCode(...bytes.subarray(n,n+8192));await post({command:'chunk',asset:a.id,offset,data:btoa(binary)});report('Sending audio '+(i+1)+' / '+assets.length+' · '+Math.round((offset+bytes.length)/blob.size*100)+'%')}
            }
            if(signature!==JSON.stringify(app.state())||mixer.player.playing||mixer.busy())throw Error('The concert changed during transfer. Stop playback and send it again.');
            nativeSyncing=true;await post({command:'activity',busy:false});report(forSync?'Saving concert to sync folder…':'Preparing native player…');const result=await post({command:'finish',forSync});if(forSync){applyInfo(result);report(result.status)}else report('Native player opened.');
          }catch(error){try{await post({command:'cancel'})}catch{}report(error.message||String(error))}finally{nativeSyncing=false;transferring=false;button.disabled=false;if(direction)direction.disabled=false;if(folder)folder.disabled=false;if(setlist)setlist.disabled=false;setDirection()}
      };
      new MutationObserver(install).observe(document.documentElement,{childList:true,subtree:true});install();
    })();
    """#
}
