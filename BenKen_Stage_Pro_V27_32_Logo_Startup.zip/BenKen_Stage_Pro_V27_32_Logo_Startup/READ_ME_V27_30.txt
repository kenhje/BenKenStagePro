BenKen Native V27.30 — concert preparation and reusable audio
7 November 2026 · Use with Web V26.132.

Open App/BenKenStagePro.xcodeproj. Select your device and the existing developer team, then Run over the existing BenKen Stage Pro app. Do not delete the app. Bundle identity and web storage remain unchanged.

After updating: open Setlist → PREPARE CONCERT → PREPARE SETLIST while playback is stopped. Audio originals and prepared tempo/key versions remain on disk on this device. The first preparation takes time; later song loads reuse verified files. New, changed or damaged files require copying again. No whole-set decoded audio is kept in memory.

The main audio engine and current song stay unchanged during set preparation. Playback and the metronome cannot be started concurrently with preparation. Missing files, cancelled transfers and wrong fingerprints cannot be treated as ready. Previous native/web combinations keep their old full-transfer path; the fast path needs both new versions.

Validation: 51 core tests completed (2 skipped), no failures. iOS Simulator and Mac Catalyst builds passed without signing. Browser checks cover 30 songs/180 tracks, progress/cancellation, selection preservation, six-track zero-chunk reload and older-native fallback. Physical iPhone/iPad/Mac audio, interface routing and real transition times remain unverified. Gapless playback is not promised.
Made for BenKen™ · Copyright © Kenneth Hjelle 2026
