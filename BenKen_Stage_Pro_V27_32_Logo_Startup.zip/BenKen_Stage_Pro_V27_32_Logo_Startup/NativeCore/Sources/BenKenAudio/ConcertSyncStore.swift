import Foundation
import CryptoKit

public struct ConcertAsset: Codable, Sendable {
    public let id: String
    public let name: String
    public let file: String
    public let sha256: String
    public let bytes: Int64
}
public struct ConcertRevision: Codable, Sendable {
    public let schema: Int
    public let id: String
    public let parent: String?
    public let publisher: String
    public let created: Date
    public let state: String
    public let stateSHA256: String
    public let assets: [ConcertAsset]
}
public struct ConcertAcknowledgement: Codable, Sendable {
    public let device: String
    public let revision: String
    public let checked: Date
}

/// Folder transport: choose the same iCloud Drive folder on both devices.
/// Immutable revisions + content hashes tolerate partial cloud downloads and detect divergent publishers.
/// No deletion is propagated. Library application/backup stays the responsibility of the app.
public struct ConcertSyncStore: Sendable {
    public let root: URL
    public init(root: URL) { self.root = root }
    private func hash(_ data: Data) -> String { SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined() }
    private func validID(_ text: String) -> Bool { UUID(uuidString: text) != nil }
    private func requireID(_ text: String) throws { guard validID(text) else { throw BenKenAudioError.invalid("Invalid concert revision.") } }
    private func folder(_ name: String) throws -> URL { let url = root.appendingPathComponent(name, isDirectory: true); try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true); return url }
    public func head() throws -> ConcertRevision? {
        let directory = try folder("revisions")
        let files = try FileManager.default.contentsOfDirectory(at: directory, includingPropertiesForKeys: nil).filter { $0.pathExtension == "json" }
        var values: [ConcertRevision] = []
        for url in files {
            let revision = try JSONDecoder().decode(ConcertRevision.self, from: Data(contentsOf: url))
            try requireID(revision.id); if let parent = revision.parent { try requireID(parent) }
            guard revision.schema == 1, url.deletingPathExtension().lastPathComponent == revision.id else { throw BenKenAudioError.invalid("Unsupported or damaged concert revision.") }
            values.append(revision)
        }
        let ids = Set(values.map(\.id)), parents = Set(values.compactMap(\.parent))
        guard parents.isSubset(of: ids) else { throw BenKenAudioError.invalid("Concert history is still downloading. Keep both apps open and try again.") }
        let heads = values.filter { !parents.contains($0.id) }
        guard heads.count <= 1, values.isEmpty || heads.count == 1 else { throw BenKenAudioError.invalid("Concert sync conflict. Changes were published from more than one device; automatic restore is paused.") }
        return heads.first
    }
    public func publish(state: Data, assets: [(id: String, name: String, url: URL)], device: String, expectedParent: String?) throws -> ConcertRevision {
        try requireID(device)
        guard state.count <= 8 * 1024 * 1024, let text = String(data: state, encoding: .utf8), (try JSONSerialization.jsonObject(with: state)) is [String: Any], Set(assets.map(\.id)).count == assets.count else { throw BenKenAudioError.invalid("Invalid concert library.") }
        let current = try head()
        guard current?.id == expectedParent else { throw BenKenAudioError.invalid("The concert changed on another device. Check sync before publishing.") }
        let directory = try folder("assets"), revisions = try folder("revisions")
        var entries: [ConcertAsset] = []
        for asset in assets {
            guard !asset.id.isEmpty, asset.id.count <= 120 else { throw BenKenAudioError.invalid("Invalid audio identifier.") }
            let digest = try AudioPreparation.digest(asset.url)
            let ext = ["mp3", "wav", "m4a", "aif", "aiff", "caf"].contains(asset.url.pathExtension.lowercased()) ? asset.url.pathExtension.lowercased() : "bin"
            let name = digest + "." + ext, destination = directory.appendingPathComponent(name)
            let bytes = try asset.url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
            guard bytes > 0, bytes <= 160 * 1024 * 1024 else { throw BenKenAudioError.invalid("Audio file missing or larger than 160 MiB.") }
            if try !FileManager.default.fileExists(atPath: destination.path) || AudioPreparation.digest(destination) != digest {
                let temporary = directory.appendingPathComponent(UUID().uuidString + ".partial")
                defer { try? FileManager.default.removeItem(at: temporary) }
                try FileManager.default.copyItem(at: asset.url, to: temporary)
                guard try AudioPreparation.digest(temporary) == digest else { throw BenKenAudioError.invalid("Audio changed while copying. Retry sync.") }
                if FileManager.default.fileExists(atPath: destination.path) { _ = try FileManager.default.replaceItemAt(destination, withItemAt: temporary) }
                else { try FileManager.default.moveItem(at: temporary, to: destination) }
            }
            entries.append(ConcertAsset(id: asset.id, name: asset.name, file: name, sha256: digest, bytes: Int64(bytes)))
        }
        // Publish manifest last. A cloud provider can reorder arrivals, so receivers still verify every file.
        guard try head()?.id == expectedParent else { throw BenKenAudioError.invalid("Another device published while copying. Automatic sync is paused.") }
        let revision = ConcertRevision(schema: 1, id: UUID().uuidString, parent: expectedParent, publisher: device, created: Date(), state: text, stateSHA256: hash(state), assets: entries)
        try JSONEncoder().encode(revision).write(to: revisions.appendingPathComponent(revision.id + ".json"), options: .atomic)
        return revision
    }
    public func verify(_ revision: ConcertRevision) throws -> [(ConcertAsset, URL)] {
        try requireID(revision.id)
        guard revision.schema == 1, hash(Data(revision.state.utf8)) == revision.stateSHA256, Set(revision.assets.map(\.id)).count == revision.assets.count else { throw BenKenAudioError.invalid("Concert metadata verification failed.") }
        return try revision.assets.map { asset in
            guard asset.sha256.count == 64, asset.sha256.allSatisfy({ $0.isHexDigit && !$0.isUppercase }), asset.file.hasPrefix(asset.sha256 + "."), asset.file == URL(fileURLWithPath: asset.file).lastPathComponent, !asset.file.contains("/"), !asset.file.contains("\\"), asset.bytes > 0, asset.bytes <= 160 * 1024 * 1024 else { throw BenKenAudioError.invalid("Unsafe concert audio reference.") }
            let url = root.appendingPathComponent("assets").appendingPathComponent(asset.file)
            let resolvedRoot = root.appendingPathComponent("assets").resolvingSymlinksInPath().standardizedFileURL.path + "/"
            guard url.resolvingSymlinksInPath().standardizedFileURL.path.hasPrefix(resolvedRoot) else { throw BenKenAudioError.invalid("Concert audio points outside the selected folder.") }
            guard FileManager.default.fileExists(atPath: url.path), try url.resourceValues(forKeys: [.fileSizeKey]).fileSize == Int(asset.bytes), try AudioPreparation.digest(url) == asset.sha256 else { throw BenKenAudioError.invalid(NativeAudioDiagnostics.describe(state: Data(revision.state.utf8), ids: [asset.id], reason: "Concert audio is missing, incomplete or still downloading (" + asset.name + ")") + "\nThe current library is kept.") }
            return (asset, url)
        }
    }
    public func acknowledge(_ revision: ConcertRevision, device: String) throws {
        try requireID(device); _ = try verify(revision)
        let acknowledgement = ConcertAcknowledgement(device: device, revision: revision.id, checked: Date())
        try JSONEncoder().encode(acknowledgement).write(to: folder("devices").appendingPathComponent(device + ".json"), options: .atomic)
    }
    public func acknowledgements() throws -> [ConcertAcknowledgement] {
        try FileManager.default.contentsOfDirectory(at: folder("devices"), includingPropertiesForKeys: nil).filter { $0.pathExtension == "json" }.map { try JSONDecoder().decode(ConcertAcknowledgement.self, from: Data(contentsOf: $0)) }
    }
}
