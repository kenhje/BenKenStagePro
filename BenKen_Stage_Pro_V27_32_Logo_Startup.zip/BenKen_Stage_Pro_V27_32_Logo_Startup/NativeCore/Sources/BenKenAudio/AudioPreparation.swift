import AVFoundation
import CryptoKit
import Foundation

/// Recheck a file when its size, modification time or file identity changes.
/// These files live in app-owned, content-addressed storage and are immutable after publication.
enum VerifiedAudioDigest {
    private static let lock = NSLock()
    private static var entries: [String: (stamp: String, hash: String)] = [:]
    static func digest(_ url: URL) throws -> String {
        let attrs = try FileManager.default.attributesOfItem(atPath: url.path)
        let stamp = "\(attrs[.size] ?? 0)|\((attrs[.modificationDate] as? Date)?.timeIntervalSince1970 ?? 0)|\(attrs[.systemFileNumber] ?? 0)"
        lock.lock(); let prior = entries[url.path]; lock.unlock()
        if let prior, prior.stamp == stamp { return prior.hash }
        let hash = try AudioPreparation.digest(url)
        lock.lock(); if entries.count>4096 {entries.removeAll()};entries[url.path] = (stamp, hash); lock.unlock()
        return hash
    }
}

public enum BenKenAudioError: LocalizedError {
    case invalid(String)
    public var errorDescription: String? { if case .invalid(let message) = self { return message }; return nil }
}
public struct PreparedAudio: Codable, Sendable {
    public let url: URL
    public let sourceDuration: Double
    public let duration: Double
    public let channels: UInt32
    public let sampleRate: Double
    public let digest: String
    public let preparedDigest: String
}

/// Work runs on one utility queue, never on the realtime audio thread.
/// MP3 originals remain immutable. CAF caches are disposable and keyed by content + settings.
public final class AudioPreparation: @unchecked Sendable {
    public static let sampleRate = 48_000.0
    private let queue = DispatchQueue(label: "no.benken.audio.prepare", qos: .utility)
    private let cache: URL
    private let lock = NSLock()
    private var generation = 0
    public init(cache: URL) throws { self.cache = cache; try FileManager.default.createDirectory(at: cache, withIntermediateDirectories: true) }
    public func cancel() { lock.lock(); generation += 1; lock.unlock() }
    private func token() -> Int { lock.lock(); defer { lock.unlock() }; return generation }
    private func check(_ token: Int) throws { if token != self.token() { throw CancellationError() } }
    public func prepare(_ source: URL, rate: Double, semitones: Double, mono: Bool = false, progress: (@Sendable (Double) -> Void)? = nil) async throws -> PreparedAudio {
        guard rate.isFinite, (0.5...1.5).contains(rate), semitones.isFinite, (-6...6).contains(semitones) else { throw BenKenAudioError.invalid("Choose tempo 50–150% and transpose −6 to +6 semitones.") }
        let token = self.token()
        return try await withCheckedThrowingContinuation { continuation in
            queue.async { autoreleasepool { do { continuation.resume(returning: try self.render(source, rate: rate, semitones: semitones, mono: mono, token: token, progress: progress)) } catch { continuation.resume(throwing: error) } } }
        }
    }
    public static func digest(_ url: URL) throws -> String {
        let handle = try FileHandle(forReadingFrom: url); defer { try? handle.close() }
        var hash = SHA256()
        while try autoreleasepool(invoking: { guard let block = try handle.read(upToCount: 1_048_576), !block.isEmpty else { return false }; hash.update(data: block); return true }) {}
        return hash.finalize().map { String(format: "%02x", $0) }.joined()
    }
    private func render(_ source: URL, rate: Double, semitones: Double, mono: Bool, token: Int, progress: (@Sendable (Double) -> Void)?) throws -> PreparedAudio {
        try check(token)
        progress?(0)
        let sourceHash = try VerifiedAudioDigest.digest(source)
        progress?(0.03)
        let identity = "apple-timepitch-v1|\(sourceHash)|\(rate)|\(semitones)|\(mono)"
        let key = SHA256.hash(data: Data(identity.utf8)).map { String(format: "%02x", $0) }.joined()
        let destination = cache.appendingPathComponent(key + ".caf"), metadata = cache.appendingPathComponent(key + ".json")
        if let data = try? Data(contentsOf: metadata), let saved = try? JSONDecoder().decode(PreparedAudio.self, from: data), saved.url == destination,
           let file = try? AVAudioFile(forReading: destination), file.length > 0, (try? VerifiedAudioDigest.digest(destination)) == saved.preparedDigest,
           abs(Double(file.length) / file.processingFormat.sampleRate - saved.duration) < 1 / Self.sampleRate { progress?(1); return saved }
        let input = try AVAudioFile(forReading: source)
        guard input.length > 0, (1...2).contains(input.processingFormat.channelCount) else { throw BenKenAudioError.invalid("Use a readable mono or stereo MP3, WAV, M4A or CAF file.") }
        let sourceDuration = Double(input.length) / input.processingFormat.sampleRate
        guard sourceDuration.isFinite, sourceDuration < 7200 else { throw BenKenAudioError.invalid("Audio files must be shorter than two hours.") }
        let channels: AVAudioChannelCount = mono ? 1 : input.processingFormat.channelCount
        let format = AVAudioFormat(standardFormatWithSampleRate: Self.sampleRate, channels: channels)!
        let frames = AVAudioFramePosition((sourceDuration / rate * Self.sampleRate).rounded())
        let available = try cache.resourceValues(forKeys: [.volumeAvailableCapacityKey]).volumeAvailableCapacity ?? 0
        guard Int64(available) > Int64(frames) * Int64(channels) * 4 + 32_000_000 else { throw BenKenAudioError.invalid("Not enough free storage to prepare this audio. Free some space and retry.") }
        let temporary = cache.appendingPathComponent(UUID().uuidString + ".partial.caf")
        defer { try? FileManager.default.removeItem(at: temporary) }
        let engine = AVAudioEngine(), player = AVAudioPlayerNode(), pitch = AVAudioUnitTimePitch()
        engine.attach(player)
        if rate == 1 && semitones == 0 {
            engine.connect(player, to: engine.mainMixerNode, format: input.processingFormat)
        } else {
            engine.attach(pitch)
            pitch.rate = Float(rate); pitch.pitch = Float(semitones * 100); pitch.overlap = 16
            engine.connect(player, to: pitch, format: input.processingFormat)
            engine.connect(pitch, to: engine.mainMixerNode, format: input.processingFormat)
        }
        try engine.enableManualRenderingMode(.offline, format: format, maximumFrameCount: 4096)
        defer { player.stop(); engine.stop(); engine.disableManualRenderingMode() }
        player.scheduleFile(input, at: nil)
        try engine.start(); player.play()
        var output: AVAudioFile? = try AVAudioFile(forWriting: temporary, settings: format.settings)
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 4096)!
        var written: AVAudioFramePosition = 0, retries = 0
        var lastProgress = -1
        while written < frames {
            try check(token)
            let count = AVAudioFrameCount(min(4096, frames - written))
            let status = try engine.renderOffline(count, to: buffer)
            switch status {
            case .success:
                guard buffer.frameLength > 0 else { throw BenKenAudioError.invalid("The audio processor produced no audio.") }
                try output!.write(from: buffer); written += AVAudioFramePosition(buffer.frameLength); retries = 0
            case .cannotDoInCurrentContext: retries += 1
            case .insufficientDataFromInputNode: throw BenKenAudioError.invalid("Audio ended before preparation completed.")
            case .error: throw BenKenAudioError.invalid("Native audio preparation failed.")
            @unknown default: throw BenKenAudioError.invalid("Unsupported audio processor status.")
            }
            let percent = Int(Double(written) / Double(frames) * 90)
            if percent != lastProgress { lastProgress = percent; progress?(0.03 + Double(percent) / 100) }
            if retries > 100 { throw BenKenAudioError.invalid("Audio preparation stalled. Please retry.") }
        }
        progress?(0.94)
        output = nil // Close and flush before publishing the cache entry.
        try check(token)
        guard try Self.digest(source) == sourceHash else { throw BenKenAudioError.invalid("Original audio changed during preparation. Please retry.") }
        if FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.removeItem(at: destination) }
        try FileManager.default.moveItem(at: temporary, to: destination)
        let result = PreparedAudio(url: destination, sourceDuration: sourceDuration, duration: Double(frames) / Self.sampleRate, channels: channels, sampleRate: Self.sampleRate, digest: sourceHash, preparedDigest: try VerifiedAudioDigest.digest(destination))
        try JSONEncoder().encode(result).write(to: metadata, options: .atomic)
        progress?(1)
        return result
    }
}
