import SwiftUI
import AVFoundation
import UniformTypeIdentifiers

@MainActor final class NativeConcertModel: ObservableObject {
    @Published var library: NativeLibrary? { didSet { rebuildLibrary() } }
    @Published var selected = 0 { didSet { rebuildLyrics() } }
    @Published var selectedEntry = 0
    @Published var lyricSections: [NativeLyricSection] = []
    @Published var followLyrics = UserDefaults.standard.object(forKey: "nativeFollowLyrics") as? Bool ?? true
    @Published var midiInputs: [String] = []
    @Published var midiStatus = "No native MIDI assignment yet."
    @Published var midiBindings: [NativeMIDIBinding] = []
    @Published var midiLearning = false
    private var cachedState: [String: Any] = [:]
    private var cachedRegionTimes: [NativeRegionTime] = []
    private var appliedRate = 1.0
    @Published private(set) var activeLyricSection: Int?
    @Published var status = "Send a concert from Settings → Concert, or reopen your saved native concert."
    var preparationProgress = 0.0
    var preparationPhase = ""
    @Published var busy = false
    @Published var playing = false
    @Published var position = 0.0
    @Published var duration = 0.0
    @Published var rate = 1.0
    @Published var pitch = 0.0
    @Published var stereo = UserDefaults.standard.object(forKey: "nativeStereo") as? Bool ?? true
    @Published var practice = false
    @Published var countBars = 0
    @Published var audibleClick = false
    @Published var continuousClick = false
    @Published var bpm = 120.0
    @Published var syncEnabled = UserDefaults.standard.bool(forKey: "nativeSyncEnabled")
    @Published var publisher = UserDefaults.standard.bool(forKey: "nativeSyncPublisher")
    @Published var syncStatus = "Sync off. Select the same iCloud Drive folder on both devices."
    @Published var folderName = "Choose sync folder"
    @Published var regionIndex = 0
    let root: URL
    let preparation: AudioPreparation?
    let transport = NativeTransport()
    var folder: URL?
    var lastRevision: String? { get { preferences.string(forKey: "nativeSyncRevision") } set { preferences.set(newValue, forKey: "nativeSyncRevision") } }
    private var lastPublishedState: Data?
    private var generation = 0
    private var syncBusy = false
    private var externalPlaybackBusy = false
    var syncControlsOpen = false
    var concertName: String { (state["concertPackage"] as? [String: Any])?["name"] as? String ?? (state["set"] as? String).flatMap { $0.isEmpty ? nil : $0 } ?? "All songs" }
    func configureSimpleSync() { if preferences.object(forKey: "nativeSyncPublisher") == nil { publisher = library != nil } }
    func saveSyncChoices() { preferences.set(syncEnabled, forKey: "nativeSyncEnabled"); preferences.set(publisher, forKey: "nativeSyncPublisher") }
    func setExternalPlaybackBusy(_ value: Bool) { externalPlaybackBusy = value; if value { preparation?.cancel() } }
    private var ticker: Timer?, syncTimer: Timer?
    private let device: String
    private let preferences: UserDefaults
    init(root rootOverride: URL? = nil, preferences: UserDefaults = .standard, startTimers: Bool = true) {
        self.preferences = preferences
        let base = rootOverride ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("BenKenNative", isDirectory: true)
        root = base
        preparation = try? AudioPreparation(cache: base.appendingPathComponent("prepared", isDirectory: true))
        if let data = try? Data(contentsOf: base.appendingPathComponent("library.json")), let value = try? JSONDecoder().decode(NativeLibrary.self, from: data) { var local = value; local.assets = value.assets.mapValues { base.appendingPathComponent("originals").appendingPathComponent($0.lastPathComponent) }; library = local }
        device = preferences.string(forKey: "nativeDeviceID") ?? UUID().uuidString
        preferences.set(device, forKey: "nativeDeviceID")
        if let bookmark = preferences.data(forKey: "nativeSyncFolder") {
            var stale = false
            folder = try? URL(resolvingBookmarkData: bookmark, options: .withoutUI, relativeTo: nil, bookmarkDataIsStale: &stale)
            if let folder { folderName = folder.lastPathComponent }
        }
        transport.onEnded = { [weak self] _ in self?.playing = false; self?.position = self?.transport.currentTime ?? 0; self?.status = "Finished. Choose Play to start again." }
        transport.onInterruption = { [weak self] text in self?.playing = false; self?.duration = 0; self?.status = text }
        transport.observeSession()
        if startTimers {
        ticker = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in Task { @MainActor in guard let self else { return }; self.position = self.transport.currentTime; self.playing = self.transport.playing; self.updateActiveSection(); if self.playing && !self.transport.countingIn && self.status.hasPrefix("Count-in") { self.status = "Playing" } } }
        syncTimer = Timer.scheduledTimer(withTimeInterval: 30, repeats: true) { [weak self] _ in Task { @MainActor in await self?.sync() } }
        }
        stereo = preferences.object(forKey: "nativeStereo") as? Bool ?? true
        followLyrics = preferences.object(forKey: "nativeFollowLyrics") as? Bool ?? true
        syncEnabled = preferences.bool(forKey: "nativeSyncEnabled"); publisher = preferences.bool(forKey: "nativeSyncPublisher")
        if let data = preferences.data(forKey: "nativeMIDIBindings"), let bindings = try? JSONDecoder().decode([NativeMIDIBinding].self, from: data) { midiBindings = bindings.filter(\.valid) }
        nativeMIDI = NativeMIDIRouter(bindings: midiBindings)
        rebuildLibrary(); selected = playlist.first ?? 0; readSettings()
    }
    private var nativeMIDI: NativeMIDIRouter?
    private func rebuildLibrary() {
        cachedState = library.flatMap { (try? JSONSerialization.jsonObject(with: $0.state)) as? [String: Any] } ?? [:]
        rebuildLyrics()
    }
    private func rebuildLyrics() {
        let key = song["key"] as? String ?? ""
        let flats = key.contains("b") || ["F","Dm","Gm","Cm","Fm","Bbm","Ebm"].contains(key)
        let tempo = playback["tempo"] as? [String: Any] ?? [:], original = tempo["originalBpm"] as? Double ?? 120
        appliedRate = (tempo["targetBpm"] as? Double ?? original) / original
        cachedRegionTimes = regions.compactMap { r in guard let index = r["index"] as? Int, let start = r["start"] as? Double, let end = r["end"] as? Double else { return nil }; return NativeRegionTime(index: index, start: start, end: end) }
        updateActiveSection()
        lyricSections = NativeLyrics.sections(text, semitones: Int(playback["transpose"] as? Double ?? 0), preferFlats: flats)
    }
    var state: [String: Any] { cachedState }
    var songs: [[String: Any]] { state["songs"] as? [[String: Any]] ?? [] }
    var song: [String: Any] { songs.indices.contains(selected) ? songs[selected] : [:] }
    var title: String { song["title"] as? String ?? "Native concert player" }
    var text: String { song["text"] as? String ?? "" }
    var playback: [String: Any] { song["playback"] as? [String: Any] ?? [:] }
    var rawTracks: [[String: Any]] { playback["tracks"] as? [[String: Any]] ?? [] }
    var regions: [[String: Any]] { song["_nativeRegions"] as? [[String: Any]] ?? [] }
    var playlist: [Int] { NativePlaylist.order(songCount: songs.count, selectedSet: state["set"] as? String ?? "", sets: state["sets"] as? [String: [Int]] ?? [:]) }
    private func updateActiveSection() {
        let value = NativeLyrics.activeSection(position: position, rate: appliedRate, regions: cachedRegionTimes)
        if activeLyricSection != value { activeLyricSection = value }
    }
    var receiver: Bool { syncEnabled && !publisher }
    var transposingCount: Int { rawTracks.filter { trackFollows($0) }.count }
    func trackFollows(_ track: [String: Any]) -> Bool {
        TransposeSelection.follows(name: track["name"] as? String ?? "", fileName: track["fileName"] as? String ?? library?.names[track["assetId"] as? String ?? ""] ?? "", explicit: track["followTranspose"] as? Bool)
    }
    func setTrackFollows(_ index: Int, enabled: Bool) async {
        guard !busy, !playing, !receiver, var library, rawTracks.indices.contains(index) else { return }
        if enabled && !trackFollows(rawTracks[index]) && transposingCount >= 3 { status = "Choose at most three tracks to transpose."; return }
        do {
            var db = state, all = songs, changed = song, pb = playback, tracks = rawTracks
            tracks[index]["followTranspose"] = enabled; pb["tracks"] = tracks; changed["playback"] = pb; all[selected] = changed; db["songs"] = all
            library.state = try JSONSerialization.data(withJSONObject: db, options: .sortedKeys)
            try library.save(at: root); self.library = library
            await prepare()
        } catch { status = error.localizedDescription }
    }
    func selectEntry(_ entry: Int) async {
        guard !busy, !playing, playlist.indices.contains(entry) else { return }
        selectedEntry = entry; await select(playlist[entry])
    }
    func moveSong(_ direction: Int) async {
        guard !busy, playlist.indices.contains(selectedEntry + direction) else { return }
        stop(); await selectEntry(selectedEntry + direction)
    }
    func updateMIDIPorts(_ ports: [[String: String]]) { midiInputs = ports.map { $0["name"] ?? "MIDI input" } }
    func activateMIDI() { nativeMIDI?.resetInputState(); nativeMIDI?.cancelLearning(); midiLearning = false; midiStatus = "Native MIDI ready · \(midiBindings.count) assignment(s)." }
    func learnMIDI(_ action: NativeMIDIAction) { nativeMIDI?.learn(action); midiLearning = true; midiStatus = nativeMIDI?.status ?? "" }
    func cancelMIDILearn() { nativeMIDI?.cancelLearning(); midiLearning = false; midiStatus = nativeMIDI?.status ?? "" }
    func clearMIDI() { nativeMIDI?.clear(); saveMIDI(); midiLearning = false; midiStatus = nativeMIDI?.status ?? "" }
    private func saveMIDI() {
        midiBindings = nativeMIDI?.bindings ?? []
        if let data = try? JSONEncoder().encode(midiBindings) { preferences.set(data, forKey: "nativeMIDIBindings") }
    }
    func receiveMIDI(source: String, bytes: [UInt8]) {
        guard !syncControlsOpen, let nativeMIDI else { return }
        let wasLearning = nativeMIDI.learning != nil
        let action = nativeMIDI.receive(bytes, source: source, now: ProcessInfo.processInfo.systemUptime)
        if midiStatus != nativeMIDI.status { midiStatus = nativeMIDI.status }; if midiLearning != (nativeMIDI.learning != nil) { midiLearning = nativeMIDI.learning != nil }
        if wasLearning && !midiLearning { saveMIDI() }
        guard !busy, let action else { return }
        switch action {
        case .start: if !playing { play() }
        case .playPause: play()
        case .stop: stop()
        case .next: Task { await moveSong(1) }
        case .previous: Task { await moveSong(-1) }
        case .beginning:
            let resume = playing; stop(); if resume { play() }
        }
    }
    func readSettings() {
        let tempo = playback["tempo"] as? [String: Any] ?? [:], original = tempo["originalBpm"] as? Double ?? 120
        rate = (tempo["targetBpm"] as? Double ?? original) / original; pitch = playback["transpose"] as? Double ?? 0
        let click = playback["click"] as? [String: Any] ?? [:]
        bpm = click["bpm"] as? Double ?? original; countBars = click["countInBars"] as? Int ?? 0; audibleClick = click["countInSound"] as? Bool ?? false; continuousClick = click["continuous"] as? Bool ?? false
    }
    func accept(_ value: NativeLibrary, prepareAudio: Bool = true) async {
        guard !playing, !busy else { status = "Stop playback before replacing the native concert."; return }
        do { try value.validate(); transport.stop(); duration = 0; position = 0; library = value; selected = playlist.first ?? 0; selectedEntry = 0; readSettings(); lastRevision = nil; lastPublishedState = nil; if prepareAudio { await prepare() } } catch { status = error.localizedDescription }
    }
    func select(_ index: Int) async {
        guard !busy, !playing, songs.indices.contains(index) else { return }
        selected = index; regionIndex = 0; readSettings(); await prepare()
    }
    private func preparedTracks(_ index: Int, from candidate: NativeLibrary? = nil, parsedState: [String: Any]? = nil) async throws -> [NativeTrack] {
        guard let library = candidate ?? library else { return [] }
        let candidateState: [String: Any]
        if let parsedState { candidateState = parsedState }
        else if candidate != nil { candidateState = try JSONSerialization.jsonObject(with: library.state) as? [String: Any] ?? [:] }
        else { candidateState = cachedState }
        guard let candidateSongs = candidateState["songs"] as? [[String: Any]], candidateSongs.indices.contains(index) else { return [] }
        let song = candidateSongs[index], pb = song["playback"] as? [String: Any] ?? [:], tracks = pb["tracks"] as? [[String: Any]] ?? []
        let opts = candidateState["opts"] as? [String: Any] ?? [:], buses = opts["audioBuses"] as? [[String: Any]] ?? []
        let tempo = pb["tempo"] as? [String: Any] ?? [:], original = tempo["originalBpm"] as? Double ?? 120, ratio = (tempo["targetBpm"] as? Double ?? original) / original
        let transpose = pb["transpose"] as? Double ?? 0, songGain = pb["masterGain"] as? Double ?? 1, solo = tracks.contains { $0["solo"] as? Bool == true }
        let followsCount = tracks.filter { TransposeSelection.follows(name: $0["name"] as? String ?? "", fileName: $0["fileName"] as? String ?? library.names[$0["assetId"] as? String ?? ""] ?? "", explicit: $0["followTranspose"] as? Bool) }.count
        try TransposeSelection.validate(count: followsCount, semitones: transpose)
        guard let preparation else { throw BenKenAudioError.invalid("Audio storage could not be opened. Check free storage and reopen the app.") }
        var result: [NativeTrack] = []
        for (trackIndex, track) in tracks.enumerated() {
            preparationPhase = "Preparing track \(trackIndex + 1) / \(tracks.count): \(track["name"] as? String ?? "Audio")"
            preparationProgress = Double(trackIndex) / Double(max(1, tracks.count))
            if externalPlaybackBusy { throw CancellationError() }
            guard let id = track["assetId"] as? String, let source = library.assets[id], FileManager.default.fileExists(atPath: source.path) else { throw BenKenAudioError.invalid(NativeAudioDiagnostics.describe(state: library.state, ids: [track["assetId"] as? String ?? ""])) }
            let trackStereo = track["stereo"] as? Bool ?? true
            let audio: PreparedAudio
            do { audio = try await preparation.prepare(source, rate: ratio, semitones: TransposeSelection.follows(name: track["name"] as? String ?? "", fileName: track["fileName"] as? String ?? library.names[id] ?? "", explicit: track["followTranspose"] as? Bool) ? transpose : 0, mono: !trackStereo, progress: { [weak self] fraction in
                    Task { @MainActor in guard let self, self.busy, !self.externalPlaybackBusy else { return }; self.preparationProgress = max(self.preparationProgress, (Double(trackIndex) + min(1, max(0, fraction))) / Double(max(1, tracks.count))) }
                }) } catch {
                if error is CancellationError { throw error }
                let report = NativeAudioDiagnostics.describe(state: library.state, ids: [id], reason: "Audio preparation failed")
                throw BenKenAudioError.invalid(report + "\n" + error.localizedDescription)
            }
            let bus = buses.first { ($0["id"] as? Int) == (track["bus"] as? Int) }, output = stereo ? 1 : (bus?["output"] as? Int ?? track["output"] as? Int ?? 1)
            let groups = track["muteGroups"] as? [Int] ?? [], mutedGroups = opts["mutedGroups"] as? [Int] ?? []
            let muted = opts["masterMuted"] as? Bool == true || !Set(groups).isDisjoint(with: mutedGroups) || track["mute"] as? Bool == true || bus?["mute"] as? Bool == true || (solo && track["solo"] as? Bool != true)
            let gain = muted ? 0 : (track["gain"] as? Double ?? 1) * (bus?["gain"] as? Double ?? 1) * songGain * (opts["masterGain"] as? Double ?? 1)
            result.append(NativeTrack(id: track["id"] as? String ?? id, audio: audio, output: output, stereo: stereo || (bus?["stereo"] as? Bool ?? trackStereo), gain: Float(min(16, gain)), pan: Float(track["pan"] as? Double ?? 0), eq: try NativeTrackEQ(saved: track["eq"])))
        }
        return result
    }
    /// Populate only on-disk audio caches. Do not connect, stop or start an audio output.
    func prepareFilesOnly() async throws {
        _ = try await preparedTracks(0)
        preparationProgress=1;preparationPhase="Ready on this device"
    }
    func prepare(offline: Bool = false, reserveOutputs: Bool = false) async {
        guard !busy, !playing, library != nil else { return }
        busy = true; preparationProgress = 0; preparationPhase = "Opening audio output…"; generation += 1; let token = generation; status = "Preparing original audio at the selected tempo and key…"
        defer { if token == generation { busy = false } }
        do {
            transport.stop(); duration = 0; position = 0
            #if os(iOS)
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setPreferredSampleRate(48_000)
            try session.setPreferredIOBufferDuration(Double(UserDefaults.standard.object(forKey: "benken-buffer-frames") as? Int ?? 1024) / 48_000)
            try session.setActive(true)
            if !stereo { let outputs = min(32, session.maximumOutputNumberOfChannels); if outputs > 0 { try session.setPreferredOutputNumberOfChannels(outputs) } }
            #endif
            let tracks = try await preparedTracks(selected)
            guard token == generation else { return }
            let click = playback["click"] as? [String: Any] ?? [:], opts = state["opts"] as? [String: Any] ?? [:], buses = opts["audioBuses"] as? [[String: Any]] ?? []
            let clickBus = buses.first { $0["id"] as? Int == (click["bus"] as? Int ?? 2) }
            let clickOutput = (audibleClick && countBars > 0 || continuousClick) ? (clickBus?["output"] as? Int ?? 3) : 2
            let needed = stereo ? 2 : max(clickOutput, tracks.map { $0.output + ($0.stereo ? 1 : 0) }.max() ?? 2)
            let available = Int(transport.engine.outputNode.outputFormat(forBus: 0).channelCount)
            guard offline || needed <= available else { throw BenKenAudioError.invalid("Live / USB needs \(needed) outputs, but the connected audio device currently provides \(available). Check the USB connection and press REFRESH OUTPUTS. Your routing has been kept.") }
            preparationPhase = "Connecting audio outputs…"
            let requested = reserveOutputs && !stereo && !offline ? min(32, available) : needed
            try await transport.load(tracks, channels: requested, offline: offline, stereoOutput: stereo)
            preparationProgress = 1; preparationPhase = "Ready"
            duration = transport.duration; position = 0; status = "Ready · \(tracks.count) tracks · \(transposingCount) follow key · 48 kHz · \(needed) outputs"
        } catch { status = error.localizedDescription }
    }
    func saveSettings() async {
        guard !playing, !busy, !receiver, var value = library else { return }
        do {
            var db = state, all = songs, changed = song, pb = playback
            var tempo = pb["tempo"] as? [String: Any] ?? [:]; let original = tempo["originalBpm"] as? Double ?? bpm
            tempo["originalBpm"] = original; tempo["targetBpm"] = original * rate; pb["tempo"] = tempo; pb["transpose"] = pitch
            var click = pb["click"] as? [String: Any] ?? [:]; click["bpm"] = bpm; click["countInBars"] = countBars; click["countInSound"] = audibleClick; click["continuous"] = continuousClick; pb["click"] = click
            changed["playback"] = pb; all[selected] = changed; db["songs"] = all; value.state = try JSONSerialization.data(withJSONObject: db, options: .sortedKeys); try value.save(at: root); library = value
            await prepare()
        } catch { status = error.localizedDescription }
    }
    func play(region: Bool = false) {
        guard !busy else { return }
        if playing { transport.pause(); playing = false; status = "Paused"; return }
        guard duration > 0 else { return }
        do {
            let end: Double?, start: Double
            if region, regions.indices.contains(regionIndex), let a = regions[regionIndex]["start"] as? Double, let b = regions[regionIndex]["end"] as? Double { start = a / rate; end = b / rate } else { start = position; end = nil }
            let click = playback["click"] as? [String: Any] ?? [:], opts = state["opts"] as? [String: Any] ?? [:], buses = opts["audioBuses"] as? [[String: Any]] ?? []
            let clickBus = buses.first { $0["id"] as? Int == (click["bus"] as? Int ?? 2) }, output = stereo ? 1 : clickBus?["output"] as? Int ?? 3
            let count = practice ? (region ? click["regionCountInBars"] as? Int ?? countBars : countBars) : 0
            let beat = click["beatsPerBar"] as? Int ?? 4
            let follow = click["followSongBpm"] as? Bool != false, tempo = playback["tempo"] as? [String: Any] ?? [:], actualBpm = follow ? tempo["targetBpm"] as? Double ?? bpm : bpm
            let cfg = NativeClick(bpm: actualBpm, beats: beat, bars: count, audible: audibleClick, continuous: continuousClick, output: output, gain: Float(click["volume"] as? Double ?? 0.12), stereo: stereo, sound: click["sound"] as? String ?? "sine")
            _ = try transport.play(position: start, stopAt: end, click: cfg); playing = true; status = count > 0 ? "Count-in · \(count) bars" : "Playing"
        } catch { transport.pause(); status = error.localizedDescription; playing = false }
    }
    func stop() { transport.stop(); playing = false; position = 0; if duration > 0 { status = "Stopped" } }
    func chooseFolder(_ url: URL) {
        guard !playing, !busy else { return }
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        do {
            let bookmark = try url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil)
            preferences.set(bookmark, forKey: "nativeSyncFolder"); folder = url; folderName = url.lastPathComponent; lastRevision = nil; lastPublishedState = nil; syncStatus = "Folder selected. Choose SEND on one device and RECEIVE on the other."
        } catch { syncStatus = error.localizedDescription }
    }
    func setSyncOptions() {
        saveSyncChoices()
        Task { await sync() }
    }
    @discardableResult func sync(force: Bool = false) async -> Bool {
        guard (syncEnabled || force), !externalPlaybackBusy, !syncBusy, !busy, !playing, let folder else { return false }
        syncBusy = true; busy = true
        let access = folder.startAccessingSecurityScopedResource(); defer { if access { folder.stopAccessingSecurityScopedResource() }; syncBusy = false; busy = false }
        do {
            let store = ConcertSyncStore(root: folder), current = try await Task.detached { try store.head() }.value
            if publisher {
                guard let library else { throw BenKenAudioError.invalid("Send a concert to the native player first.") }
                try library.validate()
                guard current == nil || current?.publisher == device || force else { throw BenKenAudioError.invalid("The sync direction changed on your other device. Choose the receiving direction here.") }
                if current?.state != String(data: library.state, encoding: .utf8) || current == nil || current?.publisher != device {
                    let assets = library.assets.map { (id: $0.key, name: library.names[$0.key] ?? $0.value.lastPathComponent, url: $0.value) }, device = self.device
                    let revision = try await Task.detached { try store.publish(state: library.state, assets: assets, device: device, expectedParent: current?.id) }.value
                    lastRevision = revision.id; lastPublishedState = library.state
                } else { lastRevision = current?.id }
                let acknowledgements = try store.acknowledgements().filter { $0.device != device && $0.revision == lastRevision }
                syncStatus = acknowledgements.isEmpty ? "Concert sent. Open BenKen on your other device and press SYNC." : "Your other device has this concert. Last confirmed \(acknowledgements.map(\.checked).max()!.formatted())"
            } else if let revision = current {
                if revision.id != lastRevision || force {
                    syncStatus = "Downloading and checking concert files…"
                    let root = self.root
                    let value = try await Task.detached { let files = try store.verify(revision); return try NativeLibrary.install(state: Data(revision.state.utf8), originals: files.map { (id: $0.0.id, name: $0.0.name, url: $0.1) }, root: root, commit: false) }.value
                    syncStatus = "Preparing all songs for offline playback…"
                    let candidateState = try JSONSerialization.jsonObject(with: value.state) as! [String: Any]
                    let candidateSongs = candidateState["songs"] as! [[String: Any]]
                    for i in candidateSongs.indices { if externalPlaybackBusy { throw CancellationError() }; _ = try await preparedTracks(i, from: value, parsedState: candidateState) }
                    try value.save(at: root)
                    transport.stop(); duration = 0; position = 0; library = value; selected = playlist.first ?? 0; selectedEntry = 0; readSettings()
                    let device = self.device
                    try await Task.detached { try store.acknowledge(revision, device: device) }.value
                    let prepared = try await preparedTracks(selected)
                    let opts = state["opts"] as? [String: Any] ?? [:], buses = opts["audioBuses"] as? [[String: Any]] ?? [], click = playback["click"] as? [String: Any] ?? [:]
                    let clickBus = buses.first { $0["id"] as? Int == (click["bus"] as? Int ?? 2) }
                    let clickOutput = audibleClick && countBars > 0 || continuousClick ? clickBus?["output"] as? Int ?? 3 : 2
                    let needed = stereo ? 2 : max(clickOutput, prepared.map { $0.output + ($0.stereo ? 1 : 0) }.max() ?? 2)
                    try await transport.load(prepared, channels: needed, stereoOutput: stereo); duration = transport.duration; position = 0
                    lastRevision = revision.id
                }
                syncStatus = "Concert ready on this device."
            } else { syncStatus = "Waiting for a concert. On the other device, choose the sending direction and press SYNC."; return false }
            return true
        } catch { syncStatus = error.localizedDescription; return false }
    }
}
