import Foundation

public struct NativeLyricLine: Equatable, Sendable {
    public let words: String
    public let chords: String
}
public struct NativeLyricSection: Identifiable, Equatable, Sendable {
    public let id: Int
    public let label: String
    public let lines: [NativeLyricLine]
}
public struct NativeRegionTime: Equatable, Sendable {
    public let index: Int
    public let start: Double
    public let end: Double
    public init(index: Int, start: Double, end: Double) { self.index = index; self.start = start; self.end = end }
}
public enum NativeLyrics {
    private static let notes = ["C": 0, "D": 2, "E": 4, "F": 5, "G": 7, "A": 9, "B": 11]
    private static let sharps = ["C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"]
    private static let flats = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"]
    private static func replace(_ text: String, pattern: String, with value: String = "") -> String {
        guard let regex = try? NSRegularExpression(pattern: pattern, options: .caseInsensitive) else { return text }
        return regex.stringByReplacingMatches(in: text, range: NSRange(text.startIndex..., in: text), withTemplate: value)
    }
    private static func root(_ text: String, semitones: Int, preferFlats: Bool) -> String? {
        guard let regex = try? NSRegularExpression(pattern: "^([A-G])([#b♯♭]?)(.*)$"), let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)), let base = notes[(text as NSString).substring(with: match.range(at: 1))] else { return nil }
        let accidental = (text as NSString).substring(with: match.range(at: 2)), suffix = (text as NSString).substring(with: match.range(at: 3))
        guard suffix.range(of: "^(?:maj|min|dim|aug|sus|add|omit|no|m|M|Δ|ø|°|\\+|\\-|[0-9#b♯♭(),])*$", options: .regularExpression) != nil else { return nil }
        let adjustment = ["#", "♯"].contains(accidental) ? 1 : ["b", "♭"].contains(accidental) ? -1 : 0
        let value = ((base + adjustment + semitones) % 12 + 12) % 12
        return (preferFlats ? flats : sharps)[value] + suffix
    }
    public static func transpose(_ chord: String, semitones: Int, preferFlats: Bool = false) -> String {
        guard semitones % 12 != 0 else { return chord }
        let parts = chord.split(separator: "/", omittingEmptySubsequences: false).map(String.init)
        guard parts.count <= 2, let first = root(parts[0], semitones: semitones, preferFlats: preferFlats) else { return chord }
        guard parts.count == 2 else { return first }
        if let bass = root(parts[1], semitones: semitones, preferFlats: preferFlats) { return first + "/" + bass }
        if Int(parts[1]) != nil { return first + "/" + parts[1] }
        return chord
    }
    public static func line(_ text: String, semitones: Int, preferFlats: Bool = false) -> NativeLyricLine {
        let cleaned = replace(text, pattern: "\\{\\s*(?:/?color(?:\\s*:\\s*#[0-9a-f]{6})?|/?kor)\\s*\\}")
        let ns = cleaned as NSString
        let regex = try! NSRegularExpression(pattern: "\\[([^\\]\\r\\n]+)\\]")
        var words = "", chords = "", offset = 0
        for match in regex.matches(in: cleaned, range: NSRange(location: 0, length: ns.length)) {
            words += ns.substring(with: NSRange(location: offset, length: match.range.location - offset))
            let original = ns.substring(with: match.range(at: 1))
            // Unknown bracketed stage notes remain visible as text.
            guard root(original.split(separator: "/").first.map(String.init) ?? original, semitones: 0, preferFlats: false) != nil else {
                words += ns.substring(with: match.range); offset = NSMaxRange(match.range); continue
            }
            if chords.count < words.count { chords += String(repeating: " ", count: words.count - chords.count) }
            else if !chords.isEmpty { chords += " " }
            chords += transpose(original, semitones: semitones, preferFlats: preferFlats)
            offset = NSMaxRange(match.range)
        }
        words += ns.substring(from: offset)
        return NativeLyricLine(words: words, chords: chords)
    }
    public static func sections(_ text: String, semitones: Int = 0, preferFlats: Bool = false) -> [NativeLyricSection] {
        let header = try! NSRegularExpression(pattern: "^\\s*\\{\\s*([^}:]+?)\\s*(?::\\s*([^{}]*?))?\\s*\\}\\s*$", options: .caseInsensitive)
        let aliases = ["soc":"CHORUS", "start_of_chorus":"CHORUS", "sov":"VERSE", "start_of_verse":"VERSE", "sob":"BRIDGE", "start_of_bridge":"BRIDGE", "som":"MELODY", "start_of_melody":"MELODY"]
        let metadata = Set(["title","t","subtitle","st","artist","a","key","k","capo","tempo","time","duration","copyright","end_of_chorus","eoc","end_of_verse","eov","end_of_bridge","eob","end_of_melody","eom"])
        var result: [NativeLyricSection] = [], label = "", lines: [NativeLyricLine] = [], index = -1
        for raw in text.replacingOccurrences(of: "\r\n", with: "\n").components(separatedBy: "\n") {
            if let match = header.firstMatch(in: raw, range: NSRange(raw.startIndex..., in: raw)) {
                let ns = raw as NSString, key = ns.substring(with: match.range(at: 1)).trimmingCharacters(in: .whitespaces).lowercased()
                let value = match.range(at: 2).location == NSNotFound ? "" : ns.substring(with: match.range(at: 2))
                if ["section","comment","c"].contains(key) || aliases[key] != nil {
                    if index >= 0 || !lines.isEmpty { result.append(NativeLyricSection(id: index, label: label, lines: lines)) }
                    index += 1; label = value.isEmpty ? aliases[key] ?? "SECTION" : value; lines = []; continue
                }
                if metadata.contains(key) || ["color","/color","kor","/kor"].contains(key) { continue }
            }
            lines.append(line(raw, semitones: semitones, preferFlats: preferFlats))
        }
        if !lines.isEmpty || index >= 0 { result.append(NativeLyricSection(id: index, label: label, lines: lines)) }
        return result
    }
    public static func activeSection(position: Double, rate: Double, regions: [NativeRegionTime]) -> Int? {
        guard position.isFinite, rate.isFinite, rate > 0 else { return nil }
        let sourcePosition = position * rate
        return regions.first { $0.index >= 0 && $0.start.isFinite && $0.end.isFinite && $0.start <= sourcePosition && sourcePosition < $0.end }?.index
    }
}
