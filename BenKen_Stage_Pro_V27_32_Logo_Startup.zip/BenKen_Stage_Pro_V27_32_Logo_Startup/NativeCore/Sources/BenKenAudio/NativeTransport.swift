import AVFoundation
import Accelerate
import AudioToolbox
import Foundation

public struct NativeTrack: Sendable {
    public var id: String
    public var audio: PreparedAudio
    public var output: Int
    public var stereo: Bool
    public var gain: Float
    public var pan: Float
    public var eq: NativeTrackEQ
    public init(id: String, audio: PreparedAudio, output: Int = 1, stereo: Bool = true, gain: Float = 1, pan: Float = 0, eq: NativeTrackEQ = NativeTrackEQ()) {
        self.id = id; self.audio = audio; self.output = output; self.stereo = stereo; self.gain = gain; self.pan = pan; self.eq = eq
    }
}

public struct NativeClick: Sendable {
    public var stereo: Bool
    public var sound: String
    public var bpm: Double, beats: Int, bars: Int, audible: Bool, continuous: Bool, output: Int, gain: Float
    public init(bpm: Double = 120, beats: Int = 4, bars: Int = 0, audible: Bool = false, continuous: Bool = false, output: Int = 1, gain: Float = 0.12, stereo: Bool = false, sound: String = "sine") {
        self.sound = sound; self.bpm = bpm; self.beats = beats; self.bars = bars; self.audible = audible; self.continuous = continuous; self.output = output; self.gain = gain; self.stereo = stereo
    }
}

/// File streaming with one shared host clock. Time/pitch processing is done before play.
/// All graph mutations are on the main actor; no file reads or bridge calls in render callbacks.
@MainActor public final class NativeTransport {
    public let engine = AVAudioEngine()
    public private(set) var tracks: [NativeTrack] = []
    public private(set) var playing = false
    public private(set) var duration: Double = 0
    public private(set) var position: Double = 0
    public private(set) var channels = 2
    public var midiClock: NativeMIDIClock?
    public var onEnded: ((Bool) -> Void)?
    public var onInterruption: ((String) -> Void)?
    private var players: [AVAudioPlayerNode] = []
    private var equalizers: [AVAudioUnitEQ] = []
    private var trackProbes: [NativeSignalProbe] = []
    private var clickPlayer: AVAudioPlayerNode?
    private var clickOffset = 0
    private var metronomeEnd = 0.0
    public var metronomeRunning: Bool { clickPlayer?.isPlaying == true && Self.now < metronomeEnd }
    private var files: [AVAudioFile] = []
    private var matrix: AVAudioUnit?
    private var macStereoMixer = false
    private var signalProbe = NativeSignalProbe()
    private var probeInstalled = false
    private var outputSignalProbe=NativeSignalProbe()
    private var outputProbeInstalled=false
    private var startedAt = 0.0, startedOffset = 0.0
    private var stopAt: Double?, serial = 0, pending = 0
    private var inputOffsets: [Int] = []
    private var observer: NSObjectProtocol?
    private var sessionObservers: [NSObjectProtocol] = []
    private var loadedRoute = ""
    public static let backgroundRenderFrames: AVAudioFrameCount = 4096
    private var signalProbesEnabled = false
    private func routeKey() -> String {
        #if os(iOS)
        let s=AVAudioSession.sharedInstance();return s.currentRoute.outputs.map(\.uid).sorted().joined(separator:"|")+"|\(s.sampleRate)|\(s.outputNumberOfChannels)"
        #else
        let f=engine.outputNode.outputFormat(forBus:0);return "\(f.sampleRate)|\(f.channelCount)"
        #endif
    }
    public static var now: Double { AVAudioTime.seconds(forHostTime: mach_absolute_time()) }
    public init() {
        observer = NotificationCenter.default.addObserver(forName: .AVAudioEngineConfigurationChange, object: engine, queue: .main) { [weak self] _ in
            Task { @MainActor in guard let self, self.playing || self.metronomeRunning else { return };if self.engine.isRunning && self.routeKey()==self.loadedRoute{return}; self.pause(); self.onInterruption?("Audio device changed. Check the outputs and prepare the song again.") }
        }
    }
    deinit { if let observer { NotificationCenter.default.removeObserver(observer) }; sessionObservers.forEach { NotificationCenter.default.removeObserver($0) } }
    public func observeSession() {
        #if os(iOS)
        for name in [AVAudioSession.interruptionNotification, AVAudioSession.routeChangeNotification, AVAudioSession.mediaServicesWereResetNotification] {
            sessionObservers.append(NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { [weak self] notification in
                if notification.name == AVAudioSession.routeChangeNotification {
                    Task { @MainActor in guard let self,!self.tracks.isEmpty,!self.loadedRoute.isEmpty,self.routeKey() != self.loadedRoute else{return};self.pause();self.onInterruption?("Audio output changed. Check the interface and press REFRESH OUTPUTS. Playback will not restart automatically.") };return
                }
                if notification.name == AVAudioSession.interruptionNotification, (notification.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt) != AVAudioSession.InterruptionType.began.rawValue { return }
                Task { @MainActor in guard let self else { return }; self.pause(); self.onInterruption?("Audio session changed or was interrupted. Check the interface and prepare the song again.") }
            })
        }
        #endif
    }
    public var currentTime: Double { playing ? min(stopAt ?? duration, startedOffset + max(0, Self.now - startedAt)) : position }
    public var countInRemaining: Double { playing ? max(0, startedAt - Self.now) : 0 }
    public var countingIn: Bool { playing && Self.now < startedAt }
    public func load(_ tracks: [NativeTrack], channels requested: Int = 2, offline: Bool = false, stereoOutput: Bool = false, renderSampleRate: Double = AudioPreparation.sampleRate) async throws {
        guard tracks.count <= 32 else { throw BenKenAudioError.invalid("Maximum 32 audio tracks per song.") }
        stop(); let loadToken = serial; engine.stop()
        if outputProbeInstalled { engine.mainMixerNode.removeTap(onBus:0);outputProbeInstalled=false };outputSignalProbe=NativeSignalProbe()
        if macStereoMixer { engine.disconnectNodeOutput(engine.mainMixerNode); macStereoMixer = false }
        if let clickPlayer { engine.detach(clickPlayer) }; clickPlayer = nil
        for eq in equalizers { eq.removeTap(onBus:0);engine.detach(eq) }; equalizers = [];trackProbes=[]
        for p in players { engine.detach(p) }; players = []; files = []; inputOffsets = []
        if let matrix { if probeInstalled { matrix.removeTap(onBus:0) }; engine.detach(matrix) }; matrix = nil; probeInstalled = false; signalProbe = NativeSignalProbe(alwaysOn: offline)
        outputSignalProbe = NativeSignalProbe(alwaysOn: offline)
        self.tracks = []; duration = 0
        guard !tracks.isEmpty else { return }
        let available = offline ? requested : Int(engine.outputNode.outputFormat(forBus: 0).channelCount)
        guard requested > 0, requested <= available, requested <= 32 else { throw BenKenAudioError.invalid("The selected output needs \(requested) channels; this audio device provides \(available).") }
        channels = requested
        for t in tracks {
            try t.eq.validate()
            guard t.output > 0, t.output + (t.stereo ? 1 : 0) <= channels, t.gain.isFinite, (0...16).contains(t.gain), t.pan.isFinite, (-1...1).contains(t.pan) else { throw BenKenAudioError.invalid("Check output routing and levels for \(t.id).") }
            let file = try AVAudioFile(forReading: t.audio.url)
            guard file.processingFormat.sampleRate == AudioPreparation.sampleRate, (1...2).contains(file.processingFormat.channelCount) else { throw BenKenAudioError.invalid("Prepare all tracks before playback.") }
            files.append(file)
        }
        let description = AudioComponentDescription(componentType: kAudioUnitType_Mixer, componentSubType: kAudioUnitSubType_MatrixMixer, componentManufacturer: kAudioUnitManufacturer_Apple, componentFlags: 0, componentFlagsMask: 0)
        let unit: AVAudioUnit = try await withCheckedThrowingContinuation { continuation in
            AVAudioUnit.instantiate(with: description, options: []) { unit, error in
                if let unit { continuation.resume(returning: unit) } else { continuation.resume(throwing: error ?? BenKenAudioError.invalid("Native output mixer could not start.")) }
            }
        }
        guard serial == loadToken else { throw CancellationError() }
        matrix = unit; engine.attach(unit)
        var buses = UInt32(tracks.count + 1)
        try status(AudioUnitSetProperty(unit.audioUnit, kAudioUnitProperty_ElementCount, kAudioUnitScope_Input, 0, &buses, UInt32(MemoryLayout<UInt32>.size)))
        var offset = 0
        for (i, file) in files.enumerated() {
            let p = AVAudioPlayerNode(); engine.attach(p); players.append(p); inputOffsets.append(offset)
            let eq = AVAudioUnitEQ(numberOfBands: 4)
            tracks[i].eq.apply(to: eq)
            eq.auAudioUnit.maximumFramesToRender = max(eq.auAudioUnit.maximumFramesToRender, Self.backgroundRenderFrames)
            engine.attach(eq); equalizers.append(eq)
            engine.connect(p, to: eq, format: file.processingFormat)
            engine.connect(eq, to: unit, fromBus: 0, toBus: AVAudioNodeBus(i), format: file.processingFormat)
            let trackProbe=NativeSignalProbe(alwaysOn:offline);trackProbes.append(trackProbe)
            eq.installTap(onBus:0,bufferSize:1024,format:nil){buffer,_ in trackProbe.record(buffer)}
            offset += Int(file.processingFormat.channelCount)
        }
        let click = AVAudioPlayerNode(); clickPlayer = click; engine.attach(click); clickOffset = offset
        engine.connect(click, to: unit, fromBus: 0, toBus: AVAudioNodeBus(tracks.count), format: AVAudioFormat(standardFormatWithSampleRate: AudioPreparation.sampleRate, channels: 1)!)
        offset += 1
        #if targetEnvironment(macCatalyst) || os(macOS)
        let stereoLayout=stereoOutput && requested == 2
        #else
        let stereoLayout=false
        #endif
        // Discrete labels are retained for USB buses; Mac stereo needs Left/Right labels.
        let layout = AVAudioChannelLayout(layoutTag: stereoLayout ? kAudioChannelLayoutTag_Stereo : kAudioChannelLayoutTag_DiscreteInOrder | UInt32(channels))!
        let output = AVAudioFormat(standardFormatWithSampleRate: AudioPreparation.sampleRate, channelLayout: layout)
        if offline {
            engine.connect(unit, to: engine.mainMixerNode, format: output)
            guard renderSampleRate.isFinite, (8000...192000).contains(renderSampleRate) else { throw BenKenAudioError.invalid("Invalid render output format.") }
            let renderFormat = AVAudioFormat(standardFormatWithSampleRate: renderSampleRate, channelLayout: layout)
            engine.connect(engine.mainMixerNode, to: engine.outputNode, format: renderFormat)
            try engine.enableManualRenderingMode(.offline, format: renderFormat, maximumFrameCount: 4096)
        } else {
            #if targetEnvironment(macCatalyst) || os(macOS)
            if stereoOutput && requested == 2 {
                // Main mixer adapts the 48 kHz source to the Mac's hardware format.
                // A nil output format leaves hardware-rate tracking with AVAudioEngine.
                engine.connect(unit, to: engine.mainMixerNode, format: output)
                engine.connect(engine.mainMixerNode, to: engine.outputNode, format: nil)
                engine.mainMixerNode.outputVolume = 1; macStereoMixer = true
            } else { engine.connect(unit, to: engine.outputNode, format: output) }
            #else
            engine.connect(unit, to: engine.outputNode, format: output)
            #endif
        }
        // iOS can increase its render slice in the background independently of
        // the user's preferred hardware buffer. Reserve before allocating resources.
        unit.auAudioUnit.maximumFramesToRender = max(unit.auAudioUnit.maximumFramesToRender, Self.backgroundRenderFrames)
        for player in players + [click] {
            player.auAudioUnit.maximumFramesToRender = max(player.auAudioUnit.maximumFramesToRender, Self.backgroundRenderFrames)
        }
        // Accessing mainMixerNode creates/connects an implicit mixer. Only touch
        // it on paths that already use it; iOS USB/stereo routes go directly out.
        if offline || macStereoMixer {
            engine.mainMixerNode.auAudioUnit.maximumFramesToRender = max(engine.mainMixerNode.auAudioUnit.maximumFramesToRender, Self.backgroundRenderFrames)
        }
        signalProbesEnabled = true
        // One output observation point, sampled only while a short UI lease is renewed.
        // Track taps share the short UI lease: no peak scans when the mixer is hidden.
        if signalProbesEnabled {
            if macStereoMixer { let out=outputSignalProbe;engine.mainMixerNode.installTap(onBus:0,bufferSize:1024,format:nil){buffer,_ in out.record(buffer)};outputProbeInstalled=true }
            if offline || !macStereoMixer {
                let probe = signalProbe
                unit.installTap(onBus:0,bufferSize:1024,format:nil) { buffer, _ in probe.record(buffer) }; probeInstalled = true
            }
        }
        engine.prepare(); try engine.start()
        // Matrix channels default to muted. Open input/output/master levels, then route explicitly.
        for i in 0..<offset { try parameter(scope: kAudioUnitScope_Input, element: UInt32(i), value: 1) }
        for i in 0..<channels { try parameter(scope: kAudioUnitScope_Output, element: UInt32(i), value: 1) }
        try parameter(scope: kAudioUnitScope_Global, element: UInt32.max, value: 1)
        self.tracks = tracks
        duration = files.map { Double($0.length) / $0.processingFormat.sampleRate }.max() ?? 0
        try update(tracks);loadedRoute=routeKey()
    }
    public func setOutputMetering(_ enabled: Bool) {
        trackProbes.forEach{$0.monitor(enabled)}
        signalProbe.monitor(enabled && !macStereoMixer)
        outputSignalProbe.monitor(enabled && macStereoMixer)
    }
    public func outputMeterState() -> [String: Any] {
        let reading = (macStereoMixer ? outputSignalProbe : signalProbe).recent()
        return ["available": signalProbesEnabled, "mode": "sampled-output", "frequency": 10,
                "peak": playing && engine.isRunning ? reading.peak : 0,
                "fresh": reading.fresh && playing && engine.isRunning]
    }
    public func trackMeterState() -> [[String:Any]] {
        zip(tracks,trackProbes).map {track,probe in
            let reading=probe.recent(),active=playing && engine.isRunning
            return ["id":track.id,"peak":active && reading.fresh ? reading.peak * track.gain : 0,"fresh":active && reading.fresh]
        }
    }
    public func audioDiagnostics() -> [String:Any] {
        let probe=signalProbe.snapshot(),outputProbe=outputSignalProbe.snapshot(), format=engine.outputNode.outputFormat(forBus:0)
        var info:[String:Any] = ["trackEQ":true,"enabledTrackEQs":tracks.filter { $0.eq.enabled }.count,"backgroundRenderFrames":matrix?.auAudioUnit.maximumFramesToRender ?? 0,"signalProbesEnabled":signalProbesEnabled,"outputMeter":outputMeterState(),"engineRunning":engine.isRunning,"playing":playing,"position":currentTime,"countingIn":countingIn,"outputChannels":format.channelCount,"outputSampleRate":format.sampleRate,"renderedFrames":probe.0,"mixerPeak":probe.1,"macStereoMixer":macStereoMixer,"outputMixerPeak":outputProbe.1,"outputRenderedFrames":outputProbe.0,"tracks":tracks.map{["id":$0.id,"gain":$0.gain,"output":$0.output,"stereo":$0.stereo]},"players":players.map{p -> [String:Any] in let time=p.lastRenderTime;return ["playing":p.isPlaying,"hasRenderTime":time != nil,"sampleTime":time.flatMap{($0.isSampleTimeValid || $0.isHostTimeValid) ? p.playerTime(forNodeTime:$0) : nil}?.sampleTime ?? -1]}]
        #if os(iOS)
        info["hardwareBufferSeconds"] = AVAudioSession.sharedInstance().ioBufferDuration
        info["route"] = AVAudioSession.sharedInstance().currentRoute.outputs.map{["name":$0.portName,"uid":$0.uid]}
        #else
        info["route"] = [["name":"System default output"]]
        #endif
        #if os(macOS) || targetEnvironment(macCatalyst)
        if let unit=engine.outputNode.audioUnit { var device:UInt32=0;var size=UInt32(MemoryLayout<UInt32>.size);let result=AudioUnitGetProperty(unit,kAudioOutputUnitProperty_CurrentDevice,kAudioUnitScope_Global,0,&device,&size);info["outputDeviceID"]=device;info["outputDeviceReadStatus"]=result }
        #endif
        return info
    }
    private func status(_ value: OSStatus) throws { if value != noErr { throw BenKenAudioError.invalid("Native audio error \(value).") } }
    private func parameter(scope: AudioUnitScope, element: UInt32, value: Float) throws {
        guard let matrix else { return }; try status(AudioUnitSetParameter(matrix.audioUnit, kMatrixMixerParam_Volume, scope, element, value, 0))
    }
    public func update(_ tracks: [NativeTrack]) throws {
        guard tracks.count == self.tracks.count else { throw BenKenAudioError.invalid("Prepare audio after changing track count.") }
        for t in tracks { try t.eq.validate() }
        for (index, t) in tracks.enumerated() {
            guard t.id == self.tracks[index].id, t.audio.url == self.tracks[index].audio.url, t.output > 0, t.output + (t.stereo ? 1 : 0) <= channels, t.gain.isFinite, (0...16).contains(t.gain), t.pan.isFinite, (-1...1).contains(t.pan) else { throw BenKenAudioError.invalid("Prepare audio after changing files or outputs.") }
            if t.eq != self.tracks[index].eq { t.eq.apply(to: equalizers[index]) }
            let count = Int(files[index].processingFormat.channelCount)
            for input in 0..<count { for output in 0..<channels {
                var gain: Float = 0
                let destination = t.output - 1
                if t.stereo {
                    if output == destination && input == 0 { gain = t.gain * (t.pan > 0 ? 1 - t.pan : 1) }
                    if output == destination + 1 && input == (count > 1 ? 1 : 0) { gain = t.gain * (t.pan < 0 ? 1 + t.pan : 1) }
                } else if output == destination { gain = t.gain / Float(count) }
                let address = UInt32(inputOffsets[index] + input) << 16 | UInt32(output)
                try parameter(scope: kAudioUnitScope_Global, element: address, value: gain)
            } }
        }
        self.tracks = tracks
    }
    @discardableResult public func play(position: Double? = nil, delay: Double = 0, stopAt: Double? = nil, click: NativeClick? = nil, offline: Bool = false, midiBpm: Double? = nil) throws -> Double {
        guard !players.isEmpty, delay.isFinite, (0...120).contains(delay) else { throw BenKenAudioError.invalid("Prepare audio before playing.") }
        pause()
        if let position { guard position.isFinite, position >= 0, position <= duration else { throw BenKenAudioError.invalid("Invalid playback position.") }; self.position = position }
        if self.position >= duration { self.position = 0 }
        let end = min(stopAt ?? duration, duration)
        guard end.isFinite, end > self.position else { throw BenKenAudioError.invalid("The selected region has no playable audio.") }
        self.stopAt = stopAt == nil ? nil : end
        if !engine.isRunning { try engine.start() }
        serial += 1; let token = serial
        let clickDelay = click.map { Double($0.bars * $0.beats) * 60 / $0.bpm } ?? delay
        guard clickDelay.isFinite, (0...300).contains(clickDelay) else { throw BenKenAudioError.invalid("Invalid count-in.") }
        startedAt = Self.now + 0.15 + clickDelay; startedOffset = self.position; pending = 0
        for (i, file) in files.enumerated() {
            let start = AVAudioFramePosition((self.position * file.processingFormat.sampleRate).rounded())
            let finish = min(file.length, AVAudioFramePosition((end * file.processingFormat.sampleRate).rounded()))
            guard finish > start else { continue }
            pending += 1
            players[i].scheduleSegment(file, startingFrame: start, frameCount: AVAudioFrameCount(finish - start), at: nil, completionCallbackType: .dataPlayedBack) { [weak self] _ in
                Task { @MainActor in
                    guard let self, self.serial == token, self.playing else { return }
                    self.pending -= 1
                    if self.pending == 0 { let practice = self.stopAt != nil; self.pause(); self.position = end; self.onEnded?(practice) }
                }
            }
        }
        guard pending > 0 else { throw BenKenAudioError.invalid("No audio in this region.") }
        if let click { try scheduleClick(click, musicTime: startedAt, offline: offline) }
        playing = true
        let at = offline ? nil : AVAudioTime(hostTime: AVAudioTime.hostTime(forSeconds: startedAt))
        for p in players { p.play(at: at) }
        if !offline,let clockBpm=midiBpm ?? click?.bpm {midiClock?.start(bpm:clockBpm,musicTime:startedAt,position:startedOffset,countIn:clickDelay,end:startedAt+end-startedOffset)}
        return startedAt
    }
    private func scheduleClick(_ click: NativeClick, musicTime: Double, offline: Bool, standalone: Bool = false, firstBeat: Int = 0) throws {
        guard ["sine", "wood", "bell"].contains(click.sound), (20...300).contains(click.bpm), (2...12).contains(click.beats), [0, 2, 4].contains(click.bars), click.output >= 1, (!(click.audible && click.bars > 0 || click.continuous) || click.output + (click.stereo ? 1 : 0) <= channels), click.gain.isFinite, (0...1).contains(click.gain), let player = clickPlayer else { throw BenKenAudioError.invalid("Invalid metronome settings or output.") }
        for output in 0..<channels { try parameter(scope: kAudioUnitScope_Global, element: UInt32(clickOffset) << 16 | UInt32(output), value: output == click.output - 1 || click.stereo && output == click.output ? click.gain : 0) }
        guard click.audible && click.bars > 0 || click.continuous else { return }
        let format = AVAudioFormat(standardFormatWithSampleRate: AudioPreparation.sampleRate, channels: 1)!
        let beatFrames = Int((60 / click.bpm * AudioPreparation.sampleRate).rounded())
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(beatFrames * click.beats))!; buffer.frameLength = buffer.frameCapacity
        let samples = buffer.floatChannelData![0]
        for i in 0..<Int(buffer.frameLength) { samples[i] = 0 }
        for beat in 0..<click.beats { for i in 0..<1680 {
            let phase = Double(i) / AudioPreparation.sampleRate
            let base = click.sound == "bell" ? 1760.0 : click.sound == "wood" ? 640.0 : 880.0
            let accented = (beat + firstBeat) % click.beats == 0
            let frequency = base * (accented ? 1.5 : 1.0)
            let wave = sin(2 * .pi * frequency * phase)
            let tone = click.sound == "wood" ? (2 / .pi) * asin(wave) : wave
            samples[beat * beatFrames + i] = Float(tone * (1 - Double(i) / 1680) * (accented ? 1 : 0.65))
        } }
        if click.audible { for _ in 0..<click.bars { player.scheduleBuffer(buffer, completionHandler: nil) } }
        if standalone {
            player.scheduleBuffer(buffer, at: nil, options: .loops, completionHandler: nil)
        } else if click.continuous {
            // A finite queue stops on the audio thread, even if the UI thread is busy.
            let musicFrames = Int(max(0, startedAt + (self.stopAt ?? duration) - startedOffset - musicTime) * AudioPreparation.sampleRate)
            let fullBars = musicFrames / Int(buffer.frameLength), tailFrames = musicFrames % Int(buffer.frameLength)
            for _ in 0..<fullBars { player.scheduleBuffer(buffer, completionHandler: nil) }
            if tailFrames > 0 {
                let tail = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(tailFrames))!; tail.frameLength = tail.frameCapacity
                tail.floatChannelData![0].update(from: samples, count: tailFrames)
                player.scheduleBuffer(tail, completionHandler: nil)
            }
        }
        metronomeEnd = standalone ? .infinity : click.continuous ? startedAt + (self.stopAt ?? duration) - startedOffset : musicTime
        let start = click.audible ? musicTime - Double(click.bars * beatFrames * click.beats) / AudioPreparation.sampleRate : musicTime
        player.play(at: offline ? nil : AVAudioTime(hostTime: AVAudioTime.hostTime(forSeconds: start)))
    }
    /// Changes only the click node; backing-track playback and its host clock are untouched.
    @discardableResult public func startMetronome(_ config: NativeClick, offline: Bool = false) throws -> Double {
        guard clickPlayer != nil, !loadedRoute.isEmpty else { throw BenKenAudioError.invalid("Prepare the song before starting the metronome.") }
        guard offline || routeKey() == loadedRoute else { throw BenKenAudioError.invalid("Audio output changed. Prepare the song again.") }
        stopMetronome()
        var click=config;click.bars=0;click.audible=false;click.continuous=true
        if !engine.isRunning { try engine.start() }
        var at=Self.now + 0.05, beat=0
        if playing {
            let anchor=startedAt-startedOffset, period=60 / click.bpm
            beat=max(0,Int(ceil((at-anchor)/period)));at=anchor+Double(beat)*period
        }
        do { try scheduleClick(click,musicTime:at,offline:offline,standalone:!playing,firstBeat:beat % click.beats) }
        catch { stopMetronome();throw error }
        return max(0,at-Self.now)
    }
    public func stopMetronome() { clickPlayer?.stop();metronomeEnd=0 }
    public func pause() { midiClock?.stop();stopMetronome(); if playing { position = currentTime }; playing = false; serial += 1; for p in players { p.stop() } }
    public func stop() { pause(); position = 0; stopAt = nil }
}

// The tap never waits for the UI. Scanning is capped at 10 Hz for live playback.
// A lease expires when the UI stops polling (including background/suspended WebKit).
final class NativeSignalProbe: @unchecked Sendable {
    private let lock = NSLock()
    private let alwaysOn: Bool
    private var frames: Int64 = 0
    private var peak: Float = 0, latest: Float = 0
    private var recordedAt = 0.0, enabledUntil = 0.0, nextScan = 0.0
    init(alwaysOn: Bool = false) { self.alwaysOn = alwaysOn }
    func monitor(_ enabled: Bool) {
        let now = ProcessInfo.processInfo.systemUptime
        lock.lock(); defer { lock.unlock() }
        enabledUntil = enabled ? now + 0.6 : 0
        if !enabled { latest = 0; recordedAt = 0 }
    }
    func record(_ buffer: AVAudioPCMBuffer) {
        let now = ProcessInfo.processInfo.systemUptime
        guard lock.try() else { return }
        frames += Int64(buffer.frameLength)
        guard alwaysOn || (now <= enabledUntil && now >= nextScan) else { lock.unlock(); return }
        nextScan = now + (alwaysOn ? 0 : 0.1)
        lock.unlock()
        guard buffer.frameLength > 0, let data = buffer.floatChannelData else { return }
        let channels = Int(buffer.format.channelCount), stride = buffer.format.isInterleaved ? channels : 1
        var value: Float = 0
        for c in 0..<channels {
            let samples = buffer.format.isInterleaved ? data[0].advanced(by: c) : data[c]
            var channelPeak: Float = 0
            vDSP_maxmgv(samples, vDSP_Stride(stride), &channelPeak, vDSP_Length(buffer.frameLength))
            if channelPeak.isFinite { value = max(value, channelPeak) }
        }
        if lock.try() {
            peak = max(peak, value)
            if now >= recordedAt { latest = value; recordedAt = now }
            lock.unlock()
        }
    }
    func recent() -> (peak: Float, fresh: Bool) {
        let now = ProcessInfo.processInfo.systemUptime
        lock.lock(); defer { lock.unlock() }
        let fresh = recordedAt > 0 && now - recordedAt < 0.4 && (alwaysOn || now <= enabledUntil)
        return (fresh ? latest : 0, fresh)
    }
    func snapshot() -> (Int64, Float) { lock.lock(); defer { lock.unlock() }; return (frames, peak) }
}
