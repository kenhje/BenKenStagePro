import Foundation
public enum TransposeSelection {
    public static func validate(count: Int, semitones: Double) throws {
        if semitones != 0 && count > 3 { throw BenKenAudioError.invalid("Choose at most three tracks to transpose. Turn off Follow key for drums or click under Tempo & transpose. All four tracks can still play and follow tempo.") }
    }
    public static func follows(name: String, fileName: String, explicit: Bool?) -> Bool {
        if let explicit { return explicit }
        return (name + " " + fileName).range(of: "click|clix|klikk|metronom|drums?|tromm|percussion", options: .regularExpression.union(.caseInsensitive)) == nil
    }
}
