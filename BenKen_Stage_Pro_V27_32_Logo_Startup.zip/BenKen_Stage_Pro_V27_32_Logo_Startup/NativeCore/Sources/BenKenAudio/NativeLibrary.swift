import Foundation

public enum NativeAudioDiagnostics {
    public static func describe(state: Data, ids: [String], reason: String = "Audio file missing locally") -> String {
        let value = (try? JSONSerialization.jsonObject(with: state)) as? [String: Any] ?? [:]
        let wanted = Set(ids), songs = value["songs"] as? [[String: Any]] ?? []
        var lines: [String] = []
        for song in songs {
            let playback = song["playback"] as? [String: Any] ?? [:]
            for track in playback["tracks"] as? [[String: Any]] ?? [] where wanted.contains(track["assetId"] as? String ?? "") {
                let title = song["title"] as? String ?? "Untitled song", name = track["name"] as? String ?? "Audio track", file = track["fileName"] as? String ?? "Original filename unavailable"
                lines.append("• \(title) → \(name) → \(file)")
            }
        }
        if lines.isEmpty { lines = ids.map { "Audio reference: " + $0 } }
        let shown = Array(lines.prefix(200)) + (lines.count > 200 ? ["… \(lines.count - 200) more references."] : [])
        return reason + ":\n" + shown.joined(separator: "\n")
    }
}

public struct NativeLibrary: Codable, Sendable {
    public var state: Data
    public var assets: [String: URL]
    public var names: [String: String]
    public init(state: Data, assets: [String: URL], names: [String: String]) { self.state = state; self.assets = assets; self.names = names }
    public func validate() throws {
        guard let value = try JSONSerialization.jsonObject(with: state) as? [String: Any], let songs = value["songs"] as? [[String: Any]], !songs.isEmpty, songs.count <= 10000 else { throw BenKenAudioError.invalid("Choose a concert with at least one song.") }
        var required = Set<String>(), missing = Set<String>()
        for song in songs {
            let playback = song["playback"] as? [String: Any] ?? [:]
            let tracks = playback["tracks"] as? [[String: Any]] ?? []
            guard tracks.count <= 32 else { throw BenKenAudioError.invalid("Maximum 32 tracks per song.") }
            for track in tracks {
                guard let id = track["assetId"] as? String else { throw BenKenAudioError.invalid("Invalid audio entry in " + (song["title"] as? String ?? "Untitled song")) }
                required.insert(id)
                if let url = assets[id], FileManager.default.fileExists(atPath: url.path) {} else { missing.insert(id) }
            }
        }
        if !missing.isEmpty { throw BenKenAudioError.invalid(NativeAudioDiagnostics.describe(state: state, ids: missing.sorted()) + "\nSend the concert again with its original audio.") }
        guard required == Set(assets.keys) else { throw BenKenAudioError.invalid("The concert audio catalog does not match the song library.") }
    }
    public static func install(state: Data, originals: [(id: String, name: String, url: URL)], root: URL, commit: Bool = true) throws -> NativeLibrary {
        let directory = root.appendingPathComponent("originals", isDirectory: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var assets: [String: URL] = [:], names: [String: String] = [:]
        for original in originals {
            guard assets[original.id] == nil else { throw BenKenAudioError.invalid("Duplicate concert audio identifier.") }
            let digest = try AudioPreparation.digest(original.url)
            let ext = URL(fileURLWithPath: original.name).pathExtension.lowercased()
            let safeExtension = ["mp3", "wav", "caf", "m4a", "aif", "aiff"].contains(ext) ? ext : "bin"
            let destination = directory.appendingPathComponent(digest + "." + safeExtension)
            if !FileManager.default.fileExists(atPath: destination.path) { try FileManager.default.copyItem(at: original.url, to: destination) }
            guard try AudioPreparation.digest(destination) == digest else { throw BenKenAudioError.invalid("Original audio verification failed.") }
            assets[original.id] = destination; names[original.id] = original.name
        }
        let value = NativeLibrary(state: state, assets: assets, names: names); try value.validate()
        if !commit { return value }
        let library = root.appendingPathComponent("library.json"), backup = root.appendingPathComponent("library.previous.json")
        if FileManager.default.fileExists(atPath: library.path) { try Data(contentsOf: library).write(to: backup, options: .atomic) }
        try JSONEncoder().encode(value).write(to: library, options: .atomic)
        return value
    }
    public func save(at root: URL) throws {
        try validate(); let url = root.appendingPathComponent("library.json")
        if FileManager.default.fileExists(atPath: url.path) { try Data(contentsOf: url).write(to: root.appendingPathComponent("library.previous.json"), options: .atomic) }
        try JSONEncoder().encode(self).write(to: url, options: .atomic)
    }
}
