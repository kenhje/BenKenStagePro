import Foundation

public enum NativeMIDIAction: String, Codable, CaseIterable, Sendable {
    case start, playPause, stop, next, previous, beginning
    public var label: String {
        switch self { case .start:return "Start"; case .playPause:return "Play / pause"; case .stop:return "Stop"; case .next:return "Next song"; case .previous:return "Previous song"; case .beginning:return "Back to start" }
    }
}
public struct NativeMIDIBinding: Codable, Equatable, Sendable {
    public var action: NativeMIDIAction
    public var type: String
    public var channel: Int
    public var number: Int
    public init(action: NativeMIDIAction, type: String, channel: Int, number: Int) { self.action = action; self.type = type; self.channel = channel; self.number = number }
    public var valid: Bool { ["note","cc","pc"].contains(type) && (1...16).contains(channel) && (0...127).contains(number) }
    public var description: String { "\(type.uppercased()) · CH \(channel) · \(type == "pc" ? number + 1 : number)" }
}
/// Called only on the app's main actor. MIDI input never runs on the audio rendering thread.
public final class NativeMIDIRouter {
    public private(set) var bindings: [NativeMIDIBinding]
    public private(set) var learning: NativeMIDIAction?
    public private(set) var status = "Choose an action and press LEARN, then press the pedal."
    private var held = Set<String>(), programTimes: [String: Double] = [:]
    public init(bindings: [NativeMIDIBinding] = []) { self.bindings = Array(bindings.filter(\.valid).prefix(32)) }
    public func resetInputState() { held = []; programTimes = [:] }
    public func learn(_ action: NativeMIDIAction) { learning = action; status = "Press the pedal for \(action.label)…" }
    public func cancelLearning() { learning = nil; status = "MIDI Learn cancelled." }
    public func clear() { learning = nil; bindings = []; held = []; programTimes = [:]; status = "Native MIDI assignments cleared." }
    public func receive(_ bytes: [UInt8], source: String, now: Double) -> NativeMIDIAction? {
        guard bytes.count >= 2, bytes[0] >= 0x80, bytes[0] < 0xf0, bytes[1] < 0x80 else { return nil }
        let kind = bytes[0] & 0xf0, channel = Int(bytes[0] & 0x0f) + 1, number = Int(bytes[1])
        guard [UInt8(0x80),0x90,0xb0,0xc0].contains(kind), kind == 0xc0 || bytes.count >= 3 && bytes[2] < 0x80 else { return nil }
        let type = kind == 0xc0 ? "pc" : kind == 0xb0 ? "cc" : "note"
        let pressed = kind != 0x80 && (kind == 0xc0 || bytes[2] > 0)
        let key = "\(source)|\(type)|\(channel)|\(number)"
        if !pressed { held.remove(key); return nil }
        if type == "pc" { if let last = programTimes[key], now - last < 0.2 { return nil }; programTimes[key] = now }
        else { guard held.insert(key).inserted else { return nil } }
        if held.count > 512 { held = [key] }; if programTimes.count > 512 { programTimes = [key:now] }
        if let action = learning {
            if let conflict = bindings.first(where: { $0.type == type && $0.channel == channel && $0.number == number && $0.action != action }) {
                status = "Already assigned to \(conflict.action.label). Clear assignments or use another pedal."; return nil
            }
            bindings.removeAll { $0.action == action }
            bindings.append(NativeMIDIBinding(action: action, type: type, channel: channel, number: number))
            learning = nil; status = "\(action.label) assigned."; return nil
        }
        let action = bindings.first { $0.type == type && $0.channel == channel && $0.number == number }?.action
        if let action { status = "MIDI · \(action.label)" }; return action
    }
}

public enum NativePlaylist {
    public static func order(songCount: Int, selectedSet: String, sets: [String: [Int]]) -> [Int] {
        let raw = !selectedSet.isEmpty ? sets[selectedSet] ?? [] : Array(0..<max(0,songCount))
        return raw.filter { $0 >= 0 && $0 < songCount }
    }
}
