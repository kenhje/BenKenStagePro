import AVFoundation
import Foundation
import CoreFoundation

/// Same four stored bands and explicit opt-in as the browser EQ.
public struct NativeTrackEQ: Sendable, Equatable {
    public var enabled = false
    public var gains: [Float] = [0, 0, 0, 0]
    public var frequencies: [Float] = [120, 1000, 3000, 8000]
    public var widths: [Float] = [1, 1.384522, 1.384522, 1]
    public init() {}
    public init(saved: Any?) throws {
        self.init()
        guard let saved else { return }
        guard let values = saved as? [String: Any] else { throw BenKenAudioError.invalid("Invalid track EQ settings.") }
        if let value = values["enabled"], !(value is Bool) { throw BenKenAudioError.invalid("EQ must be on or off.") }
        enabled = values["enabled"] as? Bool == true && values["optInVersion"] as? Int == 1
        func read(_ key: String, _ fallback: Float, _ range: ClosedRange<Float>) throws -> Float {
            guard let raw = values[key] else { return fallback }
            guard let number = raw as? NSNumber, CFGetTypeID(number) != CFBooleanGetTypeID() else { throw BenKenAudioError.invalid("Invalid EQ value: \(key).") }
            let value = number.floatValue
            guard value.isFinite, range.contains(value) else { throw BenKenAudioError.invalid("EQ value out of range: \(key).") }
            return value
        }
        for (i, name) in ["low", "mid", "mid2", "high"].enumerated() {
            gains[i] = try read(name, gains[i], -15...15)
            frequencies[i] = try read(name + "Hz", frequencies[i], 20...20000)
            if i == 1 || i == 2 { widths[i] = try read(name + "Width", widths[i], 0.1...4) }
        }
    }
    func validate() throws {
        guard gains.count == 4, frequencies.count == 4, widths.count == 4,
              gains.allSatisfy({ $0.isFinite && (-15...15).contains($0) }),
              frequencies.allSatisfy({ $0.isFinite && (20...20000).contains($0) }),
              widths.allSatisfy({ $0.isFinite && (0.1...4).contains($0) }) else { throw BenKenAudioError.invalid("Invalid track EQ settings.") }
    }
    @MainActor func apply(to unit: AVAudioUnitEQ) {
        let types: [AVAudioUnitEQFilterType] = [.lowShelf, .parametric, .parametric, .highShelf]
        for i in 0..<4 {
            let band = unit.bands[i]
            band.filterType = types[i]; band.frequency = frequencies[i]
            band.bandwidth = widths[i]; band.gain = gains[i]; band.bypass = !enabled
        }
        unit.globalGain = 0
        unit.bypass = !enabled
    }
}
