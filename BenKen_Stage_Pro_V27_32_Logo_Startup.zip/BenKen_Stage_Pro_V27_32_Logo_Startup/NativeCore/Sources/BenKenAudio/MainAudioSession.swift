import Foundation
import AVFoundation

/// Live matrix values share the same rules as the saved song, without decoding files again.
enum MainAudioMix {
    static func resolve(_ prepared: [NativeTrack], tracks: [[String: Any]], options: [String: Any], master: Double, stereo: Bool) throws -> [NativeTrack] {
        guard prepared.count == tracks.count, master.isFinite, (0...2).contains(master) else { throw BenKenAudioError.invalid("Prepare audio after changing tracks.") }
        let buses = options["audioBuses"] as? [[String: Any]] ?? [], solo = tracks.contains { $0["solo"] as? Bool == true }
        let groups = Set(options["mutedGroups"] as? [Int] ?? [])
        let global = options["masterGain"] as? Double ?? 1
        guard global.isFinite, (0...2).contains(global) else { throw BenKenAudioError.invalid("Invalid master level.") }
        return try zip(prepared, tracks).map { audio, track in
            guard track["id"] as? String == audio.id else { throw BenKenAudioError.invalid("Prepare audio after changing track order.") }
            let bus = buses.first { $0["id"] as? Int == track["bus"] as? Int }
            let gain = track["gain"] as? Double ?? 1, busGain = bus?["gain"] as? Double ?? 1, pan = track["pan"] as? Double ?? 0
            guard gain.isFinite, busGain.isFinite, pan.isFinite, (0...2).contains(gain), (0...2).contains(busGain), (-1...1).contains(pan) else { throw BenKenAudioError.invalid("Invalid track or bus level.") }
            let muted = options["masterMuted"] as? Bool == true || track["mute"] as? Bool == true || bus?["mute"] as? Bool == true || !groups.isDisjoint(with: track["muteGroups"] as? [Int] ?? []) || (solo && track["solo"] as? Bool != true)
            var value = audio
            value.gain = muted ? 0 : Float(gain * busGain * master * global)
            value.eq = try NativeTrackEQ(saved: track["eq"])
            value.pan = Float(pan); value.output = stereo ? 1 : bus?["output"] as? Int ?? track["output"] as? Int ?? 1
            value.stereo = stereo || (bus?["stereo"] as? Bool ?? track["stereo"] as? Bool ?? true)
            return value
        }
    }
}

/// Separate from concert sync: only the current main-interface song is installed here.
@MainActor final class MainAudioSession {
    private struct Transfer: @unchecked Sendable {
        let token: String, folder: URL, state: Data, catalog: [[String: Any]]
        var files: [String: URL] = [:], handles: [String: FileHandle] = [:], lengths: [String: Int] = [:]
    }
    private var warmTransfer: Transfer?, warmModel: NativeConcertModel?
    private var warmToken = "", warmPreparing = false, warmAutomatic = false
    private var warmWork: Task<[String: Any], Error>?
    private var reusedAssets = 0
    private var transfer: Transfer?, model: NativeConcertModel?, preparingModel: NativeConcertModel?
    private(set) var token = ""
    private(set) var preparing = false
    private var endSerial = 0, ended = false, practiceEnd = false
    private let root: URL
    private var preparationTimings: [String: Double] = [:]
    private var lastInterruption = ""
    private var lastAudioError = ""
    private var waveformTask: Task<[Float], Error>?
    private var waveformCache: [String: [Float]] = [:]
    private let midiClock: NativeMIDIClock
    private let offline: Bool
    init(root: URL? = nil, offline: Bool = false) { self.midiClock=NativeMIDIClock(persist:!offline);self.offline = offline; self.root = root ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("BenKenMainAudio") }
    var playing: Bool { model?.transport.playing == true }
    func pauseForTuner() { if !playing { model?.transport.engine.pause() } }
    func cancel() {
        waveformTask?.cancel(); waveformTask = nil; waveformCache.removeAll()
        token = ""; preparing = false; ended = false
        preparingModel?.setExternalPlaybackBusy(true); preparingModel?.transport.stop(); preparingModel = nil
        model?.transport.stop(); model = nil
        if let transfer { transfer.handles.values.forEach { try? $0.close() }; try? FileManager.default.removeItem(at: transfer.folder) }; transfer = nil
    }
    func state(metering: Bool? = nil) -> [String: Any] {
        let transport = model?.transport
        if let metering { transport?.setOutputMetering(metering) }
        return ["metronomeRunning": transport?.metronomeRunning ?? false, "preparationProgress": preparingModel?.preparationProgress ?? 0, "preparationPhase": preparingModel?.preparationPhase ?? (preparing ? "Verifying local audio…" : ""), "trackMeters":transport?.trackMeterState() ?? [], "meters": transport?.outputMeterState() ?? ["available":false,"peak":0], "token": token, "ready": model?.duration ?? 0 > 0, "preparing": preparing, "playing": playing,
                "position": transport?.currentTime ?? 0, "duration": model?.duration ?? 0,
                "sourceDuration": transport?.tracks.map { $0.audio.sourceDuration }.max() ?? 0,
                "channels": transport?.channels ?? 2, "availableChannels": transport.map { Int($0.engine.outputNode.outputFormat(forBus: 0).channelCount) } ?? 2,
                "hardwareSampleRate": transport?.engine.outputNode.outputFormat(forBus: 0).sampleRate ?? 0,
                "countingIn": transport?.countingIn ?? false, "countRemaining": transport?.countInRemaining ?? 0,
                "endSerial": endSerial, "ended": ended, "practiceEnd": practiceEnd,
                "error": model != nil && model?.duration == 0 ? model?.status ?? "Audio unavailable" : ""]
    }
    func diagnostics() -> [String:Any] {
        var value=model?.transport.audioDiagnostics() ?? [:];value["token"]=token;value["preparing"]=preparing;value["nativeVersion"]="27.32";value["reusedOriginals"]=reusedAssets;value["timestamp"]=ISO8601DateFormatter().string(from:Date());value["midiClock"]=midiClock.status();value["lastAudioError"]=lastAudioError;value["preparationSeconds"]=preparationTimings;value["lastInterruption"]=lastInterruption;value["modelStatus"]=model?.status ?? "No song prepared";value["mode"]=model?.stereo == true ? "Stereo" : "USB";return value
    }
    func writeReport(reason:String) {
        var value=diagnostics();value["reason"]=reason
        if let data=try? JSONSerialization.data(withJSONObject:value,options:[.prettyPrinted,.sortedKeys]){try? FileManager.default.createDirectory(at:root,withIntermediateDirectories:true);try? data.write(to:root.appendingPathComponent("last-audio-diagnostics.json"),options:.atomic)}
    }
    func request(_ payload: [String: Any]) async throws -> [String: Any] {
        do {return try await performRequest(payload)}
        catch is CancellationError {throw CancellationError()}
        catch {
            if ["audioBegin","audioChunk","audioFinish","audioPlay"].contains(payload["command"] as? String ?? "") {lastAudioError = error.localizedDescription}
            var text = error.localizedDescription
            if let source = model ?? preparingModel {
                for track in source.rawTracks {
                    if let id = track["id"] as? String, text.contains(id) { text = text.replacingOccurrences(of: id, with: "«\(source.title) → \(track["name"] as? String ?? "Audio track")»") }
                }
            }
            lastAudioError = text
            throw BenKenAudioError.invalid(text)
        }
    }
    nonisolated static func waveform(url:URL,bins:Int=600) throws -> [Float] {
        guard (2...2000).contains(bins) else {throw BenKenAudioError.invalid("Invalid waveform size.")}
        let file=try AVAudioFile(forReading:url,commonFormat:.pcmFormatFloat32,interleaved:false)
        guard file.length>0,let block=AVAudioPCMBuffer(pcmFormat:file.processingFormat,frameCapacity:8192) else {throw BenKenAudioError.invalid("Audio has no waveform.")}
        var values=[Float](repeating:0,count:bins)
        let total=file.length
        while file.framePosition<total {
            try Task.checkCancellation()
            let start=file.framePosition
            try file.read(into:block,frameCount:AVAudioFrameCount(min(8192,total-start)))
            guard block.frameLength>0,let channels=block.floatChannelData else {break}
            for i in 0..<Int(block.frameLength) {
                let bin=min(bins-1,Int((start+Int64(i))*Int64(bins)/total))
                for c in 0..<Int(block.format.channelCount) {
                    let sample=abs(channels[c][i]);if sample.isFinite {values[bin]=max(values[bin],sample)}
                }
            }
        }
        try Task.checkCancellation()
        return values
    }
    private nonisolated static func cacheURL(_ entry: [String: Any], root: URL) -> URL? {
        guard let hash=entry["digest"] as? String, hash.count==64, hash.allSatisfy({"0123456789abcdef".contains($0)}) else {return nil}
        let ext=URL(fileURLWithPath:entry["name"] as? String ?? "").pathExtension.lowercased()
        let safe=["mp3","wav","caf","m4a","aif","aiff"].contains(ext) ? ext : "bin"
        return root.appendingPathComponent("originals",isDirectory:true).appendingPathComponent(hash+"."+safe)
    }
    private nonisolated static func makeTransfer(_ payload: [String: Any], root: URL) throws -> Transfer {
        guard let next=payload["token"] as? String,UUID(uuidString:next) != nil,let text=payload["state"] as? String,text.utf8.count<=8*1024*1024,
              let entries=payload["assets"] as? [[String:Any]],entries.count<=32 else {throw BenKenAudioError.invalid("Invalid main audio request.")}
        let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
        var value=Transfer(token:next,folder:folder,state:Data(text.utf8),catalog:entries),bytes=0
        do {
            for entry in entries {
                guard let id=entry["id"] as? String,!id.isEmpty,id.count<=120,value.files[id]==nil,let size=entry["size"] as? Int,size>0,size<=160*1024*1024 else {throw BenKenAudioError.invalid("Invalid audio file.")}
                bytes+=size;guard bytes<=8*1024*1024*1024 else {throw BenKenAudioError.invalid("Song exceeds 8 GiB.")}
                if entry["digest"] != nil && cacheURL(entry,root:root)==nil {throw BenKenAudioError.invalid("Invalid audio fingerprint.")}
                if let url=cacheURL(entry,root:root),let attrs=try? FileManager.default.attributesOfItem(atPath:url.path),attrs[.size] as? Int==size,
                   (try? VerifiedAudioDigest.digest(url))==entry["digest"] as? String {
                    value.files[id]=url;value.lengths[id]=size;continue
                }
                let file=folder.appendingPathComponent(UUID().uuidString);FileManager.default.createFile(atPath:file.path,contents:nil)
                value.files[id]=file;value.handles[id]=try FileHandle(forWritingTo:file);value.lengths[id]=0
            }
            return value
        } catch {value.handles.values.forEach{try? $0.close()};try? FileManager.default.removeItem(at:folder);throw error}
    }
    private nonisolated static func writeChunk(_ payload: [String: Any], to value: inout Transfer) throws {
        guard let id=payload["asset"] as? String,let text=payload["data"] as? String,text.utf8.count<=350000,let bytes=Data(base64Encoded:text),bytes.count<=262144,
              let handle=value.handles[id],let offset=payload["offset"] as? Int,offset==value.lengths[id],let size=value.catalog.first(where:{$0["id"] as? String==id})?["size"] as? Int,offset+bytes.count<=size else {throw BenKenAudioError.invalid("Incomplete main audio transfer.")}
        try handle.write(contentsOf:bytes);value.lengths[id]=offset+bytes.count
    }
    private nonisolated static func install(_ value: Transfer, root: URL) throws -> NativeLibrary {
        let directory=root.appendingPathComponent("originals",isDirectory:true);try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
        var assets:[String:URL]=[:],names:[String:String]=[:]
        for entry in value.catalog {
            guard let id=entry["id"] as? String,let source=value.files[id] else {throw BenKenAudioError.invalid("Missing audio file.")}
            let hash=try VerifiedAudioDigest.digest(source)
            if let expected=entry["digest"] as? String,expected != hash {throw BenKenAudioError.invalid("Audio changed or was damaged during transfer. Prepare it again.")}
            var named=entry;named["digest"]=hash
            guard let destination=cacheURL(named,root:root) else {throw BenKenAudioError.invalid("Invalid audio fingerprint.")}
            if source != destination {
                if (try? VerifiedAudioDigest.digest(destination)) != hash {
                    let partial=directory.appendingPathComponent(UUID().uuidString+".partial")
                    defer {try? FileManager.default.removeItem(at:partial)}
                    try FileManager.default.copyItem(at:source,to:partial)
                    guard try AudioPreparation.digest(partial)==hash else {throw BenKenAudioError.invalid("Local audio verification failed.")}
                    if FileManager.default.fileExists(atPath:destination.path){try FileManager.default.removeItem(at:destination)}
                    try FileManager.default.moveItem(at:partial,to:destination)
                }
            }
            assets[id]=destination;names[id]=entry["name"] as? String ?? "audio.mp3"
        }
        let library=NativeLibrary(state:value.state,assets:assets,names:names);try library.validate();return library
    }
    private func cancelWarm() async {
        // Drain the old writer before playback or cache removal can touch the same files.
        warmToken="";warmModel?.setExternalPlaybackBusy(true)
        let work=warmWork
        _ = await work?.result
        if let value=warmTransfer{value.handles.values.forEach{try? $0.close()};try? FileManager.default.removeItem(at:value.folder)}
        warmTransfer=nil;warmModel=nil;warmWork=nil;warmPreparing=false;warmAutomatic=false
    }
    private func performRequest(_ payload: [String: Any]) async throws -> [String: Any] {
        let command = payload["command"] as? String ?? ""
        if command == "midiClockStatus" { return midiClock.status() }
        if command == "midiClockConfigure" {
            guard !playing,!preparing else {throw BenKenAudioError.invalid("Stop playback before changing MIDI Clock.")}
            try midiClock.configure(enabled:payload["enabled"] as? Bool ?? false,destination:payload["destination"] as? String ?? "",transport:payload["sendStartStop"] as? Bool ?? false);return midiClock.status()
        }
        if command == "audioWarmState" {return ["token":warmToken,"preparing":warmPreparing,"phase":warmModel?.preparationPhase ?? "Saving local audio…","progress":warmModel?.preparationProgress ?? 0]}
        if command == "audioWarmCancel" {if payload["token"] as? String==warmToken{await cancelWarm()};return [:]}
        if command == "audioWarmBegin" {
            guard !playing,model?.transport.metronomeRunning != true,!preparing,!warmPreparing else {throw BenKenAudioError.invalid("Stop playback and wait for preparation before preparing a concert.")}
            guard let expected=payload["token"] as? String,UUID(uuidString:expected) != nil else {throw BenKenAudioError.invalid("Invalid concert request.")}
            warmToken=expected;warmPreparing=true;warmAutomatic=payload["automatic"] as? Bool == true;let root=self.root
            do {
                let work=Task { @MainActor in
                    let value=try await Task.detached(priority:.utility){try Self.makeTransfer(payload,root:root)}.value
                    guard self.warmToken==expected else {value.handles.values.forEach{try? $0.close()};try? FileManager.default.removeItem(at:value.folder);throw CancellationError()}
                    self.warmTransfer=value
                    return ["token":expected,"cachedAssets":value.files.keys.filter{value.handles[$0]==nil}.sorted()] as [String:Any]
                }
                warmWork=work;return try await work.value
            } catch {if warmToken==expected{await cancelWarm()};throw error}
        }
        if command == "audioWarmChunk" {
            guard payload["token"] as? String==warmToken,var value=warmTransfer else {throw CancellationError()}
            try Self.writeChunk(payload,to:&value);warmTransfer=value;return [:]
        }
        if command == "audioWarmFinish" {
            guard let value=warmTransfer,payload["token"] as? String==warmToken,value.catalog.allSatisfy({value.lengths[$0["id"] as? String ?? ""]==$0["size"] as? Int}) else {throw BenKenAudioError.invalid("Concert audio transfer is incomplete.")}
            warmTransfer=nil;value.handles.values.forEach{try? $0.close()}
            let expected=warmToken,root=self.root
            let work=Task { @MainActor in
                defer {try? FileManager.default.removeItem(at:value.folder);if self.warmToken==expected{self.warmPreparing=false;self.warmModel=nil}}
                let library=try await Task.detached(priority:.utility){try Self.install(value,root:root)}.value
                guard self.warmToken==expected else {throw CancellationError()}
                let candidate=NativeConcertModel(root:root,startTimers:false);candidate.library=library;candidate.stereo=payload["stereo"] as? Bool ?? true;self.warmModel=candidate
                try await candidate.prepareFilesOnly()
                guard self.warmToken==expected else {throw CancellationError()}
                return ["token":expected,"ready":true,"tracks":candidate.rawTracks.count] as [String:Any]
            }
            warmWork=work;return try await work.value
        }
        if ["audioBegin","audioPlay","audioRefreshOutput","audioMetronomeStart"].contains(command),warmPreparing {
            if warmAutomatic {await cancelWarm()} else {throw BenKenAudioError.invalid("Finish or cancel concert preparation first.")}
        }
        if command == "audioCacheClear" {
            guard !playing,model?.transport.metronomeRunning != true,!preparing else {throw BenKenAudioError.invalid("Stop playback and wait for audio loading before clearing the cache.")}
            await cancelWarm();cancel()
            // Only regenerated playback copies live here. Never remove the saved library.
            for name in ["originals","prepared"] {
                let folder=root.appendingPathComponent(name,isDirectory:true)
                if FileManager.default.fileExists(atPath:folder.path){try FileManager.default.removeItem(at:folder)}
            }
            return ["cleared":true]
        }
        if command == "audioState" { return state(metering: payload["meters"] as? Bool ?? false) }
        if command == "audioRefreshOutput" {
            guard !playing, !preparing else { throw BenKenAudioError.invalid("Stop playback and wait for preparation before refreshing outputs.") }
            if let model {
                preparing = true; preparingModel = model
                defer { preparing = false; preparingModel = nil }
                await model.prepare(offline: offline, reserveOutputs: true)
                guard model.duration > 0 else { throw BenKenAudioError.invalid(model.status) }
                lastAudioError = ""; lastInterruption = ""
                return state()
            }
            #if os(iOS)
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
            let outputs = min(32, session.maximumOutputNumberOfChannels)
            if outputs > 0 { try session.setPreferredOutputNumberOfChannels(outputs) }
            var value = state(); value["availableChannels"] = session.outputNumberOfChannels; return value
            #else
            return state()
            #endif
        }
        if command == "audioDiagnostics" { writeReport(reason:"Requested audio status");return diagnostics() }
        if command == "audioCancel" { if payload["token"] as? String == token { cancel() }; return state() }
        if command == "audioBegin" {
            cancel();preparing=true;preparationTimings=[:];lastInterruption="";lastAudioError=""
            guard let next=payload["token"] as? String,UUID(uuidString:next) != nil else {preparing=false;throw BenKenAudioError.invalid("Invalid main audio request.")};token=next
            let root=self.root
            do {
                let value=try await Task.detached{try Self.makeTransfer(payload,root:root)}.value
                guard token==next else {value.handles.values.forEach{try? $0.close()};try? FileManager.default.removeItem(at:value.folder);throw CancellationError()}
                transfer=value;reusedAssets=value.files.count-value.handles.count
                var result=state();result["cachedAssets"]=value.files.keys.filter{value.handles[$0]==nil}.sorted();return result
            } catch {if token==next{cancel()};throw error}
        }
        guard let requestToken = payload["token"] as? String, requestToken == token, !token.isEmpty else { throw CancellationError() }
        if command == "audioChunk" {
            guard var value=transfer else {throw CancellationError()};try Self.writeChunk(payload,to:&value);transfer=value;return [:]
        }
        if command == "audioFinish" {
            guard let value = transfer, value.catalog.allSatisfy({ value.lengths[$0["id"] as? String ?? ""] == $0["size"] as? Int }) else { throw BenKenAudioError.invalid("Audio transfer is incomplete.") }
            transfer = nil; value.handles.values.forEach { try? $0.close() }
            defer { try? FileManager.default.removeItem(at: value.folder); if token == requestToken { preparing = false; preparingModel = nil } }
            let root=self.root,installBegan=ProcessInfo.processInfo.systemUptime
            let library=try await Task.detached{try Self.install(value,root:root)}.value
            guard token == requestToken else { throw CancellationError() }
            preparationTimings["verifyAndInstall"] = ProcessInfo.processInfo.systemUptime - installBegan
            let prepareBegan = ProcessInfo.processInfo.systemUptime
            let candidate = NativeConcertModel(root: root, startTimers: false); candidate.library = library
            candidate.stereo = payload["stereo"] as? Bool ?? true
            preparingModel = candidate; await candidate.prepare(offline: offline, reserveOutputs: true)
            guard token == requestToken else { candidate.transport.stop(); throw CancellationError() }
            guard candidate.duration > 0 || candidate.rawTracks.isEmpty else { var text = candidate.status
                for track in candidate.rawTracks { if let id = track["id"] as? String { text = text.replacingOccurrences(of: id, with: "«\(candidate.title) → \(track["name"] as? String ?? "Audio track")»") } }
                throw BenKenAudioError.invalid(text) }
            preparationTimings["prepareAndLoad"] = ProcessInfo.processInfo.systemUptime - prepareBegan
            candidate.transport.midiClock=midiClock
            let interrupted = candidate.transport.onInterruption
            candidate.transport.onInterruption = { [weak self] reason in
                interrupted?(reason); self?.lastInterruption = reason
                self?.writeReport(reason: "Audio interruption: " + reason)
            }
            model = candidate; preparing = false; ended = false
            candidate.transport.onEnded = { [weak self, weak candidate] practice in
                guard let self, self.model === candidate else { return }; self.ended = true; self.practiceEnd = practice; self.endSerial += 1
            }
            return state()
        }
        guard let model, !preparing, model.duration > 0 else { throw BenKenAudioError.invalid("Prepare the selected song first.") }
        if command == "audioWaveform" {
            guard !playing,let id=payload["track"] as? String,
                  let track=model.transport.tracks.first(where:{$0.id==id}) else {
                throw BenKenAudioError.invalid("Stop playback before reading the waveform.")
            }
            let key=track.audio.url.path
            if let values=waveformCache[key] {return ["token":token,"peaks":values]}
            waveformTask?.cancel()
            let url=track.audio.url
            let task=Task.detached(priority:.utility) {try Self.waveform(url:url)}
            waveformTask=task
            let values=try await task.value
            guard token==requestToken,!playing else {throw CancellationError()}
            waveformTask=nil
            if waveformCache.count>=4 {waveformCache.removeAll()}
            waveformCache[key]=values
            return ["token":token,"peaks":values]
        }
        switch command {
        case "audioMix":
            guard let tracks = payload["tracks"] as? [[String: Any]], let opts = payload["opts"] as? [String: Any], let master = payload["master"] as? Double else { throw BenKenAudioError.invalid("Invalid mixer request.") }
            try model.transport.update(MainAudioMix.resolve(model.transport.tracks, tracks: tracks, options: opts, master: master, stereo: model.stereo))
        case "audioPlay":
            waveformTask?.cancel(); waveformTask=nil
            let position = payload["position"] as? Double ?? 0, stop = payload["stopAt"] as? Double, click = payload["click"] as? [String: Any] ?? [:]
            let cfg = NativeClick(bpm: click["bpm"] as? Double ?? 120, beats: click["beatsPerBar"] as? Int ?? 4, bars: click["countInBars"] as? Int ?? 0, audible: click["countInSound"] as? Bool ?? false, continuous: click["continuous"] as? Bool ?? false, output: model.stereo ? 1 : click["output"] as? Int ?? 3, gain: Float(click["volume"] as? Double ?? 0.12), stereo: model.stereo, sound: click["sound"] as? String ?? "sine")
            ended = false; try model.transport.play(position: position, stopAt: stop, click: cfg, offline: offline, midiBpm:payload["midiBpm"] as? Double)
            if !offline { Task { [weak self] in try? await Task.sleep(nanoseconds:650_000_000);guard let self,self.token == requestToken else{return};self.writeReport(reason:"After Play") } }
        case "audioMetronomeStart":
            let click=payload["click"] as? [String:Any] ?? [:]
            let cfg=NativeClick(bpm:click["bpm"] as? Double ?? 120,beats:click["beatsPerBar"] as? Int ?? 4,continuous:true,output:model.stereo ? 1 : click["output"] as? Int ?? 3,gain:Float(click["volume"] as? Double ?? 0.12),stereo:model.stereo,sound:click["sound"] as? String ?? "sine")
            let delay=try model.transport.startMetronome(cfg,offline:offline)
            var response=state();response["metronomeDelay"]=delay;return response
        case "audioMetronomeStop": model.transport.stopMetronome()
        case "audioPause": model.transport.pause(); ended = false
        case "audioStop": model.transport.stop(); ended = false
        default: throw BenKenAudioError.invalid("Unknown main audio command.")
        }
        return state()
    }
}
