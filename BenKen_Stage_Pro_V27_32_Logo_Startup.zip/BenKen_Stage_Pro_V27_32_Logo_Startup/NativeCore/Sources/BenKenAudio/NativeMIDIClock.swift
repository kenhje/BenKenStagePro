import Foundation
import AVFoundation
import CoreMIDI

/// MIDI clock is 24 pulses per quarter note. Absolute host times avoid cumulative drift.
public struct NativeClockGrid: Sendable {
    public let interval: Double, origin: Double, end: Double
    public private(set) var next: Int64
    public init(bpm: Double, musicTime: Double, position: Double, begin: Double, end: Double) throws {
        guard bpm.isFinite, (20...300).contains(bpm), musicTime.isFinite, position.isFinite, position >= 0,
              begin.isFinite, end.isFinite, end > begin else { throw BenKenAudioError.invalid("Invalid MIDI clock timing.") }
        interval = 60 / bpm / 24; origin = musicTime - position; self.end = end
        next = Int64(ceil((begin-origin)/interval - 0.00000001))
    }
    public var nextTime: Double { origin + Double(next) * interval }
    public mutating func take(until horizon: Double) -> [Double] {
        var result: [Double] = []
        while nextTime <= horizon && nextTime < end && result.count < 128 { result.append(nextTime); next += 1 }
        return result
    }
}

/// One selected destination, one dedicated scheduling queue, no JavaScript timing loop.
public final class NativeMIDIClock: @unchecked Sendable {
    private let queue = DispatchQueue(label:"no.benken.midi-clock",qos:.userInteractive)
    private var client = MIDIClientRef(), port = MIDIPortRef(), endpoint = MIDIEndpointRef()
    private var timer: DispatchSourceTimer?, grid: NativeClockGrid?
    private var enabled = false, transport = false, destination = "", running = false
    private var startAt: Double?, startQueued = false, lastSubmitted = 0.0, sent = 0
    private var lastError = "", bpm = 120.0
    private let settings: UserDefaults?
    private static var now: Double { AVAudioTime.seconds(forHostTime:mach_absolute_time()) }
    public init(persist: Bool = true) {
        settings = persist ? .standard : nil
        enabled = settings?.bool(forKey:"benken-midi-clock-enabled") ?? false
        transport = settings?.bool(forKey:"benken-midi-clock-transport") ?? false
        destination = settings?.string(forKey:"benken-midi-clock-destination") ?? ""
        let result=MIDIClientCreateWithBlock("BenKen Clock" as CFString,&client) { [weak self] _ in
            self?.queue.async { [weak self] in
                guard let self,self.running,self.resolve() == 0 else{return}
                self.lastError="MIDI destination disconnected. Reconnect and press Play again.";self.stopLocked()
            }
        }
        if result == noErr { let status=MIDIOutputPortCreate(client,"BenKen tempo output" as CFString,&port);if status != noErr {lastError="MIDI output unavailable (\(status))."} }
        else {lastError="MIDI clock unavailable (\(result))."}
    }
    deinit { timer?.cancel();if port != 0 {MIDIPortDispose(port)};if client != 0 {MIDIClientDispose(client)} }
    public static func destinations() -> [[String:String]] {
        (0..<MIDIGetNumberOfDestinations()).map { index in
            let endpoint=MIDIGetDestination(index);var id=MIDIUniqueID();var name:Unmanaged<CFString>?
            MIDIObjectGetIntegerProperty(endpoint,kMIDIPropertyUniqueID,&id);MIDIObjectGetStringProperty(endpoint,kMIDIPropertyDisplayName,&name)
            return ["id":String(id),"name":name?.takeRetainedValue() as String? ?? "MIDI output"]
        }
    }
    private func resolve() -> MIDIEndpointRef {
        for index in 0..<MIDIGetNumberOfDestinations() {let e=MIDIGetDestination(index);var id=MIDIUniqueID();MIDIObjectGetIntegerProperty(e,kMIDIPropertyUniqueID,&id);if String(id)==destination{return e}}
        return 0
    }
    public func configure(enabled: Bool,destination: String,transport: Bool) throws {
        try queue.sync {
            guard !running else {throw BenKenAudioError.invalid("Stop playback before changing MIDI Clock.")}
            let old=self.destination;self.destination=destination
            if enabled && (port == 0 || resolve() == 0) {self.destination=old;throw BenKenAudioError.invalid("Choose a connected MIDI output.")}
            self.enabled=enabled;self.transport=transport;lastError=""
            settings?.set(enabled,forKey:"benken-midi-clock-enabled");settings?.set(destination,forKey:"benken-midi-clock-destination");settings?.set(transport,forKey:"benken-midi-clock-transport")
        }
    }
    public func status() -> [String:Any] {
        queue.sync { ["enabled":enabled,"destination":destination,"sendStartStop":transport,"running":running,"bpm":bpm,"pulses":sent,"error":lastError,"destinations":Self.destinations()] }
    }
    public func start(bpm: Double,musicTime: Double,position: Double,countIn: Double,end: Double) {
        queue.sync {
            stopLocked();guard enabled else{return};lastError="";endpoint=resolve()
            guard port != 0,endpoint != 0 else {lastError="Selected MIDI output is disconnected. Audio continues without MIDI Clock.";return}
            do {grid=try NativeClockGrid(bpm:bpm,musicTime:musicTime,position:position,begin:musicTime-countIn,end:end)}catch{lastError=error.localizedDescription;return}
            self.bpm=bpm;sent=0;lastSubmitted=0;running=true;startQueued=false
            // Clock warms up during count-in. Optional START is aligned to the first audio beat.
            // Seeking/resuming does not rewind the looper; start from the song beginning for START.
            startAt=transport && position < 0.001 ? musicTime : nil
            let t=DispatchSource.makeTimerSource(queue:queue);timer=t
            t.schedule(deadline:.now(),repeating:.milliseconds(5),leeway:.milliseconds(1))
            t.setEventHandler { [weak self] in self?.pump() };t.resume()
        }
    }
    public func stop() { queue.sync {stopLocked()} }
    private func stopLocked() {
        let wasRunning=running;timer?.cancel();timer=nil;grid=nil;running=false
        // STOP follows every packet already submitted, so a queued START cannot restart a stopped loop.
        if wasRunning && transport && endpoint != 0 { _=send([(max(Self.now,lastSubmitted+0.000001),[0xfc])]) }
        startAt=nil;startQueued=false
    }
    private func pump() {
        guard running,var g=grid else{return};let now=Self.now,horizon=now+0.025
        // Never emit a burst of stale clock pulses after a scheduling stall.
        if now-g.nextTime > 0.075 {lastError="MIDI Clock timing was interrupted. Stop and restart playback to resync.";stopLocked();return}
        var events:[(Double,[UInt8])]=[]
        if let at=startAt,at<=horizon,!startQueued {events.append((at,[0xfa]));startQueued=true}
        for at in g.take(until:horizon) {events.append((at,[0xf8]));sent += 1}
        grid=g
        let finishing=horizon>=g.end
        if finishing && transport {events.append((g.end,[0xfc]))}
        events.sort {a,b in a.0 == b.0 ? a.1[0] == 0xfa && b.1[0] != 0xfa : a.0 < b.0}
        if !events.isEmpty && !send(events) {lastError="MIDI output failed. Audio continues without MIDI Clock.";stopLocked();return}
        if finishing {timer?.cancel();timer=nil;running=false;grid=nil;startAt=nil}
    }
    private func send(_ events:[(Double,[UInt8])]) -> Bool {
        guard port != 0,endpoint != 0 else{return false}
        let memory=UnsafeMutableRawPointer.allocate(byteCount:4096,alignment:MemoryLayout<MIDIPacketList>.alignment);defer{memory.deallocate()}
        let list=memory.bindMemory(to:MIDIPacketList.self,capacity:1);var packet=MIDIPacketListInit(list)
        for (time,bytes) in events {
            let added: UnsafeMutablePointer<MIDIPacket>? = bytes.withUnsafeBufferPointer { buffer in MIDIPacketListAdd(list,4096,packet,AVAudioTime.hostTime(forSeconds:max(0,time)),bytes.count,buffer.baseAddress!) }
            guard let added else{return false};packet=added;lastSubmitted=max(lastSubmitted,time)
        }
        return MIDISend(port,endpoint,list)==noErr
    }
}
