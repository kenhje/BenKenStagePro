import XCTest
import AVFoundation
import CoreMIDI
@testable import BenKenAudio
final class MIDIClockTests: XCTestCase {
    func testAbsoluteGridHas24PulsesAndNoAccumulatedDrift() throws {
        for bpm in [96.0,120.0,125.0,300.0] {
            let seconds=60/bpm*400
            var grid=try NativeClockGrid(bpm:bpm,musicTime:100,position:0,begin:100,end:100+seconds)
            var times:[Double]=[]
            for i in 0...Int(ceil(seconds*50)) { times += grid.take(until:100+Double(i)/50) }
            XCTAssertEqual(times.count,400*24)
            for (index,time) in times.enumerated() {XCTAssertEqual(time,100+Double(index)*60/bpm/24,accuracy:0.000000001)}
        }
    }
    func testCountInAndSeekUseSameSongGrid() throws {
        var grid=try NativeClockGrid(bpm:120,musicTime:100,position:0,begin:96,end:101)
        let warmup=grid.take(until:100);XCTAssertEqual(warmup.count,128) // bounded batches
        let rest=grid.take(until:100);XCTAssertEqual(warmup.count+rest.count,193)
        XCTAssertEqual(rest.last!,100,accuracy:0.000001)
        var seek=try NativeClockGrid(bpm:120,musicTime:100,position:1.125,begin:100,end:101)
        let first=seek.take(until:100.05);XCTAssertEqual(first.first!,100,accuracy:0.000001)
    }
    func testInvalidTempoAndEndAreRejected() {
        for bpm in [0.0,19.0,301.0,Double.nan] {XCTAssertThrowsError(try NativeClockGrid(bpm:bpm,musicTime:1,position:0,begin:1,end:2))}
        XCTAssertThrowsError(try NativeClockGrid(bpm:120,musicTime:1,position:0,begin:1,end:1))
    }
    func testMissingMIDIOutputDoesNotEnableClock() throws {
        let clock=NativeMIDIClock(persist:false)
        XCTAssertThrowsError(try clock.configure(enabled:true,destination:"not-a-midi-endpoint",transport:true))
        XCTAssertEqual(clock.status()["enabled"] as? Bool,false)
        try clock.configure(enabled:false,destination:"",transport:false);clock.stop()
    }
}

private final class ClockRecorder: @unchecked Sendable {
    private let lock=NSLock()
    private var events:[(UInt8,UInt64)]=[]
    func receive(_ list:UnsafePointer<MIDIPacketList>) {
        var values:[(UInt8,UInt64)]=[]
        let offset=MemoryLayout<MIDIPacketList>.offset(of:\.packet)!,dataOffset=MemoryLayout<MIDIPacket>.offset(of:\.data)!
        var packet=UnsafeRawPointer(list).advanced(by:offset).assumingMemoryBound(to:MIDIPacket.self)
        for _ in 0..<list.pointee.numPackets {
            let data=UnsafeRawPointer(packet).advanced(by:dataOffset).assumingMemoryBound(to:UInt8.self)
            for i in 0..<Int(packet.pointee.length){values.append((data[i],packet.pointee.timeStamp))}
            packet=UnsafePointer(MIDIPacketNext(packet))
        }
        lock.lock();events += values;lock.unlock()
    }
    func snapshot() -> [(UInt8,UInt64)] {lock.lock();defer{lock.unlock()};return events}
}
extension MIDIClockTests {
    func testVirtualDestinationReceivesClockAndTransportOnAudioHostTimeline() async throws {
        let recorder=ClockRecorder();var client=MIDIClientRef(),destination=MIDIEndpointRef()
        guard MIDIClientCreateWithBlock("BenKen clock test" as CFString,&client,nil)==noErr else{throw XCTSkip("Core MIDI server unavailable")}
        defer {if destination != 0 {MIDIEndpointDispose(destination)};MIDIClientDispose(client)}
        let result=MIDIDestinationCreateWithBlock(client,"BenKen isolated test destination" as CFString,&destination) {packets,_ in recorder.receive(packets)}
        guard result==noErr else{throw XCTSkip("Virtual MIDI destination unavailable")}
        var id=MIDIUniqueID();MIDIObjectGetIntegerProperty(destination,kMIDIPropertyUniqueID,&id)
        let clock=NativeMIDIClock(persist:false);try clock.configure(enabled:true,destination:String(id),transport:true)
        let music=AVAudioTime.seconds(forHostTime:mach_absolute_time())+0.15
        clock.start(bpm:120,musicTime:music,position:0,countIn:0,end:music+0.5)
        try await Task.sleep(nanoseconds:900_000_000)
        let values=recorder.snapshot(),ticks=values.filter{$0.0==0xf8}
        XCTAssertEqual(ticks.count,24);XCTAssertEqual(values.first?.0,0xfa);XCTAssertEqual(values.last?.0,0xfc)
        for (index,event) in ticks.enumerated(){XCTAssertEqual(AVAudioTime.seconds(forHostTime:event.1),music+Double(index)/48,accuracy:0.000001)}
        XCTAssertEqual(clock.status()["running"] as? Bool,false);clock.stop()
    }
}
