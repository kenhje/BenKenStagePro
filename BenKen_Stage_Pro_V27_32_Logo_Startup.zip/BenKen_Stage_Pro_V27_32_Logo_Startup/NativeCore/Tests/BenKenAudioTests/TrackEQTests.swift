import XCTest
import AVFoundation
@testable import BenKenAudio

final class TrackEQTests: XCTestCase {
    func testSavedSettingsRequireOptInAndRejectInvalidValues() throws {
        XCTAssertFalse(try NativeTrackEQ(saved: ["enabled": true]).enabled)
        XCTAssertTrue(try NativeTrackEQ(saved: ["enabled": true, "optInVersion": 1]).enabled)
        for raw: [String: Any] in [["mid": Double.nan], ["high": 16], ["lowHz": 0], ["midWidth": 5], ["mid": true], ["high": "6"]] {
            XCTAssertThrowsError(try NativeTrackEQ(saved: raw))
        }
    }
    @MainActor func testEachBandProcessesAudioAndLiveBypassKeepsUSBRouting() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let prep = try AudioPreparation(cache: folder.appendingPathComponent("cache"))
        for sourceChannels: AVAudioChannelCount in [1, 2] {
            for (band, frequency) in [(0, 60.0), (1, 1000.0), (2, 3000.0), (3, 16000.0)] {
                let format = AVAudioFormat(standardFormatWithSampleRate: 48000, channels: sourceChannels)!
                let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 96000)!; buffer.frameLength = 96000
                for c in 0..<Int(sourceChannels) { for f in 0..<96000 { buffer.floatChannelData![c][f] = Float(0.1 * sin(2 * .pi * frequency * Double(f) / 48000)) } }
                let url = folder.appendingPathComponent("\(sourceChannels)-\(band).wav")
                do { let file = try AVAudioFile(forWriting: url, settings: format.settings); try file.write(from: buffer) }
                let audio = try await prep.prepare(url, rate: 1, semitones: 0)
                let transport = NativeTransport()
                var track = NativeTrack(id: "eq", audio: audio, output: 21, stereo: sourceChannels == 2)
                try await transport.load([track], channels: 22, offline: true)
                defer { transport.stop(); transport.engine.stop() }
                let output = AVAudioPCMBuffer(pcmFormat: transport.engine.manualRenderingFormat, frameCapacity: 4096)!
                try transport.play(offline: true)
                func rms() throws -> Double {
                    var energy = 0.0, count = 0
                    for block in 0..<5 {
                        XCTAssertEqual(try transport.engine.renderOffline(4096, to: output), .success)
                        for c in 0..<22 {
                            if c != 20 && !(sourceChannels == 2 && c == 21) {
                                for f in 0..<Int(output.frameLength) { XCTAssertLessThan(abs(output.floatChannelData![c][f]), 0.00001) }
                            }
                        }
                        if block > 1 { for f in 0..<Int(output.frameLength) { let v = Double(output.floatChannelData![20][f]); energy += v*v; count += 1 } }
                    }
                    return sqrt(energy / Double(count))
                }
                let original = try rms()
                track.eq.enabled = true; track.eq.gains[band] = -12
                try transport.update([track])
                let reduced = try rms()
                XCTAssertLessThan(reduced / original, band == 0 || band == 3 ? 0.5 : 0.3)
                track.eq.enabled = false
                try transport.update([track])
                let restored = try rms()
                XCTAssertEqual(restored / original, 1, accuracy: 0.02)
                XCTAssertTrue(transport.playing)
                XCTAssertEqual(transport.tracks[0].output, 21)
                XCTAssertEqual(transport.tracks[0].audio.url, audio.url)
            }
        }
    }
    func testMainBridgeCarriesEQWithoutChangingSourceOrGain() throws {
        let prepared = NativeTrack(id: "one", audio: PreparedAudio(url: URL(fileURLWithPath: "/tmp/tone.wav"), sourceDuration: 1, duration: 1, channels: 1, sampleRate: 48000, digest: "test", preparedDigest: "test"))
        let tracks: [[String: Any]] = [["id": "one", "gain": 0.5, "eq": ["enabled": true, "optInVersion": 1, "mid": -6.0]]]
        let updated = try MainAudioMix.resolve([prepared], tracks: tracks, options: [:], master: 1, stereo: true)
        XCTAssertTrue(updated[0].eq.enabled); XCTAssertEqual(updated[0].eq.gains[1], -6)
        XCTAssertEqual(updated[0].gain, 0.5); XCTAssertEqual(updated[0].audio.url, prepared.audio.url)
    }
    @MainActor func testThirtyTwoIndependentEQsRenderWithoutChannelBleed() async throws {
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        defer { try? FileManager.default.removeItem(at: folder) }
        let format = AVAudioFormat(standardFormatWithSampleRate: 48000, channels: 1)!
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 48000)!; buffer.frameLength = 48000
        for f in 0..<48000 { buffer.floatChannelData![0][f] = Float(0.1 * sin(2 * .pi * 1000 * Double(f) / 48000)) }
        let url = folder.appendingPathComponent("tone.wav")
        do { let file = try AVAudioFile(forWriting: url, settings: format.settings); try file.write(from: buffer) }
        let prep = try AudioPreparation(cache: folder.appendingPathComponent("cache"))
        let audio = try await prep.prepare(url, rate: 1, semitones: 0)
        let tracks = (0..<32).map { index -> NativeTrack in
            var eq = NativeTrackEQ(); eq.enabled = true; eq.gains[1] = index.isMultiple(of: 2) ? -12 : 0
            return NativeTrack(id: "track-\(index)", audio: audio, output: index + 1, stereo: false, eq: eq)
        }
        let transport = NativeTransport()
        try await transport.load(tracks, channels: 32, offline: true)
        defer { transport.stop(); transport.engine.stop() }
        try transport.play(offline: true)
        let output = AVAudioPCMBuffer(pcmFormat: transport.engine.manualRenderingFormat, frameCapacity: 4096)!
        var peaks = Array(repeating: Float(0), count: 32)
        for block in 0..<6 {
            XCTAssertEqual(try transport.engine.renderOffline(4096, to: output), .success)
            if block > 1 { for c in 0..<32 { for f in 0..<Int(output.frameLength) { peaks[c] = max(peaks[c], abs(output.floatChannelData![c][f])) } } }
        }
        for c in 0..<32 { XCTAssertEqual(peaks[c], c.isMultiple(of: 2) ? 0.02512 : 0.1, accuracy: 0.003) }
        XCTAssertEqual(transport.audioDiagnostics()["enabledTrackEQs"] as? Int, 32)
    }

}
