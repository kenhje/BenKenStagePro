import XCTest
import AVFoundation
@testable import BenKenAudio

extension MainAudioTests {
    @MainActor private func cacheBegin(_ session: MainAudioSession, data: Data, digest: String, token: String, warm: Bool = false) async throws -> [String:Any] {
        try await session.request(["command":warm ? "audioWarmBegin":"audioBegin","token":token,"state":rawState(),"assets":[["id":"tone","name":"Tone.wav","size":data.count,"digest":digest]]])
    }
    @MainActor private func cacheChunk(_ session: MainAudioSession, data: Data, token: String, warm: Bool = false) async throws {
        _ = try await session.request(["command":warm ? "audioWarmChunk":"audioChunk","token":token,"asset":"tone","offset":0,"data":data.base64EncodedString()])
    }
    @MainActor func testVerifiedOriginalReuseAcrossLoadsAndSessions() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),session=MainAudioSession(root:root,offline:true)
        let (source,data)=try sample(),hash=try AudioPreparation.digest(source)
        defer {session.cancel();try? FileManager.default.removeItem(at:source);try? FileManager.default.removeItem(at:root)}
        let first=UUID().uuidString
        let missing=try await cacheBegin(session,data:data,digest:hash,token:first);XCTAssertEqual(missing["cachedAssets"] as? [String],[])
        try await cacheChunk(session,data:data,token:first)
        _ = try await session.request(["command":"audioFinish","token":first,"stereo":true])
        let duration=session.state()["duration"] as? Double
        let second=UUID().uuidString,reused=try await cacheBegin(session,data:data,digest:hash,token:second)
        XCTAssertEqual(reused["cachedAssets"] as? [String],["tone"])
        // No chunks at all: the actual finish/prepare/play path must use saved disk files.
        let ready=try await session.request(["command":"audioFinish","token":second,"stereo":true])
        XCTAssertEqual(ready["ready"] as? Bool,true);XCTAssertEqual(ready["duration"] as? Double,duration)
        XCTAssertEqual(session.diagnostics()["reusedOriginals"] as? Int,1)
        session.cancel()
        let reopened=MainAudioSession(root:root,offline:true),third=UUID().uuidString
        let persisted=try await cacheBegin(reopened,data:data,digest:hash,token:third);XCTAssertEqual(persisted["cachedAssets"] as? [String],["tone"])
        _ = try await reopened.request(["command":"audioFinish","token":third,"stereo":true]);XCTAssertEqual(reopened.state()["ready"] as? Bool,true);reopened.cancel()
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("library.json").path))
    }
    @MainActor func testDamagedCacheRequiresCopyAndIsRepaired() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),session=MainAudioSession(root:root,offline:true)
        let (source,data)=try sample(),hash=try AudioPreparation.digest(source)
        defer {session.cancel();try? FileManager.default.removeItem(at:source);try? FileManager.default.removeItem(at:root)}
        let token=UUID().uuidString
        _ = try await cacheBegin(session,data:data,digest:hash,token:token);try await cacheChunk(session,data:data,token:token)
        _ = try await session.request(["command":"audioFinish","token":token,"stereo":true]);session.cancel()
        let stored=root.appendingPathComponent("originals/"+hash+".wav");try Data(repeating:0,count:data.count).write(to:stored)
        try FileManager.default.setAttributes([.modificationDate:Date().addingTimeInterval(2)],ofItemAtPath:stored.path)
        let retry=UUID().uuidString,need=try await cacheBegin(session,data:data,digest:hash,token:retry)
        XCTAssertEqual(need["cachedAssets"] as? [String],[])
        try await cacheChunk(session,data:data,token:retry);let ready=try await session.request(["command":"audioFinish","token":retry,"stereo":true]);XCTAssertEqual(ready["ready"] as? Bool,true)
        XCTAssertEqual(try AudioPreparation.digest(stored),hash)
    }
    @MainActor func testChangedContentAndWrongDigestNeverReuseOldAudio() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),session=MainAudioSession(root:root,offline:true)
        let (source,data)=try sample(),hash=try AudioPreparation.digest(source)
        defer {session.cancel();try? FileManager.default.removeItem(at:source);try? FileManager.default.removeItem(at:root)}
        let first=UUID().uuidString
        _ = try await cacheBegin(session,data:data,digest:hash,token:first);try await cacheChunk(session,data:data,token:first)
        _ = try await session.request(["command":"audioFinish","token":first,"stereo":true]);session.cancel()
        var changed=data;changed[changed.count-1] ^= 1
        let modified=source.deletingPathExtension().appendingPathExtension("changed.wav");try changed.write(to:modified);defer{try? FileManager.default.removeItem(at:modified)}
        let newHash=try AudioPreparation.digest(modified),next=UUID().uuidString
        let need=try await cacheBegin(session,data:changed,digest:newHash,token:next);XCTAssertEqual(need["cachedAssets"] as? [String],[])
        try await cacheChunk(session,data:data,token:next) // The claimed new content is not what arrived.
        do {_ = try await session.request(["command":"audioFinish","token":next,"stereo":true]);XCTFail("Wrong fingerprint accepted")}catch{}
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("originals/"+newHash+".wav").path))
        let invalid=UUID().uuidString
        do {_ = try await cacheBegin(session,data:data,digest:"../unsafe",token:invalid);XCTFail("Unsafe fingerprint accepted")}catch{}
    }
    @MainActor func testWholeSetPreparationLeavesCurrentSongUntouchedAndCanCancel() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),session=MainAudioSession(root:root,offline:true)
        let (source,data)=try sample(),hash=try AudioPreparation.digest(source)
        defer {session.cancel();try? FileManager.default.removeItem(at:source);try? FileManager.default.removeItem(at:root)}
        let current=UUID().uuidString
        _ = try await cacheBegin(session,data:data,digest:hash,token:current);try await cacheChunk(session,data:data,token:current)
        _ = try await session.request(["command":"audioFinish","token":current,"stereo":true]);let before=session.state()
        for _ in 0..<3 {
            let warm=UUID().uuidString,begin=try await cacheBegin(session,data:data,digest:hash,token:warm,warm:true)
            XCTAssertEqual(begin["cachedAssets"] as? [String],["tone"])
            let done=try await session.request(["command":"audioWarmFinish","token":warm,"stereo":true]);XCTAssertEqual(done["ready"] as? Bool,true)
            XCTAssertEqual(session.state()["token"] as? String,current);XCTAssertEqual(session.state()["duration"] as? Double,before["duration"] as? Double);XCTAssertFalse(session.playing)
        }
        let cancelled=UUID().uuidString
        _ = try await cacheBegin(session,data:data,digest:hash,token:cancelled,warm:true)
        _ = try await session.request(["command":"audioWarmCancel","token":cancelled])
        do {_ = try await session.request(["command":"audioWarmFinish","token":cancelled]);XCTFail("Cancelled warm request finished")}catch{}
        XCTAssertEqual(session.state()["token"] as? String,current)
        _ = try await session.request(["command":"audioPlay","token":current,"position":0])
        do {_ = try await cacheBegin(session,data:data,digest:hash,token:UUID().uuidString,warm:true);XCTFail("Concert preparation started during playback")}catch{}
        XCTAssertTrue(session.playing)
    }
}

extension MainAudioTests {
    @MainActor func testAutomaticPreparationYieldsToPlaybackAndSongLoading() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),session=MainAudioSession(root:root,offline:true)
        let (source,data)=try sample(),hash=try AudioPreparation.digest(source)
        defer {session.cancel();try? FileManager.default.removeItem(at:source);try? FileManager.default.removeItem(at:root)}
        let current=UUID().uuidString
        _ = try await cacheBegin(session,data:data,digest:hash,token:current);try await cacheChunk(session,data:data,token:current)
        _ = try await session.request(["command":"audioFinish","token":current,"stereo":true])
        func warm(_ token:String) async throws {
            _ = try await session.request(["command":"audioWarmBegin","automatic":true,"token":token,"state":rawState(),"assets":[["id":"tone","name":"Tone.wav","size":data.count,"digest":hash]]])
        }
        let first=UUID().uuidString;try await warm(first)
        _ = try await session.request(["command":"audioPlay","token":current,"position":0]);XCTAssertTrue(session.playing)
        do {_ = try await session.request(["command":"audioWarmFinish","token":first]);XCTFail("Preempted warm transfer survived")}catch{}
        _ = try await session.request(["command":"audioStop","token":current])
        let second=UUID().uuidString;try await warm(second)
        let finish=Task {try await session.request(["command":"audioWarmFinish","token":second,"stereo":true])}
        await Task.yield()
        let next=UUID().uuidString
        let began=try await cacheBegin(session,data:data,digest:hash,token:next)
        _ = await finish.result
        XCTAssertEqual(began["cachedAssets"] as? [String],["tone"])
        XCTAssertEqual(session.state()["token"] as? String,next)
        _ = try await session.request(["command":"audioFinish","token":next,"stereo":true]);XCTAssertEqual(session.state()["ready"] as? Bool,true)
    }
    @MainActor func testClearCachePreservesLibraryAndRejectsPlayback() async throws {
        let root=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString),session=MainAudioSession(root:root,offline:true)
        let (source,data)=try sample(),hash=try AudioPreparation.digest(source)
        defer {session.cancel();try? FileManager.default.removeItem(at:source);try? FileManager.default.removeItem(at:root)}
        let token=UUID().uuidString
        _ = try await cacheBegin(session,data:data,digest:hash,token:token);try await cacheChunk(session,data:data,token:token)
        _ = try await session.request(["command":"audioFinish","token":token,"stereo":true])
        let marker=root.appendingPathComponent("library.json");try Data("saved library".utf8).write(to:marker)
        _ = try await session.request(["command":"audioPlay","token":token,"position":0])
        do {_ = try await session.request(["command":"audioCacheClear"]);XCTFail("Cleared playing files")}catch{}
        XCTAssertTrue(session.playing)
        XCTAssertTrue(FileManager.default.fileExists(atPath:root.appendingPathComponent("originals").path))
        _ = try await session.request(["command":"audioStop","token":token])
        let cleared=try await session.request(["command":"audioCacheClear"]);XCTAssertEqual(cleared["cleared"] as? Bool,true)
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("originals").path))
        XCTAssertFalse(FileManager.default.fileExists(atPath:root.appendingPathComponent("prepared").path))
        XCTAssertEqual(try String(contentsOf:marker),"saved library");XCTAssertTrue(FileManager.default.fileExists(atPath:source.path))
        let need=try await cacheBegin(session,data:data,digest:hash,token:UUID().uuidString);XCTAssertEqual(need["cachedAssets"] as? [String],[])
    }
}
