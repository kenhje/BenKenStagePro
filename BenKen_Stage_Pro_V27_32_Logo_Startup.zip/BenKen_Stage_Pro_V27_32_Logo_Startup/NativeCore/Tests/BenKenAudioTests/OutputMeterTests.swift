import XCTest
import AVFoundation
@testable import BenKenAudio
final class OutputMeterTests: XCTestCase {
    func buffer(_ level: Float, interleaved: Bool = false) -> AVAudioPCMBuffer {
        let f = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: 48000, channels: 2, interleaved: interleaved)!
        let b = AVAudioPCMBuffer(pcmFormat: f, frameCapacity: 1024)!; b.frameLength = 1024
        if interleaved { for i in 0..<1024 { b.floatChannelData![0][i*2] = 0; b.floatChannelData![0][i*2+1] = level } }
        else { for i in 0..<1024 { b.floatChannelData![0][i] = 0; b.floatChannelData![1][i] = level } }
        return b
    }
    func testDisabledDoesNotInventSignalAndEnableReadsActualOutput() {
        let p = NativeSignalProbe(); p.record(buffer(0.25)); XCTAssertFalse(p.recent().fresh); XCTAssertEqual(p.recent().peak,0)
        p.monitor(true); p.record(buffer(0.25)); XCTAssertTrue(p.recent().fresh); XCTAssertEqual(p.recent().peak,0.25,accuracy:0.00001)
        p.monitor(false); XCTAssertFalse(p.recent().fresh); XCTAssertEqual(p.recent().peak,0)
    }
    func testLiveSamplingIsThrottledThenFollowsSilence() async throws {
        let p = NativeSignalProbe(); p.monitor(true); p.record(buffer(0.5)); p.record(buffer(0)); XCTAssertEqual(p.recent().peak,0.5)
        try await Task.sleep(nanoseconds:120_000_000); p.record(buffer(0)); XCTAssertEqual(p.recent().peak,0)
        XCTAssertEqual(p.snapshot().1,0.5)
    }
    func testLeaseAndFreshnessExpireWithoutUIPolling() async throws {
        let p = NativeSignalProbe(); p.monitor(true); p.record(buffer(0.25))
        try await Task.sleep(nanoseconds:650_000_000); p.record(buffer(0.9)); XCTAssertFalse(p.recent().fresh); XCTAssertEqual(p.recent().peak,0); XCTAssertEqual(p.snapshot().1,0.25)
    }
    func testInterleavedAndOfflineBuffers() {
        let p = NativeSignalProbe(alwaysOn:true); p.record(buffer(-0.75,interleaved:true)); XCTAssertEqual(p.recent().peak,0.75); p.record(buffer(0)); XCTAssertEqual(p.recent().peak,0); XCTAssertEqual(p.snapshot().1,0.75)
    }
}
