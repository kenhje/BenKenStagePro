import XCTest
import AVFoundation
@testable import BenKenAudio
final class OutputMeterRoutingTests:XCTestCase {
 @MainActor func testReportedSixTracksReachHighUSBOutputs() async throws {
  let folder=FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
  try FileManager.default.createDirectory(at:folder,withIntermediateDirectories:true)
  let prep=try AudioPreparation(cache:folder.appendingPathComponent("cache"))
  let outputs=[21,22,19,20,18,16]
  for sourceChannels:AVAudioChannelCount in [1,2] {
   var tracks:[NativeTrack]=[]
   for (index,output) in outputs.enumerated() {
    let format=AVAudioFormat(standardFormatWithSampleRate:48000,channels:sourceChannels)!
    let buffer=AVAudioPCMBuffer(pcmFormat:format,frameCapacity:48000)!;buffer.frameLength=48000
    for channel in 0..<Int(sourceChannels) { for frame in 0..<48000 {buffer.floatChannelData![channel][frame]=Float(0.2*sin(2 * .pi * Double(220+index*110)*Double(frame)/48000))} }
    let url=folder.appendingPathComponent("track-\(sourceChannels)-\(index).wav")
    do {let file=try AVAudioFile(forWriting:url,settings:format.settings);try file.write(from:buffer)}
    let audio=try await prep.prepare(url,rate:1,semitones:0)
    tracks.append(NativeTrack(id:"track-\(index)",audio:audio,output:output,stereo:false,gain:index==5 ? 0.8287 : 1))
   }
   for channelCount in [22,32] {
    let transport=NativeTransport()
    try await transport.load(tracks,channels:channelCount,offline:true)
    defer {transport.stop();transport.engine.stop()}
    try transport.play(offline:true)
    let result=AVAudioPCMBuffer(pcmFormat:transport.engine.manualRenderingFormat,frameCapacity:4096)!
    var peaks=Array(repeating:Float(0),count:channelCount)
    for _ in 0..<8 {XCTAssertEqual(try transport.engine.renderOffline(4096,to:result),.success)
     for channel in 0..<channelCount { for frame in 0..<Int(result.frameLength) {peaks[channel]=max(peaks[channel],abs(result.floatChannelData![channel][frame]))} }
    }
    let trackLevels=transport.trackMeterState()
    XCTAssertEqual(trackLevels.count,tracks.count)
    for (i,row) in trackLevels.enumerated() {
     XCTAssertEqual(row["id"] as? String,tracks[i].id)
     XCTAssertGreaterThan(row["peak"] as? Float ?? 0,0.1,"Track meter missing signal for \(tracks[i].id)")
    }
    let signal=transport.outputMeterState()
    XCTAssertEqual(signal["available"] as? Bool,true)
    XCTAssertGreaterThan((signal["peak"] as? Float) ?? 0,0.1,"Output meter did not observe rendered high-channel USB signal")
    print("USB_RENDER sourceChannels=\(sourceChannels) outputs=\(channelCount) peaks=\(peaks)")
    for channel in 0..<channelCount {if outputs.contains(channel+1) {XCTAssertGreaterThan(peaks[channel],0.1,"Silent USB output \(channel+1)")} else {XCTAssertLessThan(peaks[channel],0.0001,"Leak at USB output \(channel+1)")} }
   }
  }
 }
}
