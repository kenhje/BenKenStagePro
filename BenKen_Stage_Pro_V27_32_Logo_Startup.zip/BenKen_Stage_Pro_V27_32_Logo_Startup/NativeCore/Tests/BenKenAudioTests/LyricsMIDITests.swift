import XCTest
@testable import BenKenAudio
final class LyricsMIDITests: XCTestCase {
    func testChordsTransposeRootsBassAndExtensions() {
        XCTAssertEqual(NativeLyrics.transpose("Cmaj7/E", semitones: 2), "Dmaj7/F#")
        XCTAssertEqual(NativeLyrics.transpose("Bb7/F", semitones: -2, preferFlats: true), "Ab7/Eb")
        XCTAssertEqual(NativeLyrics.transpose("F#m7b5", semitones: 1), "Gm7b5")
        XCTAssertEqual(NativeLyrics.transpose("C6/9", semitones: 2), "D6/9")
        XCTAssertEqual(NativeLyrics.transpose("Bridge", semitones: 2), "Bridge")
        XCTAssertEqual(NativeLyrics.transpose("Cb", semitones: 0), "Cb")
    }
    func testSectionsSeparateChordsAndKeepStageNotes() {
        let sections = NativeLyrics.sections("{title: Test}\n{section: VERSE}\n[C]Hello [G/B]world\n[repeat twice]\n{color: #ffffff}Words{/color}\n{soc}\n[Am]Chorus\n{eoc}", semitones: 2)
        XCTAssertEqual(sections.map(\.id), [0,1]); XCTAssertEqual(sections.map(\.label), ["VERSE","CHORUS"])
        XCTAssertEqual(sections[0].lines[0].words, "Hello world")
        XCTAssertTrue(sections[0].lines[0].chords.contains("D")); XCTAssertTrue(sections[0].lines[0].chords.contains("A/C#"))
        XCTAssertEqual(sections[0].lines[1].words, "[repeat twice]")
        XCTAssertEqual(sections[0].lines[2].words, "Words")
        XCTAssertEqual(sections[1].lines[0].chords, "Bm")
    }
    func testTextFollowingUsesSourceRegionTimeAtChangedTempo() {
        let regions = [NativeRegionTime(index: 0, start: 0, end: 3),NativeRegionTime(index: 1, start: 3, end: 9)]
        XCTAssertEqual(NativeLyrics.activeSection(position: 3.9, rate: 0.75, regions: regions), 0)
        XCTAssertEqual(NativeLyrics.activeSection(position: 4, rate: 0.75, regions: regions), 1)
        XCTAssertNil(NativeLyrics.activeSection(position: 12, rate: 0.75, regions: regions))
        XCTAssertNil(NativeLyrics.activeSection(position: .nan, rate: 1, regions: regions))
    }
    func testPlaylistKeepsRepeatedEntries() {
        XCTAssertEqual(NativePlaylist.order(songCount: 3, selectedSet: "Live", sets: ["Live":[2,0,2,1]]), [2,0,2,1])
        XCTAssertEqual(NativePlaylist.order(songCount: 3, selectedSet: "", sets: [:]), [0,1,2])
        XCTAssertEqual(NativePlaylist.order(songCount: 3, selectedSet: "Live", sets: ["Live":[-1,3,0]]), [0])
    }
    func testMIDILearnDoesNotPlayAndHeldNoteCannotRetrigger() {
        let router = NativeMIDIRouter(); router.learn(.playPause)
        XCTAssertNil(router.receive([0x90,60,127], source: "pedal", now: 0)); XCTAssertEqual(router.bindings.count,1)
        XCTAssertNil(router.receive([0x90,60,127], source: "pedal", now: 1))
        XCTAssertNil(router.receive([0x80,60,0], source: "pedal", now: 2))
        XCTAssertEqual(router.receive([0x90,60,127], source: "pedal", now: 3), .playPause)
        XCTAssertNil(router.receive([0x90,60,127], source: "pedal", now: 4))
        XCTAssertNil(router.receive([0x90,60,0], source: "pedal", now: 5))
        XCTAssertEqual(router.receive([0x90,60,127], source: "pedal", now: 6), .playPause)
    }
    func testCCReleasePCDebounceAndInputReset() {
        let router = NativeMIDIRouter(bindings: [NativeMIDIBinding(action:.stop,type:"cc",channel:1,number:10),NativeMIDIBinding(action:.next,type:"pc",channel:1,number:5)])
        XCTAssertEqual(router.receive([0xb0,10,127], source:"a", now:0),.stop)
        XCTAssertNil(router.receive([0xb0,10,64], source:"a", now:1))
        XCTAssertNil(router.receive([0xb0,10,0], source:"a", now:2))
        XCTAssertEqual(router.receive([0xb0,10,127], source:"a", now:3),.stop)
        XCTAssertEqual(router.receive([0xc0,5], source:"a", now:4),.next)
        XCTAssertNil(router.receive([0xc0,5], source:"a", now:4.1))
        XCTAssertEqual(router.receive([0xc0,5], source:"a", now:4.3),.next)
        router.resetInputState()
        XCTAssertEqual(router.receive([0xb0,10,127], source:"a", now:5),.stop)
    }
    func testMIDIMalformedAndConflictingAssignmentsAreRejected() {
        let router = NativeMIDIRouter(bindings:[NativeMIDIBinding(action:.stop,type:"note",channel:1,number:60)])
        for bytes: [UInt8] in [[],[0x90],[0x90,60],[0xf8,60,127],[0x90,128,127]] { XCTAssertNil(router.receive(bytes,source:"a",now:0)) }
        router.learn(.start); XCTAssertNil(router.receive([0x90,60,127],source:"a",now:1))
        XCTAssertEqual(router.bindings.count,1); XCTAssertEqual(router.bindings[0].action,.stop); XCTAssertNotNil(router.learning)
    }
}
