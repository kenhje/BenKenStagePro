import XCTest
import AVFoundation
@testable import BenKenAudio
final class NativeAudioTests: XCTestCase {
    func temporary() throws -> URL { let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString); try FileManager.default.createDirectory(at: url, withIntermediateDirectories: true); return url }
    func tone(_ folder: URL, frequency: Double = 440, seconds: Double = 2) throws -> URL {
        let url = folder.appendingPathComponent(UUID().uuidString + ".wav")
        let format = AVAudioFormat(standardFormatWithSampleRate: 44100, channels: 1)!
        let count = AVAudioFrameCount(seconds * 44100), buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: count)!; buffer.frameLength = count
        for i in 0..<Int(count) { buffer.floatChannelData![0][i] = Float(sin(2 * .pi * frequency * Double(i) / 44100) * 0.2) }
        let file = try AVAudioFile(forWriting: url, settings: format.settings); try file.write(from: buffer); return url
    }
    func frequency(_ url: URL) throws -> Double {
        let f = try AVAudioFile(forReading: url), b = AVAudioPCMBuffer(pcmFormat: f.processingFormat, frameCapacity: AVAudioFrameCount(f.length))!; try f.read(into: b)
        let data = b.floatChannelData![0], start = Int(Double(b.frameLength) * 0.25), end = Int(Double(b.frameLength) * 0.75)
        var crossings = 0
        for i in start..<end where data[i] < 0 && data[i+1] >= 0 { crossings += 1 }
        return Double(crossings) / (Double(end - start) / f.processingFormat.sampleRate)
    }
    func testTempoAndPitchUpAndDownAndCache() async throws {
        let folder = try temporary(), source = try tone(folder), prepare = try AudioPreparation(cache: folder.appendingPathComponent("cache"))
        for (rate, pitch) in [(0.75, -2.0), (1.25, 2.0), (1.0, 0.0)] {
            let result = try await prepare.prepare(source, rate: rate, semitones: pitch)
            XCTAssertEqual(result.duration, 2 / rate, accuracy: 1 / 48000)
            XCTAssertEqual(try frequency(result.url), 440 * pow(2, pitch / 12), accuracy: 5)
            let cached = try await prepare.prepare(source, rate: rate, semitones: pitch)
            XCTAssertEqual(result.url, cached.url)
        }
        let changed = try tone(folder, frequency: 220)
        let result = try await prepare.prepare(changed, rate: 1, semitones: 0)
        XCTAssertEqual(try frequency(result.url), 220, accuracy: 3)
    }
    func testMP3Preparation() async throws {
        let source = URL(fileURLWithPath: "/private/tmp/benken-mp3-test.mp3")
        guard FileManager.default.fileExists(atPath: source.path) else { throw XCTSkip("Fetch the documented MP3 fixture before running this test.") }
        let folder = try temporary(), prepare = try AudioPreparation(cache: folder)
        let original = try AVAudioFile(forReading: source)
        for rate in [0.75, 1.25] {
            let result = try await prepare.prepare(source, rate: rate, semitones: 2)
            XCTAssertEqual(result.duration, Double(original.length) / original.processingFormat.sampleRate / rate, accuracy: 1 / 48000)
            XCTAssertEqual(result.sampleRate, 48000)
        }
    }
    func testLibraryCommitKeepsPreviousAndRejectsMissingAssets() throws {
        let folder = try temporary(), source = try tone(folder)
        let state = Data("{\"songs\":[{\"playback\":{\"tracks\":[{\"assetId\":\"a\"}]}}]}".utf8)
        let value = try NativeLibrary.install(state: state, originals: [("a", "tone.wav", source)], root: folder)
        XCTAssertEqual(value.assets.count, 1)
        try value.save(at: folder)
        XCTAssertTrue(FileManager.default.fileExists(atPath: folder.appendingPathComponent("library.previous.json").path))
        XCTAssertThrowsError(try NativeLibrary.install(state: state, originals: [], root: folder))
        let reopened = try JSONDecoder().decode(NativeLibrary.self, from: Data(contentsOf: folder.appendingPathComponent("library.json")))
        XCTAssertEqual(reopened.state, state)
    }
    func testFourTracksPlayWithThreeFollowingKey() throws {
        let names = ["Guitar", "Bass", "Keys", "Drums"]
        let selections = names.map { TransposeSelection.follows(name: $0, fileName: $0 + ".mp3", explicit: nil) }
        XCTAssertEqual(selections, [true, true, true, false])
        XCTAssertNoThrow(try TransposeSelection.validate(count: selections.filter { $0 }.count, semitones: 2))
        XCTAssertThrowsError(try TransposeSelection.validate(count: 4, semitones: 2))
        XCTAssertNoThrow(try TransposeSelection.validate(count: 4, semitones: 0))
        XCTAssertFalse(TransposeSelection.follows(name: "Click", fileName: "Click.mp3", explicit: nil))
        XCTAssertFalse(TransposeSelection.follows(name: "Guitar", fileName: "g.mp3", explicit: false))
        XCTAssertTrue(TransposeSelection.follows(name: "Drums", fileName: "d.mp3", explicit: true))
    }
    func testMissingAudioIdentifiesEveryAffectedSong() throws {
        let state = Data("{\"songs\":[{\"title\":\"Ghost song\",\"playback\":{\"tracks\":[{\"assetId\":\"a\",\"name\":\"Bass\",\"fileName\":\"Ghost Bass.mp3\"}]}},{\"title\":\"Second song\",\"playback\":{\"tracks\":[{\"assetId\":\"a\",\"name\":\"Shared Bass\",\"fileName\":\"Ghost Bass.mp3\"}]}}]}".utf8)
        let report = NativeAudioDiagnostics.describe(state: state, ids: ["a"])
        XCTAssertTrue(report.contains("Ghost song → Bass → Ghost Bass.mp3"))
        XCTAssertTrue(report.contains("Second song → Shared Bass → Ghost Bass.mp3"))
        let library = NativeLibrary(state: state, assets: [:], names: [:])
        XCTAssertThrowsError(try library.validate()) { error in
            XCTAssertTrue(error.localizedDescription.contains("Ghost song"))
            XCTAssertTrue(error.localizedDescription.contains("Second song"))
        }
    }
    func testInvalidParameters() async throws {
        let folder = try temporary(), prepare = try AudioPreparation(cache: folder)
        do { _ = try await prepare.prepare(folder, rate: .nan, semitones: 0); XCTFail() } catch {}
        do { _ = try await prepare.prepare(folder, rate: 1, semitones: 7); XCTFail() } catch {}
    }
    func testSyncVerifiesAudioAndDetectsDivergence() throws {
        let folder = try temporary(), source = try tone(folder), store = ConcertSyncStore(root: folder.appendingPathComponent("shared")), device = UUID().uuidString
        let state = Data("{\"songs\":[]}".utf8)
        let first = try store.publish(state: state, assets: [("audio", "tone.wav", source)], device: device, expectedParent: nil)
        XCTAssertEqual(try store.head()?.id, first.id); XCTAssertEqual(try store.verify(first).count, 1)
        try store.acknowledge(first, device: UUID().uuidString); XCTAssertEqual(try store.acknowledgements().first?.revision, first.id)
        XCTAssertThrowsError(try store.publish(state: state, assets: [], device: device, expectedParent: nil))
        let second = try store.publish(state: state, assets: [], device: device, expectedParent: first.id)
        XCTAssertEqual(try store.head()?.id, second.id)
        let audio = try store.verify(first)[0].1; try Data("broken".utf8).write(to: audio)
        XCTAssertThrowsError(try store.verify(first))
        let sibling = ConcertRevision(schema: 1, id: UUID().uuidString, parent: first.id, publisher: device, created: Date(), state: first.state, stateSHA256: first.stateSHA256, assets: [])
        try JSONEncoder().encode(sibling).write(to: store.root.appendingPathComponent("revisions").appendingPathComponent(sibling.id + ".json"))
        XCTAssertThrowsError(try store.head())
    }
    @MainActor func testNativeMatrixRoutingAndRegionStop() async throws {
        let folder = try temporary(), source = try tone(folder, seconds: 0.4), prepare = try AudioPreparation(cache: folder.appendingPathComponent("cache")), audio = try await prepare.prepare(source, rate: 1, semitones: 0)
        let transport = NativeTransport()
        try await transport.load([NativeTrack(id: "one", audio: audio, output: 3, stereo: false)], channels: 4, offline: true)
        try transport.play(position: 0.1, stopAt: 0.2, offline: true)
        let buffer = AVAudioPCMBuffer(pcmFormat: transport.engine.manualRenderingFormat, frameCapacity: 4096)!
        var peaks = Array(repeating: Float(0), count: 4)
        for _ in 0..<4 {
            let status = try transport.engine.renderOffline(4096, to: buffer)
            XCTAssertEqual(status, .success)
            for c in 0..<4 { for i in 0..<Int(buffer.frameLength) { peaks[c] = max(peaks[c], abs(buffer.floatChannelData![c][i])) } }
        }
        XCTAssertLessThan(peaks[0], 0.0001); XCTAssertLessThan(peaks[1], 0.0001); XCTAssertGreaterThan(peaks[2], 0.1); XCTAssertLessThan(peaks[3], 0.0001)
        transport.stop(); transport.engine.stop()
    }
    @MainActor func testBackgroundRenderBlocksKeepFourTracksAndOutputIsolation() async throws {
        let folder = try temporary(), preparation = try AudioPreparation(cache:folder.appendingPathComponent("background-cache"))
        var tracks: [NativeTrack] = []
        for index in 0..<4 {
            let source = try tone(folder,frequency:Double(220 + index * 110),seconds:2)
            let audio = try await preparation.prepare(source,rate:1,semitones:index < 3 ? 2 : 0)
            tracks.append(NativeTrack(id:"track-\(index)",audio:audio,output:index+1,stereo:false))
        }
        let transport = NativeTransport()
        try await transport.load(tracks,channels:6,offline:true)
        defer {transport.stop();transport.engine.stop()}
        XCTAssertGreaterThanOrEqual(transport.audioDiagnostics()["backgroundRenderFrames"] as? UInt32 ?? 0,4096)
        try transport.play(offline:true)
        let buffer = AVAudioPCMBuffer(pcmFormat:transport.engine.manualRenderingFormat,frameCapacity:4096)!
        for _ in 0..<18 {
            XCTAssertEqual(try transport.engine.renderOffline(4096,to:buffer),.success)
            for channel in 0..<6 {
                let peak = (0..<Int(buffer.frameLength)).map{abs(buffer.floatChannelData![channel][$0])}.max() ?? 0
                if channel < 4 {XCTAssertGreaterThan(peak,0.05)} else {XCTAssertLessThan(peak,0.0001)}
            }
        }
    }

    @MainActor func testStandaloneMetronomeToggleDoesNotStartTracks() async throws {
        let folder=try temporary(),source=try tone(folder,seconds:2),preparation=try AudioPreparation(cache:folder.appendingPathComponent("metro-cache")),audio=try await preparation.prepare(source,rate:1,semitones:0)
        let transport=NativeTransport()
        try await transport.load([NativeTrack(id:"track",audio:audio,output:1,stereo:false,gain:0.5)],channels:4,offline:true)
        defer {transport.stop();transport.engine.stop()}
        try transport.startMetronome(NativeClick(bpm:120,continuous:true,output:3,gain:0.2),offline:true)
        XCTAssertFalse(transport.playing);XCTAssertTrue(transport.metronomeRunning);XCTAssertEqual(transport.currentTime,0)
        let buffer=AVAudioPCMBuffer(pcmFormat:transport.engine.manualRenderingFormat,frameCapacity:4096)!
        var clickPeak:Float=0,trackPeak:Float=0
        for _ in 0..<5 {_ = try transport.engine.renderOffline(4096,to:buffer);for frame in 0..<Int(buffer.frameLength) {clickPeak=max(clickPeak,abs(buffer.floatChannelData![2][frame]));trackPeak=max(trackPeak,abs(buffer.floatChannelData![0][frame]))}}
        XCTAssertGreaterThan(clickPeak,0.1);XCTAssertLessThan(trackPeak,0.0001)
        transport.stopMetronome();XCTAssertFalse(transport.metronomeRunning)
        // Stopping the click node must not pause active backing tracks.
        try transport.play(offline:true)
        try transport.startMetronome(NativeClick(output:3,gain:0.2),offline:true)
        transport.stopMetronome();XCTAssertTrue(transport.playing)
        XCTAssertThrowsError(try transport.startMetronome(NativeClick(output:5),offline:true))
    }

    @MainActor func testStereoMetronomeReachesBothPracticeChannels() async throws {
        let folder = try temporary(), source = try tone(folder, seconds: 0.4), prepare = try AudioPreparation(cache: folder.appendingPathComponent("cache")), audio = try await prepare.prepare(source, rate: 1, semitones: 0)
        let transport = NativeTransport()
        try await transport.load([NativeTrack(id:"silent",audio:audio,output:1,stereo:false,gain:0)],channels:2,offline:true)
        try transport.play(click:NativeClick(bpm:120,continuous:true,output:1,gain:0.1,stereo:true),offline:true)
        let buffer = AVAudioPCMBuffer(pcmFormat:transport.engine.manualRenderingFormat,frameCapacity:4096)!
        var peaks = [Float(0),Float(0)]
        for _ in 0..<4 {
            _ = try transport.engine.renderOffline(4096,to:buffer)
            for channel in 0..<2 { for frame in 0..<Int(buffer.frameLength) { peaks[channel] = max(peaks[channel],abs(buffer.floatChannelData![channel][frame])) } }
        }
        XCTAssertGreaterThan(peaks[0],0.05); XCTAssertGreaterThan(peaks[1],0.05)
        XCTAssertEqual(peaks[0],peaks[1],accuracy:0.0001)
        transport.stop();transport.engine.stop()
    }

    @MainActor func testMetronomeSoundChoicesProduceDifferentStereoAudio() async throws {
        let folder=try temporary(),source=try tone(folder,seconds:0.5),preparation=try AudioPreparation(cache:folder.appendingPathComponent("sound-cache")),audio=try await preparation.prepare(source,rate:1,semitones:0)
        var recordings:[[Float]]=[]
        for sound in ["sine","wood","bell"] {
            let transport=NativeTransport()
            try await transport.load([NativeTrack(id:"silent",audio:audio,gain:0)],channels:2,offline:true)
            try transport.play(click:NativeClick(bpm:120,continuous:true,gain:0.1,stereo:true,sound:sound),offline:true)
            let buffer=AVAudioPCMBuffer(pcmFormat:transport.engine.manualRenderingFormat,frameCapacity:4096)!
            var samples:[Float]=[]
            for _ in 0..<4 { _ = try transport.engine.renderOffline(4096,to:buffer)
                for i in 0..<Int(buffer.frameLength) {XCTAssertEqual(buffer.floatChannelData![0][i],buffer.floatChannelData![1][i],accuracy:0.0001);samples.append(buffer.floatChannelData![0][i])}
            }
            XCTAssertGreaterThan(samples.map(abs).max() ?? 0,0.05);recordings.append(samples);transport.stop();transport.engine.stop()
        }
        for i in 1..<recordings.count {let difference=zip(recordings[0],recordings[i]).reduce(Float(0)){$0+abs($1.0-$1.1)};XCTAssertGreaterThan(difference,1)}
    }

    @MainActor func testStereoMainMixerConverts48kTo44100() async throws {
        let folder = try temporary(), source = try tone(folder,seconds:0.4), prepare = try AudioPreparation(cache:folder.appendingPathComponent("cache")), audio = try await prepare.prepare(source,rate:1,semitones:0)
        let transport = NativeTransport()
        try await transport.load([NativeTrack(id:"stereo",audio:audio,output:1,stereo:true)],channels:2,offline:true,stereoOutput:true,renderSampleRate:44100)
        XCTAssertEqual(transport.engine.manualRenderingFormat.sampleRate,44100)
        try transport.play(offline:true)
        let buffer = AVAudioPCMBuffer(pcmFormat:transport.engine.manualRenderingFormat,frameCapacity:4096)!
        var peaks = [Float(0),Float(0)]
        for _ in 0..<4 {
            XCTAssertEqual(try transport.engine.renderOffline(4096,to:buffer),.success)
            for c in 0..<2 { for i in 0..<Int(buffer.frameLength) { peaks[c] = max(peaks[c],abs(buffer.floatChannelData![c][i])) } }
        }
        XCTAssertGreaterThan(peaks[0],0.05);XCTAssertGreaterThan(peaks[1],0.05)
        transport.stop();transport.engine.stop()
    }

    @MainActor func testRealtimeMacRenderClockAndSignal() async throws {
        guard ProcessInfo.processInfo.environment["BENKEN_REALTIME_AUDIO_TEST"] == "1" else { throw XCTSkip("Opt-in hardware render probe") }
        let folder = try temporary(), source = try tone(folder,seconds:1), prepare = try AudioPreparation(cache:folder.appendingPathComponent("cache")), audio = try await prepare.prepare(source,rate:1,semitones:0)
        let transport = NativeTransport()
        try await transport.load([NativeTrack(id:"probe",audio:audio,output:1,stereo:true,gain:0.1)],channels:2,stereoOutput:true)
        // Monitor upstream signal, with practically inaudible output from this test engine only.
        transport.engine.mainMixerNode.outputVolume = 0.000001
        defer { transport.stop();transport.engine.stop() }
        try transport.play()
        try await Task.sleep(nanoseconds:650_000_000)
        let report = transport.audioDiagnostics(),frames=report["outputRenderedFrames"] as? Int64 ?? 0,peak=report["outputMixerPeak"] as? Float ?? 0
        print("REALTIME_MAC_PROBE frames=\(frames) peak=\(peak) position=\(transport.currentTime) running=\(transport.engine.isRunning)")
        let out=(report["outputRenderedFrames"] as? Int64 ?? 0,report["outputMixerPeak"] as? Float ?? 0);print("MAC_DOWNSTREAM frames=\(out.0) peak=\(out.1) matrixLayout=\(transport.engine.attachedNodes.first{$0 is AVAudioUnit}?.outputFormat(forBus:0).channelLayout?.layoutTag ?? 0) mainLayout=\(transport.engine.mainMixerNode.outputFormat(forBus:0).channelLayout?.layoutTag ?? 0)");XCTAssertGreaterThan(out.1,0.0000000001,"Signal disappears in Mac hardware-format mixer")
        XCTAssertGreaterThan(frames,1024,"The live engine did not render frames")
        XCTAssertGreaterThan(peak,0.001,"Scheduled audio did not reach the stereo output path")
    }

}

private final class RealtimeRenderProbe: @unchecked Sendable {
    private let lock=NSLock();private var frames=0;private var peak:Float=0
    func add(_ buffer:AVAudioPCMBuffer){guard let data=buffer.floatChannelData else{return};var value:Float=0
        for channel in 0..<Int(buffer.format.channelCount){for frame in 0..<Int(buffer.frameLength){value=max(value,abs(data[channel][frame]))}}
        lock.lock();frames += Int(buffer.frameLength);peak=max(peak,value);lock.unlock()
    }
    func read()->(Int,Float){lock.lock();defer{lock.unlock()};return (frames,peak)}
}
