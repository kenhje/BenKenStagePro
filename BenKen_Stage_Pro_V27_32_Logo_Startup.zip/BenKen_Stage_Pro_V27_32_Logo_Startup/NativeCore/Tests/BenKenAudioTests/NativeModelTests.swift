import XCTest
import Foundation
@testable import BenKenAudio
final class NativeModelTests: XCTestCase {
    @MainActor func model() throws -> NativeConcertModel {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        return NativeConcertModel(root: root, preferences: UserDefaults(suiteName: "no.benken.tests." + UUID().uuidString)!, startTimers: false)
    }
    func library() throws -> NativeLibrary {
        let raw: [String: Any] = ["songs":[["title":"First", "text":"{section: VERSE}\n[C]First", "playback":["transpose":2,"tracks":[["id":"a","assetId":"missing-a","name":"Bass","fileName":"First Bass.mp3"]]]], ["title":"Second", "text":"{section: CHORUS}\n[G]Second", "playback":["tracks":[["id":"b","assetId":"missing-b","name":"Keys","fileName":"Second Keys.mp3"]]]]],"sets":["Live":[1,0,1]],"set":"Live","opts":[:]]
        return NativeLibrary(state: try JSONSerialization.data(withJSONObject: raw), assets: [:], names: [:])
    }
    @MainActor func testFailedPreparationInvalidatesPlaybackAndMIDICannotPlayOldSong() async throws {
        let model = try model(); model.library = try library(); model.duration = 120
        await model.prepare()
        XCTAssertEqual(model.duration,0); XCTAssertFalse(model.busy); XCTAssertFalse(model.playing)
        XCTAssertTrue(model.status.contains("First Bass.mp3"))
        let failure = model.status
        model.activateMIDI(); model.learnMIDI(.start)
        model.receiveMIDI(source:"test",bytes:[0x90,60,127]); model.receiveMIDI(source:"test",bytes:[0x80,60,0])
        model.receiveMIDI(source:"test",bytes:[0x90,60,127])
        XCTAssertFalse(model.playing); XCTAssertEqual(model.status,failure)
    }
    @MainActor func testSyncWaitsWhileWebPlaybackIsBusy() async throws {
        let model = try model(), folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        model.library = try library(); model.folder = folder; model.syncEnabled = true; model.publisher = true
        model.setExternalPlaybackBusy(true)
        await model.sync()
        XCTAssertFalse(FileManager.default.fileExists(atPath: folder.appendingPathComponent("revisions").path))
        XCTAssertFalse(model.busy)
    }
    @MainActor func testManualSendAndReceiveWorkWithAutomaticSyncOff() async throws {
        let sender = try model(), receiver = try model(), folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let raw: [String: Any] = ["songs":[["title":"Simple concert", "text":"Words", "playback":["tracks":[]]]], "sets":[:], "set":"", "opts":[:]]
        sender.library = NativeLibrary(state: try JSONSerialization.data(withJSONObject: raw), assets: [:], names: [:])
        sender.publisher = true; sender.folder = folder; sender.syncEnabled = false
        let sent = await sender.sync(force: true); XCTAssertTrue(sent)
        XCTAssertNotNil(sender.lastRevision); XCTAssertFalse(sender.syncEnabled)
        receiver.publisher = false; receiver.folder = folder; receiver.syncEnabled = false
        let received = await receiver.sync(force: true); XCTAssertTrue(received)
        XCTAssertEqual(receiver.title,"Simple concert"); XCTAssertEqual(receiver.lastRevision,sender.lastRevision)
        XCTAssertEqual(receiver.syncStatus,"Concert ready on this device."); XCTAssertFalse(receiver.syncEnabled)
    }
    @MainActor func testManualDirectionChangeStopsFormerAutomaticSender() async throws {
        let mac = try model(), ipad = try model(), folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        let raw: [String: Any] = ["songs":[["title":"Direction test","playback":["tracks":[]]]],"sets":[:],"set":"","opts":[:]]
        mac.library = NativeLibrary(state: try JSONSerialization.data(withJSONObject: raw), assets: [:], names: [:])
        mac.publisher = true; mac.syncEnabled = true; mac.folder = folder
        let first = await mac.sync(force: true); XCTAssertTrue(first)
        ipad.folder = folder; ipad.publisher = false
        let receive = await ipad.sync(force: true); XCTAssertTrue(receive)
        ipad.publisher = true
        let reverse = await ipad.sync(force: true); XCTAssertTrue(reverse)
        let latest = try ConcertSyncStore(root: folder).head()
        XCTAssertNotEqual(mac.lastRevision, latest?.id)
        let staleAutomatic = await mac.sync(); XCTAssertFalse(staleAutomatic)
        XCTAssertEqual(try ConcertSyncStore(root: folder).head()?.id, latest?.id)
        mac.publisher = false
        let update = await mac.sync(force: true); XCTAssertTrue(update)
        XCTAssertEqual(mac.lastRevision, ipad.lastRevision)
    }
    @MainActor func testEmptyOrInvalidSyncDoesNotReportSuccess() async throws {
        let model = try model()
        let withoutFolder = await model.sync(force: true); XCTAssertFalse(withoutFolder)
        model.folder = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        model.publisher = false
        let emptyReceive = await model.sync(force: true); XCTAssertFalse(emptyReceive)
        XCTAssertNil(model.library); XCTAssertTrue(model.syncStatus.contains("Waiting"))
        model.publisher = true; model.library = try library()
        let missingSend = await model.sync(force: true); XCTAssertFalse(missingSend)
        XCTAssertNil(model.lastRevision); XCTAssertFalse(model.busy)
    }
    @MainActor func testLyricsUseAppliedKeyAndRemainStableDuringClockUpdates() throws {
        let model = try model(); model.library = try library()
        XCTAssertEqual(model.lyricSections[0].lines[0].chords,"D")
        model.pitch = 4 // An un-applied editor value must not change the displayed key.
        for i in 0..<100 { model.position = Double(i) / 10 }
        XCTAssertEqual(model.lyricSections[0].lines[0].chords,"D")
    }
    @MainActor func testSelectionFollowsSetlistPositionsIncludingRepeats() async throws {
        let model = try model(); model.library = try library()
        await model.selectEntry(0); XCTAssertEqual(model.title,"Second")
        await model.selectEntry(1); XCTAssertEqual(model.title,"First")
        await model.selectEntry(2); XCTAssertEqual(model.title,"Second"); XCTAssertEqual(model.selectedEntry,2)
        XCTAssertEqual(model.duration,0)
        await model.moveSong(1); XCTAssertEqual(model.selectedEntry,2)
    }
}
