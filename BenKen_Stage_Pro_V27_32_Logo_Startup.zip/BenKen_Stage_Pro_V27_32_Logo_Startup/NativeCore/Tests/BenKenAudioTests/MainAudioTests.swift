import XCTest
import AVFoundation
@testable import BenKenAudio
final class MainAudioTests: XCTestCase {
    func sample() throws -> (URL, Data) {
        let url = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".wav")
        let format = AVAudioFormat(standardFormatWithSampleRate: 48000, channels: 1)!
        let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: 24000)!; buffer.frameLength = 24000
        for i in 0..<24000 { buffer.floatChannelData![0][i] = Float(sin(2 * .pi * 220 * Double(i) / 48000) * 0.08) }
        do { let file = try AVAudioFile(forWriting: url, settings: format.settings); try file.write(from: buffer) }
        return (url, try Data(contentsOf: url))
    }
    func rawTracks() -> [[String: Any]] { (0..<4).map { ["id":"t\($0)","assetId":"tone","name":$0 == 3 ? "Drums" : "Tone \($0)","followTranspose":$0 < 3,"stereo":false,"output":$0 + 1,"gain":1.0] } }
    func rawState() throws -> String {
        let value: [String: Any] = ["songs":[["title":"Main interface test","playback":["tracks":rawTracks(),"tempo":["originalBpm":120,"targetBpm":132],"transpose":2]]],"sets":[:],"set":"","opts":["audioOutputMode":"stereo"]]
        return String(data: try JSONSerialization.data(withJSONObject: value), encoding: .utf8)!
    }
    @MainActor func begin(_ session: MainAudioSession, data: Data, token: String) async throws {
        _ = try await session.request(["command":"audioBegin","token":token,"state":rawState(),"assets":[["id":"tone","name":"Tone.wav","size":data.count]]])
    }
    @MainActor func testMainInterfaceFourTracksTempoPitchMixPlayPauseStop() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), session = MainAudioSession(root: root, offline: true), token = UUID().uuidString
        let (source,data) = try sample(); defer { try? FileManager.default.removeItem(at: source); try? FileManager.default.removeItem(at: root) }
        try await begin(session, data:data, token:token)
        _ = try await session.request(["command":"audioChunk","token":token,"asset":"tone","offset":0,"data":data.base64EncodedString()])
        let ready = try await session.request(["command":"audioFinish","token":token,"stereo":true])
        XCTAssertEqual(ready["ready"] as? Bool,true); XCTAssertEqual(ready["duration"] as? Double ?? 0,0.5/1.1,accuracy:0.02)
        let waveform=try await session.request(["command":"audioWaveform","token":token,"track":"t0"])
        let peaks=try XCTUnwrap(waveform["peaks"] as? [Float]);XCTAssertEqual(peaks.count,600);XCTAssertGreaterThan(peaks.max() ?? 0,0.04)
        let cached=try await session.request(["command":"audioWaveform","token":token,"track":"t0"])
        XCTAssertEqual(cached["peaks"] as? [Float],peaks)
        _ = try await session.request(["command":"audioMix","token":token,"tracks":rawTracks(),"master":0.5,"opts":["masterGain":0.5]])
        let play = try await session.request(["command":"audioPlay","token":token,"position":0.1,"stopAt":0.3,"click":["countInBars":0]])
        XCTAssertEqual(play["playing"] as? Bool,true)
        do {_ = try await session.request(["command":"audioWaveform","token":token,"track":"t0"]);XCTFail("Waveform analysis started during playback")} catch {}
        let paused = try await session.request(["command":"audioPause","token":token]); XCTAssertEqual(paused["playing"] as? Bool,false)
        let stopped = try await session.request(["command":"audioStop","token":token]); XCTAssertEqual(stopped["position"] as? Double,0)
        _ = try await session.request(["command":"audioCancel","token":token]); XCTAssertEqual(session.state()["ready"] as? Bool,false)
        XCTAssertFalse(FileManager.default.fileExists(atPath: root.appendingPathComponent("library.json").path),"Main playback must not replace the saved concert library")
    }
    @MainActor func testIncompleteAndStaleTransferCannotStartAudio() async throws {
        let session = MainAudioSession(offline: true), token = UUID().uuidString
        try await begin(session, data:Data([1,2,3,4]), token:token)
        do { _ = try await session.request(["command":"audioChunk","token":token,"asset":"tone","offset":1,"data":"AQI="]); XCTFail("Out-of-order chunk accepted") } catch {}
        do { _ = try await session.request(["command":"audioFinish","token":token]); XCTFail("Incomplete transfer accepted") } catch {}
        let failure = session.diagnostics()["lastAudioError"] as? String ?? ""
        XCTAssertTrue(failure.contains("incomplete"))
        _ = try await session.request(["command":"audioCancel","token":token])
        XCTAssertEqual(session.diagnostics()["lastAudioError"] as? String,failure)
        do { _ = try await session.request(["command":"audioPlay","token":token]); XCTFail("Stale song can play") } catch {}
        XCTAssertFalse(session.playing); XCTAssertEqual(session.state()["ready"] as? Bool,false)
    }
    func prepared() -> [NativeTrack] {
        let audio = PreparedAudio(url:URL(fileURLWithPath:"/tmp/tone.caf"),sourceDuration:1,duration:1,channels:1,sampleRate:48000,digest:"test",preparedDigest:"test")
        return (0..<4).map { NativeTrack(id:"t\($0)",audio:audio) }
    }
    func testMainMixerLevelsBusSoloGroupsAndMasterMute() throws {
        var tracks = rawTracks(); tracks[0]["bus"] = 1; tracks[0]["gain"] = 0.5; tracks[1]["muteGroups"] = [2]
        let options: [String: Any] = ["masterGain":0.5,"mutedGroups":[2],"audioBuses":[["id":1,"gain":0.5,"stereo":false,"output":6]]]
        let mix = try MainAudioMix.resolve(prepared(),tracks:tracks,options:options,master:0.5,stereo:false)
        XCTAssertEqual(mix[0].gain,0.0625); XCTAssertEqual(mix[0].output,6); XCTAssertEqual(mix[1].gain,0)
        tracks[2]["solo"] = true
        let solo = try MainAudioMix.resolve(prepared(),tracks:tracks,options:options,master:1,stereo:true)
        XCTAssertEqual(solo[0].gain,0); XCTAssertEqual(solo[2].gain,0.5); XCTAssertTrue(solo[2].stereo)
        let mute = try MainAudioMix.resolve(prepared(),tracks:tracks,options:["masterMuted":true],master:1,stereo:true)
        XCTAssertTrue(mute.allSatisfy { $0.gain == 0 })
    }
    func testMainMixerRejectsChangedTracksAndInvalidLevels() throws {
        XCTAssertThrowsError(try MainAudioMix.resolve(prepared(),tracks:Array(rawTracks().reversed()),options:[:],master:1,stereo:true))
        XCTAssertThrowsError(try MainAudioMix.resolve(prepared(),tracks:rawTracks(),options:[:],master:.nan,stereo:true))
        var tracks = rawTracks(); tracks[0]["gain"] = -1.0
        XCTAssertThrowsError(try MainAudioMix.resolve(prepared(),tracks:tracks,options:[:],master:1,stereo:true))
    }
    @MainActor func testRefreshPreparedOutputKeepsSongAndRejectsPlaying() async throws {
        let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString), session = MainAudioSession(root: root, offline: true), token = UUID().uuidString
        let (source,data) = try sample(); defer { try? FileManager.default.removeItem(at: source); try? FileManager.default.removeItem(at: root) }
        try await begin(session, data:data, token:token)
        _ = try await session.request(["command":"audioChunk","token":token,"asset":"tone","offset":0,"data":data.base64EncodedString()])
        _ = try await session.request(["command":"audioFinish","token":token,"stereo":true])
        let before = session.state()["duration"] as? Double
        let refreshed = try await session.request(["command":"audioRefreshOutput","token":token])
        XCTAssertEqual(refreshed["token"] as? String,token)
        XCTAssertEqual(refreshed["ready"] as? Bool,true)
        XCTAssertEqual(refreshed["duration"] as? Double,before)
        _ = try await session.request(["command":"audioPlay","token":token,"position":0])
        do { _ = try await session.request(["command":"audioRefreshOutput","token":token]); XCTFail("Must not rebuild an output during playback") } catch {}
        XCTAssertTrue(session.playing)
        session.cancel()
    }

}
