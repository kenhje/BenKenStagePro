// swift-tools-version: 5.9
import PackageDescription
let package = Package(name: "BenKenAudio", platforms: [.macOS(.v13), .iOS(.v16)], products: [.library(name: "BenKenAudio", targets: ["BenKenAudio"])], targets: [.target(name: "BenKenAudio"), .testTarget(name: "BenKenAudioTests", dependencies: ["BenKenAudio"])])
