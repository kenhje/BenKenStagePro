BenKen Native V27.29 · Waveform and per-track meters
6 November 2026

Pair with Web V26.115. Open App/BenKenStagePro.xcodeproj. Build over the existing app using the same team/app identity. Do not delete the app or its library.

Waveform uses prepared local audio and a bounded worker read buffer. Play/song changes cancel analysis. Compact peaks are cached. Track meters sample the actual signal after EQ and scale it by the current mix gain. Meter scans expire when the mixer is hidden. The master meter remains a separate output measurement.

Audio routing, EQ and playback scheduling are unchanged. Automated render tests and builds checked. Physical USB and device verification is still required.
