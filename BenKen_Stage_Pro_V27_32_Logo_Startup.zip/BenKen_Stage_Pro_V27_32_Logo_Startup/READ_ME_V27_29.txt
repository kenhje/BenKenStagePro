BenKen Native V27.29 — metronome on/off
6 November 2026 · Use with Web V26.118 or newer.

Open App/BenKenStagePro.xcodeproj. Select your device and developer team, then Run over the existing BenKen Stage Pro app. Do not delete the app. Bundle identity and storage remain unchanged.

Standalone click and click on/off during playback use the existing native click node and saved output routing. No backing-track start, stop or seek is issued by the metronome buttons. Toggling on during playback joins the song beat grid. STOP, route changes and interruptions stop the click. Requires the selected song to be prepared first. Native metronome does not start MIDI Clock when used on its own.

Web Controls and the optional left shortcut both toggle the click. Configure BPM, sound, level and bus under Tempo & metronome. Practice/Stereo sends click to 1–2; Live/USB uses the selected bus.

Validation: 47 core tests (2 skipped), no failures, including independent click USB output and no backing-track start, plus iOS and Mac Catalyst builds without signing. Audio through your physical interface, background behavior and device touch testing remain required.
Made for BenKen™ · Copyright © Kenneth Hjelle 2026
