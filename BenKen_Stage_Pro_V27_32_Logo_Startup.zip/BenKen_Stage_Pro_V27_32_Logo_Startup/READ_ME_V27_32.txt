BenKen Native V27.32 / Web V26.148 — 10 November 2026

Normal startup shows only the existing BenKen logo and BENKEN STAGE PRO on dark navy. A matching system launch screen covers the first opening frame. Loading details and controls appear only if startup fails. Existing timeout, retry, saved-concert access and stop-audio safeguards remain.

Install over the existing app with the same signing team and bundle identifier. Do not uninstall. Open App/BenKenStagePro.xcodeproj. This native update is required for the new opening screen; a web refresh alone is insufficient. The Web folder contains the matching V26.148 package. Physical device launch verification pending.
